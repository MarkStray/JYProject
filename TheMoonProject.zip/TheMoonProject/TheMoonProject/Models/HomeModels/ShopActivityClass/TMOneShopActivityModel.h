//
//  TMOneShopActivityModel.h
//  TheMoonProject
//
//  Created by iOS_yixin on 16/4/8.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TMOneShopActivityModel : NSObject




@end
