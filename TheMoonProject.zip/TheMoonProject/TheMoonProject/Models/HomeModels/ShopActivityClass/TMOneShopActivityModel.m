//
//  TMOneShopActivityModel.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/4/8.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMOneShopActivityModel.h"

@implementation TMOneShopActivityModel

@end
