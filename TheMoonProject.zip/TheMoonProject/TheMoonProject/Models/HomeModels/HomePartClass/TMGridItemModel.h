//
//  TMGridItemModel.h
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TMGridItemModel : NSObject

@property (nonatomic, strong) NSString *title;
@property (nonatomic, strong) NSString *imageStr;

/**
 *  用来跳转
 */
@property (nonatomic, assign) Class destinationClass;

@end
