//
//  AppMacro.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/7.
//  Copyright © 2016年 moon. All rights reserved.
//

#ifndef AppMacro_h
#define AppMacro_h


#endif /* AppMacro_h */ 


//放app相关的宏定义，如:
// 收藏相关
//#define COLLECT_CACHE_PATH @"collected"

#if DEBUG
#define APPHOST @"http://www.otoera.com"
#else
#define APPHOST @"http://114.80.106.68"
#endif

#if DEBUG
#define APPPORT @"8080"
#else
#define APPPORT @"8080"
#endif