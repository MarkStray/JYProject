//
//  VendorMacro.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/7.
//  Copyright © 2016年 moon. All rights reserved.
//

#ifndef VendorMacro_h
#define VendorMacro_h


#endif /* VendorMacro_h */
//放一些第三方常量，如：
#define QQ_KEY @"xxxxx"