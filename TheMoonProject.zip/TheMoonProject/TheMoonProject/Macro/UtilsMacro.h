//
//  UtilsMacro.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/7.
//  Copyright © 2016年 moon. All rights reserved.
//

#ifndef UtilsMacro_h
#define UtilsMacro_h


#endif /* UtilsMacro_h */

//放方便使用的宏定义，如：
#define NSStringFromInt(intValue) [NSString stringWithFormat:@"%d",intValue]

/**
 *  获取物理屏幕尺寸
 */
#define PhoneScreen_HEIGHT [UIScreen mainScreen].bounds.size.height
#define PhoneScreen_WIDTH [UIScreen mainScreen].bounds.size.width

/**
 *  判断IOS7或者IOS6以下，YES为7，NO为6以下
 */
#define OSVersionIsAtLeastiOS7 (floor(NSFoundationVersionNumber) > NSFoundationVersionNumber_iOS_6_1)



/**
 *  获取 iOS 版本信息
 */
#define IOSVer      ((float)[[[UIDevice currentDevice] systemVersion] floatValue])
#define IOSVerUp8   (IOSVer >= 8.0)

///**
// *  判断屏幕4英寸还是3.5英寸，YES为Iphone5，NO为Iphone4
// */
//#define OSRetinaIs4inch ([UIScreen mainScreen].bounds.size.height > 480)

/**
 *  NSLog宏定义
 */
#define ACNSLog(format, ...) do {                                                                          \
fprintf(stderr, "<%s : %d> %s\n",                                           \
[[[NSString stringWithUTF8String:__FILE__] lastPathComponent] UTF8String],  \
__LINE__, __func__);                                                        \
(NSLog)((format), ##__VA_ARGS__);                                           \
\
} while (0)

///**
// *  提示框
// *
// *  @param m 提示的文字
// *
// *  @return null
// */

#define SHOWALERT(m) \
{\
UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:m delegate:nil cancelButtonTitle:@"确认" otherButtonTitles:nil];\
[alert show]; \
}\

//#define SHOWALERT_Success(m) \
//{\
//[HTProgressAlert showHudWithTitleSuccess:@"提示" withStatus:m afterDelay:2];\
//}\
//
//#define SHOWALERT_Error(m) \
//{\
//[HTProgressAlert showHudWithTitle:@"提示" withStatus:m afterDelay:2];\
//}\
//
//
//#define ISSUCCESS(m) [[m objectForKey:@"_success"]intValue]
//
//#define ERROR_MSG(m) [m objectForKey:@"error_msg"]
//
//#define APPDelegate ((ACAppDelegate *)[UIApplication sharedApplication].delegate)
//
//#define EmoFilePath [[NSBundle mainBundle] pathForResource:@"faceList" ofType:@"plist"]
//
//#define Emoji [NSArray arrayWithContentsOfFile:EmoFilePath];
//
//#define USERSIGN [ACUserInfo sharedInstance].sign

#define WeakSelf ({__weak __typeof(self) weakSelf = self;weakSelf;})

/**
 *  隐藏键盘
 *
 *  @return nil
 */
#define HidenKeybory {[[[UIApplication sharedApplication] keyWindow] endEditing:YES];}

/**
 *  设置颜色RGB值
 */
#define RGBCOLOR(r,g,b,_alpha) [UIColor colorWithRed:r/255.0 green:g/255.0 blue:b/255.0 alpha:_alpha]
/**
 *  主颜色(蓝色)
 */
#define ROOT_TINT_COLOR [UIColor colorWithRed:14.0/255.0 green:168.0/255.0 blue:225.0/255.0 alpha:1]

//#define CUSTOM_COLOR [UIColor colorWithRed:109/255.0 green:177/255.0 blue:242/255.0 alpha:1]
//
//#define TINT_COLOR [UIColor colorWithRed:253.0/255.0 green:131.0/255.0 blue:97.0/255.0 alpha:1]
//
//#if TARGET_IPHONE_SIMULATOR
//#define SIMULATOR 1
//#elif TARGET_OS_IPHONE
//#define SIMULATOR 0
//#endif
//
//#define NAV_COLOR [UIColor colorWithRed:63.0/255.0 green:66.0/255.0 blue:81.0/255.0 alpha:1]
//
////保存关闭了消息通知的好友数组
//#define kNotNotificationUsers @"notNotificationUsers"
//
////微信授权相关，以后在此修改，其他地方不要乱动
//#define kWXAppID @"wx06b2ffbbd94f0a4a"
//#define kWXAppSecret @"5415b7f6e28152eddef4ed41f165e147"
//
//#define iSiPhone [[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone
