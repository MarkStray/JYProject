//
//  NotificationMacro.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/7.
//  Copyright © 2016年 moon. All rights reserved.
//

#ifndef NotificationMacro_h
#define NotificationMacro_h


#endif /* NotificationMacro_h */

//放通知相关的宏定义