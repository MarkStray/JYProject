//
//  ACBaseRequestParam.h
//  AChatSoftWare
//
//  Created by 藏云柱 on 15/4/10.
//  Copyright (c) 2015年 zangyunzhu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
#import "NSString+md5.h"
#import "NSDictionary+URLParam.h"
#import "AppMacro.h"

static CGFloat const kHttpTimeoutInterval = 25.0f;
static NSString * const kHttpRequestMethod   = @"GET";

@interface ACBaseRequestParam : NSObject

@property (nonatomic,copy,readonly) NSString *host;
@property (nonatomic,copy,readonly) NSString *port;
@property (nonatomic,copy) NSString *path;

- (ACBaseRequestParam *)initWithHost:(NSString *)host port:(NSString *)port path:(NSString *)path;

- (NSString *)buildRequestPath;

- (id)initWithPath:(NSString *)path;

- (NSMutableDictionary *)buildRequestParam;

- (AFHTTPRequestOperation *)buildRequestOperation;

-(AFHTTPRequestOperation *)ZYZYZYZYZYbuildRequestOperation;


@end
