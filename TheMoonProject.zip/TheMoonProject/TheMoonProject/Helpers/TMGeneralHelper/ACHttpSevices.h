//
//  ACHttpSevices.h
//  AChatSoftWare
//
//  Created by 藏云柱 on 15/4/10.
//  Copyright (c) 2015年 zangyunzhu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "AFNetworking.h"
//#import "NSString+replaceUnicode.h"
#import "ACBaseRequestParam.h"

@interface ACHttpSevices : NSObject

@property (nonatomic, strong) NSOperationQueue *operationQueue;

+ (instancetype)services;

/**
 *  利用参数模型请求
 */
- (AFHTTPRequestOperation *)requestWithParm:(ACBaseRequestParam *)requestParam
                                    success:(void (^)(AFHTTPRequestOperation *operation, id result))success
                                    failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

/**
 *  利用URl运行
 */
- (AFHTTPRequestOperation *)requestWithURL:(NSString *)urlString
                               finishBlock:(void (^)(id object))block
                                   failure:(void (^)(NSError *error))failure;

- (AFHTTPRequestOperation *)requestByOperation:(AFHTTPRequestOperation *)aOperation
                                       success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
                                       failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

- (AFHTTPRequestOperation *)requestWithURLPost:(NSString *)urlString
                                   finishBlock:(void (^)(id object))block
                                       failure:(void (^)(NSError *error))failure;

- (void)requestByOperations:(NSMutableArray *)operations finished:(void(^)(void))finished;

- (AFHTTPRequestOperation *)ZYZYZYZYZYrequestWithParm:(ACBaseRequestParam *)requestParam
                                              success:(void (^)(AFHTTPRequestOperation *operation, id result))success
                                              failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure;

@end
