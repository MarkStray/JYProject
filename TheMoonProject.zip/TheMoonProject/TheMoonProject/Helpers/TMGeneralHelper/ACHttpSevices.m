//
//  ACHttpSevices.m
//  AChatSoftWare
//
//  Created by 藏云柱 on 15/4/10.
//  Copyright (c) 2015年 zangyunzhu. All rights reserved.
//

#import "ACHttpSevices.h"

@implementation ACHttpSevices

+ (instancetype)services
{
    return [[[self class] alloc]init];
}

- (id)init
{
    self = [super init];
    if (self) {
        self.operationQueue = [[NSOperationQueue alloc] init];
    }
    return self;
}

#pragma mark - 常用请求
/**
 *  通过参数模型请求网络
 */
- (AFHTTPRequestOperation *)requestWithParm:(ACBaseRequestParam *)requestParam
                                    success:(void (^)(AFHTTPRequestOperation *operation, id result))success
                                    failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    AFHTTPRequestOperation *operation = [requestParam buildRequestOperation];
    
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         if (success) { success(operation,responseObject);}
         
     }failure:^(AFHTTPRequestOperation *operation, NSError *error){
         
         NSLog(@"\nRequest failure : \n%@\n",error);
         NSLog(@"%@",error);
         if (error.domain == NSURLErrorDomain && error.code == -999)
         {
             NSLog(@"The request cancel. \n %@",error);
         }
         
         if (error.domain == NSURLErrorDomain && error.code == -1001)
         {
             NSLog(@"网络请求超时！");
             NSLog(@"The request timed out.\n %@",error);
         }
         if (failure) { failure(operation,error);}
     }];
    
    [self.operationQueue addOperation:operation];
    return operation;
}


/**
 *  通过URL请求网络
 */
- (AFHTTPRequestOperation *)requestWithURL:(NSString *)urlString
                               finishBlock:(void (^)(id object))block
                                   failure:(void (^)(NSError *error))failure
{
    urlString = [NSString stringWithFormat:@"%@",[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:urlString]];
    [request setHTTPMethod:@"GET"];
    [request setTimeoutInterval:25];
    
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         id result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:NULL];
         if (block)
         {
             block(result);
         }
         
     }failure:^(AFHTTPRequestOperation *operation, NSError *error){
         if (error.domain == NSURLErrorDomain && error.code == -999)
         {
            //NSLog(@"已取消网络请求！ \n %@",error);
         }
         
         if (error.domain == NSURLErrorDomain && error.code == -1001)
         {
             //NSLog(@"请求超时！\n %@",error);
         }
         if (failure)
         {
             failure(error);
         }
     }];
    //发异步请求
    [self.operationQueue addOperation:operation];
    return operation;
}

#pragma mark- 不常用请求
- (AFHTTPRequestOperation *)requestByOperation:(AFHTTPRequestOperation *)aOperation
                                       success:(void (^)(AFHTTPRequestOperation *operation, id responseObject))success
                                       failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    AFHTTPRequestOperation *operation = aOperation;
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         //         NSLog(@"\nRequest success : \n%@\n",[[responseObject description] replaceUnicode]);
         
         if (success) { success(operation,responseObject);}
         
     }failure:^(AFHTTPRequestOperation *operation, NSError *error){
         
         NSLog(@"\nRequest failure : \n%@\n",error);
         NSLog(@"%@",error);
         if (error.domain == NSURLErrorDomain && error.code == -999)
         {
             NSLog(@"The request cancel. \n %@",error);
         }
         
         if (error.domain == NSURLErrorDomain && error.code == -1001)
         {
             NSLog(@"The request timed out.\n %@",error);
         }
         if (failure) { failure(operation,error);}
     }];
    
    [self.operationQueue addOperation:operation];
    return operation;
}

- (AFHTTPRequestOperation *)requestWithURLPost:(NSString *)urlString
                                   finishBlock:(void (^)(id object))block
                                       failure:(void (^)(NSError *error))failure
{
    urlString = [NSString stringWithFormat:@"%@",[urlString stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSMutableURLRequest *request = [[NSMutableURLRequest alloc]initWithURL:[NSURL URLWithString:urlString]];
    [request setHTTPMethod:@"POST"];
    [request setTimeoutInterval:25];
    
    AFHTTPRequestOperation *operation = [[AFHTTPRequestOperation alloc] initWithRequest:request];
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         //NSLog(@"\nRequest success : \n%@\n",[[responseObject description] replaceUnicode]);
         id result = [NSJSONSerialization JSONObjectWithData:responseObject options:NSJSONReadingMutableLeaves error:NULL];
         //         NSLog(@"\nRequest success : \n%@\n",[[result description] replaceUnicode]);
         if (block)
         {
             block(result);
         }
         
     }failure:^(AFHTTPRequestOperation *operation, NSError *error){
         
         NSLog(@"\nRequest failure : \n%@\n",error);
         NSLog(@"%@",error);
         if (error.domain == NSURLErrorDomain && error.code == -999)
         {
             NSLog(@"已取消网络请求！ \n %@",error);
         }
         
         if (error.domain == NSURLErrorDomain && error.code == -1001)
         {
             NSLog(@"请求超时！\n %@",error);
         }
         if (failure)
         {
             failure(error);
         }
     }];
    
    //发异步请求
    [self.operationQueue addOperation:operation];
    return operation;
}

- (void)requestByOperations:(NSMutableArray *)operations finished:(void(^)(void))finished
{
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSOperationQueue *queue = [[NSOperationQueue alloc] init];
        for (int i = 0; i < operations.count; i ++)
        {
            NSOperation *operation = operations[i];
            [queue addOperation:operation];
        }
        
        [queue waitUntilAllOperationsAreFinished];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            if (finished) {
                finished();
            }
        });
    });
}


- (AFHTTPRequestOperation *)ZYZYZYZYZYrequestWithParm:(ACBaseRequestParam *)requestParam
                                    success:(void (^)(AFHTTPRequestOperation *operation, id result))success
                                    failure:(void (^)(AFHTTPRequestOperation *operation, NSError *error))failure
{
    AFHTTPRequestOperation *operation = [requestParam ZYZYZYZYZYbuildRequestOperation];
    
    
    [operation setCompletionBlockWithSuccess:^(AFHTTPRequestOperation *operation, id responseObject)
     {
         if (success) { success(operation,responseObject);}
         
     }failure:^(AFHTTPRequestOperation *operation, NSError *error){
         
         NSLog(@"\nRequest failure : \n%@\n",error);
         NSLog(@"%@",error);
         if (error.domain == NSURLErrorDomain && error.code == -999)
         {
             NSLog(@"The request cancel. \n %@",error);
         }
         
         if (error.domain == NSURLErrorDomain && error.code == -1001)
         {
             NSLog(@"网络请求超时！");
             NSLog(@"The request timed out.\n %@",error);
         }
         if (failure) { failure(operation,error);}
     }];
    
    [self.operationQueue addOperation:operation];
    return operation;
}


@end
