//
//  ACViewHelper.h
//  AChatSoftWare
//
//  Created by 藏云柱 on 15/4/10.
//  Copyright (c) 2015年 zangyunzhu. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <Accelerate/Accelerate.h>

@interface ACViewHelper : NSObject

/**
 *  导航栏标题
 *
 *  @param title 标题内容
 *
 *  @return 返回标题视图
 */
+ (UIView *)navigationTitleView:(NSString *)title;

/**
 *  导航栏返回上一页按钮
 *
 *  @param target self
 *  @param action 按钮触发事件
 *
 *  @return 返回按钮视图
 */
+ (UIBarButtonItem *)backBarButtonItemTarget:(id)target action:(SEL)action;
/**
 *  万能按钮
 *
 *  @param target self
 *  @param action 按钮触发事件
 *
 *  @return
 */
+ (UIBarButtonItem *)customButtonItemTarget:(NSString *)text target:(id)target action:(SEL)action;
/**
 *  导航栏返回首页按钮
 *
 *  @param target self
 *  @param action 按钮触发事件
 *
 *  @return 返回首页视图
 */
+ (UIBarButtonItem *)mainBarButtonItemTarget:(id)target action:(SEL)action;

//取消按钮
+ (UIBarButtonItem *)cancelBarButtonItemTarget:(id)target action:(SEL)action;

/**
 *  对视图进行圆角设置
 *
 *  @param view
 */
+ (void)makeViewToRadius:(UIView *)view borderColor:(UIColor *)color cornerRadius:(CGFloat)radius;

/**
 *  对图片进行高斯模糊处理
 *
 *  @param image 目标图片
 *
 *  @return 生成的图片
 */
+ (UIImage *)createGaussianImage:(UIImage *)image;

+ (UIImage *)blurryImage:(UIImage *)image withBlurLevel:(CGFloat)blur;

/**
 *  根据颜色生成图片
 *
 *  @param color 目标颜色
 *
 *  @return 生成的图片
 */
+ (UIImage *)createImageWithColor:(UIColor *)color;

/**
 *  对图片进行拉伸
 *
 *  @param image
 *
 *  @return
 */
+ (UIImage *)resizableImage:(UIImage *)image;

@end
