//
//  NSDictionary+URLParam.h
//  CiticMovie
//
//  Created by fuqiang on 12/9/13.
//  Copyright (c) 2013 fuqiang. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSDictionary (URLParam)

-(NSString *)URLParam;

@end
