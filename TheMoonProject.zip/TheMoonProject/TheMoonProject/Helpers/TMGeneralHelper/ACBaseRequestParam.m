//
//  ACBaseRequestParam.m
//  AChatSoftWare
//
//  Created by 藏云柱 on 15/4/10.
//  Copyright (c) 2015年 zangyunzhu. All rights reserved.
//
//  说明： 其他部分要使用参数模型，只要集成ACBaseRequestParam 就可以了，默认为get方法。
//  参数模型有主要用到 init  和  initWithPath  方法创建
//  .m 文件中实现方法
//  - (NSString *)buildRequestPath 返回接口
//  - (NSMutableDictionary *)buildRequestParam 返回接口其他字段即可。
//  如果post请求 重写方法 -(AFHTTPRequestOperation *)buildRequestOperation  即可。

#import "ACBaseRequestParam.h"

@implementation ACBaseRequestParam

- (id)init
{
    self = [super init];
    
    if (self) {
        _host = APPHOST;
        _port = APPPORT;
        _path = [self buildRequestPath];
    }
    return self;
}

- (id)initWithPath:(NSString *)path
{
    self = [super init];
    if (self)
    {
        _host = APPHOST;
        _port = APPPORT;
        _path = path;
    }
    return self;
}

- (ACBaseRequestParam *)initWithHost:(NSString *)host port:(NSString *)port path:(NSString *)path
{
    self = [super init];
    if (self)
    {
        _host = host;
        _port = port;
        _path = path;
    }
    return self;
}

/**
 *  返回  接口
 */
- (NSString *)buildRequestPath
{
    return nil;
}

/**
 *  返回所需参数
 */
- (NSMutableDictionary *)buildRequestParam
{
    NSMutableDictionary *dic = [[NSMutableDictionary alloc] init];
    
    return dic;
}

-(AFHTTPRequestOperation *)buildRequestOperation
{
    AFHTTPRequestOperation *operation;
    
    NSString * url = [NSString stringWithFormat:@"%@:%@%@",self.host,self.port,self.path];
    
    NSMutableDictionary * param = [self buildRequestParam];
    
    NSMutableURLRequest * request = [[AFHTTPRequestSerializer serializer]requestWithMethod:kHttpRequestMethod URLString:url parameters:param error:nil];
    
    operation = [[AFHTTPRequestOperation alloc]initWithRequest:request];
    
    operation.responseSerializer = [AFJSONResponseSerializer serializer];
    
    return operation;
}

-(AFHTTPRequestOperation *)ZYZYZYZYZYbuildRequestOperation
{
    AFHTTPRequestOperation *operation;
    
    NSString * url = [NSString stringWithFormat:@"%@",self.path];
    
    NSMutableDictionary * param = [self buildRequestParam];
    
    NSMutableURLRequest * request = [[AFHTTPRequestSerializer serializer]requestWithMethod:@"POST" URLString:url parameters:param error:nil];
    
    operation = [[AFHTTPRequestOperation alloc]initWithRequest:request];
    
    operation.responseSerializer = [AFJSONResponseSerializer serializer];
    
    return operation;
}


@end
