//
//  TMEaseMobManager.m
//  TheMoonProject
//
//  Created by WQL on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMEaseMobManager.h"
#import "EMSDK.h"
@interface TMEaseMobManager()<EMChatManagerDelegate,EMClientDelegate>
{
    NSMutableArray *offlineMessageArray;
}

@end

@implementation TMEaseMobManager
#pragma mark - sharedInstance
+ (instancetype)sharedInstance
{
    static TMEaseMobManager *_sharedManager = nil;
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        _sharedManager = [[TMEaseMobManager alloc]init];
    });
    return _sharedManager;
}
#pragma mark init 方法
- (instancetype)init
{
    if (self = [super init]) {
        [[EMClient sharedClient].chatManager removeDelegate:self];
        [[EMClient sharedClient].chatManager addDelegate:self delegateQueue:nil];
    }
    return self;
}
#pragma mark - 发送消息
- (void)sendMessageWithParam:(id)param
{
    NSLog(@"发送消息");
}

#pragma mark - 仅账号登录环信
- (void)loginEaseMobWithUserID:(NSString *)userID
{
    EMError *error = [[EMClient sharedClient] loginWithUsername:userID password:@"123456"];
    if (!error) {
        NSLog(@"Client 登录成功～");
    }else{
        NSLog(@"Client 登录失败！Error:%@",error.errorDescription);
    }
}

#pragma mark - 帐号密码登录环信
- (void)loginEaseMobWithUserID:(NSString *)userID  withPassword:(NSString*)password
{
    EMError *error = [[EMClient sharedClient] loginWithUsername:userID password:password];
    if (!error) {
        NSLog(@"Client 登录成功～");
    }else{
        NSLog(@"Client 登录失败！Error:%@",error.errorDescription);
    }
}

#pragma mark - 接收到消息
- (void)didReceiveMessages:(NSArray *)aMessages
{
    for (EMMessage *message in aMessages) {
        EMMessageBody *msgBody = message.body;
        switch (msgBody.type) {
            case EMMessageBodyTypeText:
            {
                // 收到的文字消息
                EMTextMessageBody *textBody = (EMTextMessageBody *)msgBody;
                NSString *txt = textBody.text;
                
                if (!offlineMessageArray) {
                    offlineMessageArray = [NSMutableArray array];
                }
                
                [offlineMessageArray addObject:txt];
                
                for (NSString *str in offlineMessageArray) {
                    NSLog(@"离线消息：%@",str);
                }
            }
                break;
            case EMMessageBodyTypeImage:
            {
                // 得到一个图片消息body
                EMImageMessageBody *body = ((EMImageMessageBody *)msgBody);
                
                NSURLSessionConfiguration *confi = [NSURLSessionConfiguration defaultSessionConfiguration];
                NSURLSession *session = [NSURLSession sessionWithConfiguration:confi];
                
                NSURL *url = [NSURL URLWithString:body.thumbnailRemotePath];
                
                NSURLSessionDataTask *task = [session dataTaskWithURL:url completionHandler:^(NSData * _Nullable data, NSURLResponse * _Nullable response, NSError * _Nullable error) {
                    if (data) {
                        UIImage *loadImage = [UIImage imageWithData:data];
                        #pragma unused(loadImage)
                        dispatch_async(dispatch_get_main_queue(), ^{
                            NSLog(@"接收到了图片～");
                        });
                    }
                }];
                [task resume];
                
                
                NSLog(@"大图remote路径 -- %@"   ,body.remotePath);
                NSLog(@"大图local路径 -- %@"    ,body.localPath); // // 需要使用sdk提供的下载方法后才会存在
                NSLog(@"大图的secret -- %@"    ,body.secretKey);
                NSLog(@"大图的W -- %f ,大图的H -- %f",body.size.width,body.size.height);
                NSLog(@"大图的下载状态 -- %u",body.downloadStatus);
                
                
                // 缩略图sdk会自动下载
                NSLog(@"小图remote路径 -- %@"   ,body.thumbnailRemotePath);
                NSLog(@"小图local路径 -- %@"    ,body.thumbnailLocalPath);
                NSLog(@"小图的secret -- %@"    ,body.thumbnailSecretKey);
                NSLog(@"小图的W -- %f ,大图的H -- %f",body.thumbnailSize.width,body.thumbnailSize.height);
                NSLog(@"小图的下载状态 -- %u",body.thumbnailDownloadStatus);
            }
                break;
            case EMMessageBodyTypeLocation:
            {
                EMLocationMessageBody *body = (EMLocationMessageBody *)msgBody;
                NSLog(@"纬度-- %f",body.latitude);
                NSLog(@"经度-- %f",body.longitude);
                NSLog(@"地址-- %@",body.address);
            }
                break;
            case EMMessageBodyTypeVoice:
            {
                // 音频sdk会自动下载
                EMVoiceMessageBody *body = (EMVoiceMessageBody *)msgBody;
                NSLog(@"音频remote路径 -- %@"      ,body.remotePath);
                NSLog(@"音频local路径 -- %@"       ,body.localPath); // 需要使用sdk提供的下载方法后才会存在（音频会自动调用）
                NSLog(@"音频的secret -- %@"        ,body.secretKey);
                NSLog(@"音频文件大小 -- %lld"       ,body.fileLength);
                NSLog(@"音频文件的下载状态 -- %u"   ,body.downloadStatus);
                NSLog(@"音频的时间长度 -- %u"      ,body.duration);
            }
                break;
            case EMMessageBodyTypeVideo:
            {
                EMVideoMessageBody *body = (EMVideoMessageBody *)msgBody;
                
                NSLog(@"视频remote路径 -- %@"      ,body.remotePath);
                NSLog(@"视频local路径 -- %@"       ,body.localPath); // 需要使用sdk提供的下载方法后才会存在
                NSLog(@"视频的secret -- %@"        ,body.secretKey);
                NSLog(@"视频文件大小 -- %lld"       ,body.fileLength);
                NSLog(@"视频文件的下载状态 -- %u"   ,body.downloadStatus);
                NSLog(@"视频的时间长度 -- %u"      ,body.duration);
                NSLog(@"视频的W -- %f ,视频的H -- %f", body.thumbnailSize.width, body.thumbnailSize.height);
                
                // 缩略图sdk会自动下载
                NSLog(@"缩略图的remote路径 -- %@"     ,body.thumbnailRemotePath);
                NSLog(@"缩略图的local路径 -- %@"      ,body.thumbnailLocalPath);
                NSLog(@"缩略图的secret -- %@"        ,body.thumbnailSecretKey);
                NSLog(@"缩略图的下载状态 -- %u"      ,body.thumbnailDownloadStatus);
            }
                break;
            case EMMessageBodyTypeFile:
            {
                EMFileMessageBody *body = (EMFileMessageBody *)msgBody;
                NSLog(@"文件remote路径 -- %@"      ,body.remotePath);
                NSLog(@"文件local路径 -- %@"       ,body.localPath); // 需要使用sdk提供的下载方法后才会存在
                NSLog(@"文件的secret -- %@"        ,body.secretKey);
                NSLog(@"文件文件大小 -- %lld"       ,body.fileLength);
                NSLog(@"文件文件的下载状态 -- %u"   ,body.downloadStatus);
            }
                break;
                
            default:
                break;
        }
        
    }

}

#pragma mark - 退出环信
- (void)logoutEaseMob
{
    EMError *error = [[EMClient sharedClient] logout:YES];
    if (!error) {
        NSLog(@"Client 退出成功");
    }else{
        NSLog(@"Client 退出失败！Error:%@",error.errorDescription);
    }
}

@end
