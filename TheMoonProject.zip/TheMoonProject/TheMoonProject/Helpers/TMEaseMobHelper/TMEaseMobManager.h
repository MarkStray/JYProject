//
//  TMEaseMobManager.h
//  TheMoonProject
//
//  Created by WQL on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>
@interface TMEaseMobManager : NSObject

+ (instancetype)sharedInstance;

- (void)sendMessageWithParam:(id)param;

- (void)loginEaseMobWithUserID:(NSString *)userID;

- (void)loginEaseMobWithUserID:(NSString *)userID  withPassword:(NSString*)password;

- (void)logoutEaseMob;

@end
