//
//  TMBaseViewController.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/7.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMBaseViewController.h"

@implementation TMBaseViewController

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
        
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    //解决push时右上方短暂停留的黑块问题
//    self.navigationController.view.backgroundColor = [UIColor whiteColor];
}
@end
