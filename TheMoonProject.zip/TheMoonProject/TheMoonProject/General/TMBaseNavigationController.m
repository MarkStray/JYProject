//
//  TMBaseNavigationController.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/7.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMBaseNavigationController.h"

@implementation TMBaseNavigationController


- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationBar.barTintColor = ROOT_TINT_COLOR;
    self.navigationBar.translucent = NO;
    self.navigationBar.barStyle = UIBarStyleBlack;
//    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    [[UIBarButtonItem appearance] setBackButtonTitlePositionAdjustment:UIOffsetMake(NSIntegerMin, NSIntegerMin) forBarMetrics:UIBarMetricsDefault];
    UIImage *backButtonImage = [[UIImage imageNamed:@"navigationbar_back"] resizableImageWithCapInsets:UIEdgeInsetsMake(0, 30, 0, 0)];
    [[UIBarButtonItem appearance] setBackButtonBackgroundImage:backButtonImage forState:UIControlStateNormal barMetrics:UIBarMetricsDefault];
}

@end
