//
//  LPGeneralHelper.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LPGeneralHelper : NSObject

+ (NSArray *) getEmojiArray;
+ (NSAttributedString *) attributedStringWithText:(NSString *)str;
+ (void) deleteFaceStringWithTextView:(UITextView *)textView andFaceArray:(NSArray *)faceArray complement:(void(^)()) complement;
+ (void)countDownWithTime:(int)time
           countDownBlock:(void (^)(int timeLeft))countDownBlock
                 endBlock:(void (^)())endBlock;
@end
