//
//  TMChatHelper.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/29.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMChatHelper.h"

@implementation TMChatHelper

- (instancetype)initWithMessageObject:(NSDictionary *)contentDict andTextView:(UITextView *)tempTextView messageType:(NSUInteger) messageType
{
    self = [super init];
    if (self) {
        _contentDict = [contentDict copy];
        _messageType = messageType;
        [self cacheMessageDescrption:tempTextView];
    }
    return self;
}

- (void) cacheMessageDescrption:(UITextView *)tempTextView
{
    
    
//    if (_contentDict.allKeys[0]) {
//        <#statements#>
//    }
//    self.messageType = 1;
    switch (self.messageType) {
        case 1:
            //text
        {
            CGSize textViewSize = [tempTextView sizeThatFits:CGSizeMake(tempTextView.bounds.size.width, CGFLOAT_MAX)];
            self.size = textViewSize;
            break;
        }
        case 2:
        {
            //image
            if ([_contentDict objectForKey:@"image"]) {
                self.image = [_contentDict objectForKey:@"image"];
            }
            CGFloat h = self.image.size.height;
            CGFloat w = self.image.size.width;
            CGFloat kMaxChatImageViewWidth = PhoneScreen_WIDTH - 130;
            CGFloat kMaxChatImageViewHeight = 200;
            CGFloat standardWidthHeightRatio = kMaxChatImageViewWidth / kMaxChatImageViewHeight;
            if (w > kMaxChatImageViewWidth || w > kMaxChatImageViewHeight) {
                
                CGFloat widthHeightRatio = w / h;
                
                if (widthHeightRatio > standardWidthHeightRatio) {
                    w = kMaxChatImageViewWidth;
                    h = w * (self.image.size.height / self.image.size.width);
                } else {
                    h = kMaxChatImageViewHeight;
                    w = h * widthHeightRatio;
                }
            }
            
            self.size = CGSizeMake(w, h);
            break;
        }
        case 3:
        {
            //voice
            if ([_contentDict objectForKey:@"voiceLength"]) {
                self.voiceLength = [[_contentDict objectForKey:@"voiceLength"] doubleValue];
                CGFloat width = self.voiceLength / (PhoneScreen_WIDTH - 130);
                self.size = CGSizeMake(width, 80);
//                NSLog(@"self.size %@", NSStringFromCGSize(self.size));
                break;
            }
        }
        default:
            break;
    }
}

//- (CGSize)contentSize
//{
//    return self.size;
//}

@end
