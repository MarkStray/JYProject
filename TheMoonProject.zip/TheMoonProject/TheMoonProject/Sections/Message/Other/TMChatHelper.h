//
//  TMChatHelper.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/29.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface TMChatHelper : NSObject

@property (nonatomic, copy) NSString *messageId;

@property (nonatomic, assign) BOOL isMe;

@property (nonatomic, assign) NSUInteger messageType;

@property (nonatomic, assign) CGSize size;

@property (nonatomic, assign) BOOL isShowTime;

@property (nonatomic, copy) NSDictionary *contentDict;

@property (nonatomic, strong) NSAttributedString *contentText;

@property (nonatomic, strong) UIImage *image;

@property (nonatomic, assign) double voiceLength;

@property (nonatomic, copy) NSString *voicePath;

- (instancetype)initWithMessageObject:(NSDictionary *)contentDict andTextView:(UITextView *)tempTextView messageType:(NSUInteger) messageType;

@end
