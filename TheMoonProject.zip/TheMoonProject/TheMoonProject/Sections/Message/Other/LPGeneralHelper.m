//
//  LPGeneralHelper.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "LPGeneralHelper.h"
#import <UIKit/UIKit.h>
@implementation LPGeneralHelper

+ (NSAttributedString *) attributedStringWithText:(NSString *)str
{
    //    if (str) {
    //        return [[NSAttributedString alloc] initWithString:@""];
    //    }
    NSMutableParagraphStyle *paragraphStyle = [[NSMutableParagraphStyle alloc] init];
    paragraphStyle.lineSpacing = 3;
    NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:str attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17.f], NSParagraphStyleAttributeName:paragraphStyle}];
    
    
    //    NSString *file = [[NSBundle mainBundle] pathForResource:@"faceList" ofType:@"plist"];
    //    [[NSArray alloc] initWithContentsOfFile:file];
    NSArray *arrEmoji = [self getEmojiArray];
    //正则匹配要替换的文字的范围
    //正则表达式
    NSString * pattern = @"\\[[a-zA-Z0-9\\u4e00-\\u9fa5]+\\]";
    NSError *error = nil;
    NSRegularExpression * re = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:&error];
    
    if (!re) {
        //        NSLog(@"%@", [error localizedDescription]);
    }
    
    //通过正则表达式来匹配字符串
    NSArray *resultArray = [re matchesInString:str options:0 range:NSMakeRange(0, str.length)];
    //    NSLog(@"resultArray : %@", resultArray);
    
    //用来存放字典，字典中存储的是图片和图片对应的位置
    NSMutableArray *imageArray = [NSMutableArray arrayWithCapacity:resultArray.count];
    
    for(NSTextCheckingResult *match in resultArray) {
        //获取数组元素中得到range
        NSRange range = [match range];
        
        //获取原字符串中对应的值
        NSString *subStr = [str substringWithRange:range];
        
        for (int i = 0; i < arrEmoji.count; i ++)
        {
            if ([arrEmoji[i][@"chs"] isEqualToString:subStr])
            {
                
                //face[i][@"gif"]就是我们要加载的图片
                //新建文字附件来存放我们的图片
                                NSTextAttachment *textAttachment = [[NSTextAttachment alloc] init];
//                ACNSTextAttachment* textAttachment = [[ACNSTextAttachment alloc]init];
                
                //                    CGFloat n = 25/12;
                textAttachment.bounds = CGRectMake(textAttachment.bounds.origin.x, textAttachment.bounds.origin.y - 5, 25, 25);
                
                //给附件添加图片
                textAttachment.image = [UIImage imageNamed:arrEmoji[i][@"png"]];
                
                //把附件转换成可变字符串，用于替换掉源字符串中的表情文字
                NSAttributedString *imageStr = [NSAttributedString attributedStringWithAttachment:textAttachment];
                
                //把图片和图片对应的位置存入字典中
                NSMutableDictionary *imageDic = [NSMutableDictionary dictionaryWithCapacity:2];
                [imageDic setObject:imageStr forKey:@"image"];
                [imageDic setObject:[NSValue valueWithRange:range] forKey:@"range"];
                
                //把字典存入数组中
                [imageArray addObject:imageDic];
                
            }
        }
    }
    
    //从后往前替换
    for (NSInteger i = imageArray.count - 1; i >= 0; i--)
    {
        NSRange range;
        [imageArray[i][@"range"] getValue:&range];
        //进行替换
        [attributedString replaceCharactersInRange:range withAttributedString:imageArray[i][@"image"]];
        
    }
    //    [attributedString addAttributes:@{NSFontAttributeName:[UIFont systemFontOfSize:17.f]} range:NSMakeRange(0, attributedString.length)];
    //    NSAttributedString *att = [NSAttributedString alloc] initWithString:<#(NSString *)#> attributes:<#(NSDictionary *)#>
    return attributedString;
}

#pragma mark 获取自定义表情字符串数组
+ (NSArray *) getEmojiArray
{
    NSString *file = [[NSBundle mainBundle] pathForResource:@"faceList" ofType:@"plist"];
    return [[NSArray alloc] initWithContentsOfFile:file];
}
/**
 *  删除自定义表情键盘上表情字符串的操作
 *
 *  @param textView   传入textView，处理textView当前光标下删除自定义表情字符串
 *  @param faceArray  faceArray 为从plist文件读取到的表情字符串数组
 *  @param complement complement 方法执行完成的回调
 */
+ (void) deleteFaceStringWithTextView:(UITextView *)textView andFaceArray:(NSArray *)faceArray complement:(void(^)()) complement
{
    NSString *souceText = textView.text;
    NSRange range = textView.selectedRange;
    
    
    if (range.location == NSNotFound) {
        range.location = textView.text.length;
    }
    if (range.length > 0) {
        [textView deleteBackward];
        return;
    }else
    {
        
        
        //正则匹配要替换的文字的范围
        //正则表达式
        NSString * pattern = @"\\[[a-zA-Z0-9\\u4e00-\\u9fa5]+\\]";
        NSError *error = nil;
        NSRegularExpression * re = [NSRegularExpression regularExpressionWithPattern:pattern options:NSRegularExpressionCaseInsensitive error:&error];
        
        if (!re) {
            NSLog(@"%@", [error localizedDescription]);
        }
        
        //通过正则表达式来匹配字符串
        NSArray *resultArray = [re matchesInString:souceText options:0 range:NSMakeRange(0, souceText.length)];
        NSTextCheckingResult *checkingResult = resultArray.lastObject;
        
        for (NSDictionary *faceDict in faceArray) {
            NSString *faceName = faceDict[@"chs"];
            
            if ([souceText hasSuffix:@"]"]) {
                
                if ([[souceText substringWithRange:checkingResult.range] isEqualToString:faceName]) {
                    NSLog(@"faceName %@", faceName);
                    NSString *newText = [souceText substringToIndex:souceText.length - checkingResult.range.length];
                    textView.text = newText;
                    !complement ?: complement();
//                    [self resetToolViewHeight:textView.contentSize.height];
                    return;
                }
                
            }else
            {
                [textView deleteBackward];
                return;
            }
            
        }
        
        
    }
}


+ (void)countDownWithTime:(int)time
           countDownBlock:(void (^)(int timeLeft))countDownBlock
                 endBlock:(void (^)())endBlock
{
    __block int timeout = time; //倒计时时间
    dispatch_queue_t queue = dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0);
    dispatch_source_t _timer = dispatch_source_create(DISPATCH_SOURCE_TYPE_TIMER, 0, 0,queue);
    dispatch_source_set_timer(_timer,dispatch_walltime(NULL, 0),1.0*NSEC_PER_SEC, 0); //每秒执行
    dispatch_source_set_event_handler(_timer, ^{
        if(timeout<=0){ //倒计时结束，关闭
            dispatch_source_cancel(_timer);
            dispatch_async(dispatch_get_main_queue(), ^{
                if (endBlock) {
                    endBlock();
                }
            });
        } else {
            dispatch_async(dispatch_get_main_queue(), ^{
                timeout--;
                if (countDownBlock) {
                    countDownBlock(timeout);
                }
            });
        }
    });
    dispatch_resume(_timer);
}
@end
