//
//  TMMessageViewController.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/11.
//  Copyright © 2016年 moon. All rights reserved.
//

//                            _ooOoo_
//                           o8888888o
//                           88" . "88
//                           (| -_- |)
//                            O\ = /O
//                        ____/`---'\____
//                      .   ' \\| |// `.
//                       / \\||| : |||// \
//                     / _||||| -:- |||||- \
//                       | | \\\ - /// | |
//                     | \_| ''\---/'' | |
//                      \ .-\__ `-` ___/-. /
//                   ___`. .' /--.--\ `. . __
//                ."" '< `.___\_<|>_/___.' >'"".
//               | | : `- \`.;`\ _ /`;.`/ - ` : | |
//                 \ \ `-. \_ __\ /__ _/ .-` / /
//         ======`-.____`-.___\_____/___.-`____.-'======
//                            `=---='
//
//         .............................................
//                  佛祖镇楼                  BUG辟易
//          佛曰:
//                  写字楼里写字间，写字间里程序员；
//                  程序人员写程序，又拿程序换酒钱。
//                  酒醒只在网上坐，酒醉还来网下眠；
//                  酒醉酒醒日复日，网上网下年复年。
//                  但愿老死电脑间，不愿鞠躬老板前；
//                  奔驰宝马贵者趣，公交自行程序员。
//                  别人笑我忒疯癫，我笑自己命太贱；
//                  不见满街漂亮妹，哪个归得程序员？

#import "TMMessageViewController.h"
#import "TMChatViewController.h"
#import "UIViewExt.h"
#import "TMMessageTableViewCell.h"
#import "UIImageView+WebCache.h"

@interface TMMessageViewController ()<UITableViewDelegate, UITableViewDataSource>

//@property (nonatomic, strong) UITableView *tableView;
@property (weak, nonatomic) IBOutlet UITableView *tableView;

@end

@implementation TMMessageViewController
{
    NSMutableArray *dialogs;
}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    [self.tableView deselectRowAtIndexPath:self.tableView.indexPathForSelectedRow animated:YES];
    dialogs = [NSMutableArray array];
    for (NSInteger i = 0; i < 5; i ++) {
        [dialogs addObject:@(i)];
    }
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.edgesForExtendedLayout = UIRectEdgeNone;
    self.view.backgroundColor = [UIColor groupTableViewBackgroundColor];
    [_tableView registerNib:[UINib nibWithNibName:@"TMMessageTableViewCell" bundle:nil] forCellReuseIdentifier:@"Message"];;
    _tableView.rowHeight = 65;
    self.tableView.tableFooterView = [UIView new];
    [self toChat:nil];
}

//- (UITableView *)tableView
//{
//    NSLog(@"%f", self.view.frame.size.width);
//    CGRect frame = CGRectMake(0, 0, self.view.frame.size.width, CGRectGetHeight(self.view.bounds));
////    _tableView = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
////    _tableView.height = CGRectGetHeight(self.view.frame) - [UIApplication sharedApplication].statusBarFrame.size.height - self.navigationController.navigationBar.bounds.size.height - self.tabBarController.tabBar.bounds.size.height - 30;
////    _tableView.delegate = self; _tableView.dataSource = self;
//    
////    _tableView.rowHeight = 60;
//    return _tableView;
//}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)toChat:(id)sender {
    TMChatViewController *chat = [[TMChatViewController alloc] init];
    [self.navigationController pushViewController:chat animated:YES];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return dialogs.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TMMessageTableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:@"Message" forIndexPath:indexPath];
    [cell.imgCover sd_setImageWithURL:[NSURL URLWithString:@"https://pic1.zhimg.com/9e6e0d88755ca6f92380ef683d15a618_b.jpg"]];
//    cell.imgCover.image = [UIImage imageNamed:@"home_select"];
//    cell.textLabel.text = [NSString stringWithFormat:@"%ld", (long)indexPath.row];
    
    cell.imgCover.contentMode = UIViewContentModeScaleAspectFill;
    cell.imgCover.clipsToBounds = YES;
    cell.imgCover.autoresizesSubviews = UIViewAutoresizingFlexibleHeight | UIViewAutoresizingFlexibleWidth;
    return cell;
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView beginUpdates];
    
    [dialogs removeObjectAtIndex:indexPath.row];
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];
    
    [tableView endUpdates];
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [self toChat:nil];
}

@end
