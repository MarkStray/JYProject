//
//  TMChatViewController.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/11.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMChatViewController.h"
#import "TMTextMessageTableViewCell.h"
#import "TMVoiceMessageTableViewCell.h"
#import "TMPhotoMessageTableViewCell.h"
#import "LPGeneralHelper.h"
#import "ACFaceView.h"
#import "TMRecordView.h"
#import "TMChatHelper.h"
#import "AppDelegate.h"
#import "MWPhotoBrowser.h"
#import "TMBaseNavigationController.h"

@interface TMChatViewController ()<UITableViewDataSource, UITableViewDelegate, UITextViewDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate, MWPhotoBrowserDelegate>
@property (weak, nonatomic) IBOutlet UITableView *tableView;
@property (weak, nonatomic) IBOutlet UIButton *btnSend;
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet UIView *customAccessoryView;//聊天工具栏
@property (weak, nonatomic) IBOutlet UIView *toolView;//聊天工具栏
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *customAccessoryViewLC;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *customAccessoryViewLCBottom;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *customContentViewLCHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *tableViewLCBottom;

@property (nonatomic, strong) ACFaceView *faceView;
@property (nonatomic, strong) TMRecordView *recordView;
@property (nonatomic, strong) UIView *recordHeaderView;
@property (nonatomic, strong) UIView *tableHeaderView;
@property (nonatomic, strong) UIActivityIndicatorView *loadPastActivityView;
@end

@implementation TMChatViewController
{
    NSMutableArray *messages;//当前消息数组
    NSMutableArray *itemButtons;//聊天工具栏按钮数组
    NSArray *itemIcons;//聊天工具栏按钮图片数组
    CGFloat keyboardHeight;//键盘高度
    double keyboardAnimationDuration;//键盘弹出时长
    NSUInteger keyboardAnimationCurve;//键盘动画弧度
    NSString *testText;//测试文本
    UITextView *tempTextView;//模型 用于处理cell字符串size计算
    NSAttributedString *attributedString;//富文本字符串
    UIView *chatToolView;//toolview:voice face camera album
    BOOL isShowingFaceView;//是否正在显示表情视图
    BOOL isShowingRecordView;//是否正在显示录音视图
    NSMutableArray *browserPhotos;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self.navigationController.navigationBar setTintColor:[UIColor whiteColor]];
    self.view.backgroundColor = RGBCOLOR(245, 246, 247, 1);
    self.tableView.backgroundColor = RGBCOLOR(245, 246, 247, 1);
    self.tableView.rowHeight = UITableViewAutomaticDimension;
    self.textView.layer.borderColor = RGBCOLOR(219, 219, 219, 1).CGColor;
    self.textView.layer.borderWidth = 1;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
//    [self.tableView registerClass:[TMVoiceMessageTableViewCell class] forCellReuseIdentifier:@"VoiceCell"];
    testText = @"😡😡😡😡接下来，你需要搜集合适的投资者。注意，13162396780你需要把这份名单匹配基金，这只会浪费你的时间。";//你的投资者名单还需要反复的推敲，😡😡😡😡😡😡😡😡😡😡😡😡😡😡😡😡如果你想要了解更多信息，可以在 Crun投资者。注意，你需要把这份名单匹配那些曾经投资过相关领域的投资人，因😡😡😡😡😡😡😡为他们了解这一领域可能达到的体量。如果你需要一笔 20 万美金的种子轮投资，别找成长性基金，这只会浪费你的时间。你的投资者名单还需要反复的推敲，如果你想要了解更多信息，可以在 Crunchbase 和 AngelList 这两个平台上搜罗试试。在确定了目标投资者之后，你最好能找到人帮忙引荐。😡😡😡😡😡😡😡😡😡😡😡😡😡😡😡你需要把这份名单匹配那些曾经投资过相关领域的投资人，因😡😡😡😡😡😡😡为他们了解这一领域可能达到想要了解更多信息，你需要把这份名单匹配那些曾经投资过相关领域的投资人，因😡😡😡😡😡😡😡为他们了解这一领域可能达到的体量。如果你需要一笔 20";
    tempTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, PhoneScreen_WIDTH - 130, 40)];
    tempTextView.font = [UIFont systemFontOfSize:17.f];
    attributedString = [LPGeneralHelper attributedStringWithText:testText];
    tempTextView.attributedText = attributedString;
//    CGSize textViewSize = [tempTextView sizeThatFits:CGSizeMake(tempTextView.bounds.size.width, CGFLOAT_MAX)];
//    tempTextView.frame = CGRectMake(0, 0, textViewSize.width, textViewSize.height);
//    
    itemIcons = @[@"chat_tool_voice", @"chat_tool_face", @"chat_tool_album", @"chat_tool_camera"];
    messages = [NSMutableArray array];
    for (NSInteger i = 0; i < 5; i ++) {
        
        TMChatHelper *cp = [[TMChatHelper alloc] initWithMessageObject:@{@"voiceLength":@"10"} andTextView:tempTextView messageType:1];
        cp.messageId = [NSUUID UUID].UUIDString;
        cp.isMe = (i % 2 == 0);
        cp.isShowTime = (i % 2 != 0);
        cp.contentText = [LPGeneralHelper attributedStringWithText:testText];
        [messages addObject:cp];
    }
    [self.tableView reloadData];
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tableViewTapped:)];
    [self.tableView addGestureRecognizer:tap];
    
    keyboardAnimationDuration = 0.25;
    keyboardAnimationCurve = 7;
    [self addToolSubviews];
    [self addFaceView];
    [self addRecordView];
//    [self scrollToFootOfTable:self.tableView animated:NO];
    [self addTableHeaderView];
    //录音时背面的灰色视图
    self.recordHeaderView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, PhoneScreen_WIDTH, PhoneScreen_HEIGHT - RecordViewHeight)];
    self.recordHeaderView.backgroundColor = [UIColor grayColor];
    self.recordHeaderView.alpha = 0.6;
    AppDelegate *ad = (AppDelegate *)[UIApplication sharedApplication].delegate;
    [ad.window addSubview:self.recordHeaderView];
    self.recordHeaderView.hidden = YES;
}

- (void) tableViewTapped:(UITapGestureRecognizer *)tap
{
    if (self.textView.isFirstResponder) {
        [self.textView resignFirstResponder];
        return;
    }
    if (isShowingFaceView) {
        isShowingFaceView = NO;
        [self showFaceView:isShowingFaceView];
        [self changeAssessoryViewFrameWithConstant:0 tableScrollToFoot:YES];
        return;
    }
    if (isShowingRecordView) {
        isShowingRecordView = NO;
        [self showRecordView:isShowingRecordView];
        [self changeAssessoryViewFrameWithConstant:0 tableScrollToFoot:YES];
    }
}


- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillShowNotification:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillHideNotification:) name:UIKeyboardWillHideNotification object:nil];
}

- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] removeObserver:self name:UIKeyboardWillHideNotification object:nil];
}

- (void) keyboardWillShowNotification:(NSNotification *)notification
{
    keyboardAnimationDuration = [[[notification userInfo] objectForKey:UIKeyboardAnimationDurationUserInfoKey] doubleValue];
    keyboardAnimationCurve = [[[notification userInfo] objectForKey:UIKeyboardAnimationCurveUserInfoKey] unsignedIntegerValue];
    NSValue *keyboardBoundsValue = [[notification userInfo] objectForKey:UIKeyboardFrameEndUserInfoKey];
    keyboardHeight = [keyboardBoundsValue CGRectValue].size.height;
    NSLog(@"keyboardAnimationDuration %f %lu %f", keyboardAnimationDuration, (unsigned long)keyboardAnimationCurve, keyboardHeight);
    [self changeAssessoryViewFrameWithConstant:keyboardHeight tableScrollToFoot:YES];
}

- (void) keyboardWillHideNotification:(NSNotification *)notification
{
    [self changeAssessoryViewFrameWithConstant:0 tableScrollToFoot:NO];
}

#pragma mark 添加工具栏四个按钮
- (void) addToolSubviews
{
    self.toolView.backgroundColor = [UIColor clearColor];
    itemButtons = [NSMutableArray arrayWithCapacity:itemIcons.count];
    for (NSUInteger i = 0; i < itemIcons.count; i ++) {
        
        UIView *rectangleView = [[UIView alloc] init];
        rectangleView.frame = CGRectMake((PhoneScreen_WIDTH/ 4) * i, - 5, PhoneScreen_WIDTH / 4, 36);
        rectangleView.backgroundColor = [UIColor clearColor];
        [self.toolView addSubview:rectangleView];
        
        UIButton *itemButton = [UIButton buttonWithType:UIButtonTypeCustom];
        itemButton.frame = CGRectMake(0, 0, 26, 26);
        NSString *imageNameNormal = [NSString stringWithFormat:@"%@_normal", itemIcons[i]];
        NSString *imageNameSelect = [NSString stringWithFormat:@"%@_select", itemIcons[i]];
        [itemButton setBackgroundImage:[UIImage imageNamed:imageNameNormal] forState:UIControlStateNormal];
        [itemButton setBackgroundImage:[UIImage imageNamed:imageNameSelect] forState:UIControlStateHighlighted];
        [itemButton setBackgroundImage:[UIImage imageNamed:imageNameSelect] forState:UIControlStateSelected];
        [rectangleView addSubview:itemButton];
        itemButton.tag = i;
        [itemButton addTarget:self action:@selector(itemButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [itemButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.center.equalTo(rectangleView);
            make.size.mas_equalTo(26);
        }];
        [itemButtons addObject:itemButton];
    }
}

- (void)addTableHeaderView
{
    self.tableHeaderView = [[UIView alloc] init];
    self.tableView.tableHeaderView = self.tableHeaderView;
    self.tableHeaderView.backgroundColor = self.tableView.backgroundColor;
    [self.tableHeaderView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.equalTo(self.tableView);
        make.height.mas_equalTo(30);
        make.leading.trailing.equalTo(self.tableView);
    }];
    self.loadPastActivityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [self.tableHeaderView addSubview:self.loadPastActivityView];
    [self.loadPastActivityView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.width.height.mas_equalTo(25);
        make.centerX.centerY.equalTo(self.tableHeaderView);
    }];
    
}

static CGFloat const FaceViewHeight = 216 - 44;
#pragma mark 添加表情键盘
- (void)addFaceView
{
    __weak typeof(self) weakSelf = self;
#pragma mark faceView
    self.faceView = [[ACFaceView alloc] init];
    self.faceView.frame = CGRectMake(0, PhoneScreen_HEIGHT, PhoneScreen_WIDTH, FaceViewHeight);
    self.faceView.backgroundColor = [UIColor clearColor];
    [self.view addSubview:self.faceView];
//    [self.faceView mas_makeConstraints:^(MASConstraintMaker *make) {
//        make.bottom.equalTo(self.view);
//        make.leading.equalTo(self.view);
//        make.trailing.equalTo(self.view);
//        make.height.mas_equalTo(FaceViewHeight);
//    }];
//    [self.faceView mas_updateConstraints:^(MASConstraintMaker *make) {
//        make.height.mas_equalTo(CGFLOAT_MIN);
//    }];
#pragma mark 点击默认表情回调
    self.faceView.clickFaceBlock = ^(id faceObject)
    {
        //        NSLog(@"faceObject:%@", faceObject);
        NSString *faceText = faceObject;
        NSMutableString *mutableText = [[NSMutableString alloc] initWithString:weakSelf.textView.text];
//        //光标
        NSRange range = weakSelf.textView.selectedRange;
        if (range.location == NSNotFound) {
            range.location = weakSelf.textView.text.length;
        }
        [mutableText insertString:faceText atIndex:range.location];
        weakSelf.textView.text = mutableText;
//        weakSelf.textView.attributedText = [LPGeneralHelper attributedStringWithText:weakSelf.textView.text];
        weakSelf.textView.selectedRange = NSMakeRange(range.location + faceText.length, 0);
        [weakSelf resetTextViewHeightWithTextView:weakSelf.textView];
    };
#pragma mark 删除表情回调
     NSArray *arrEmoji = [LPGeneralHelper getEmojiArray];
    self.faceView.deleteFaceBlock = ^(id faceObject)
    {
        [LPGeneralHelper deleteFaceStringWithTextView:weakSelf.textView andFaceArray:arrEmoji complement:^{
            [weakSelf resetTextViewHeightWithTextView:weakSelf.textView];
//            NSLog(@"%f", weakSelf.textView.contentSize.height);
        }];
    };
}
static CGFloat const RecordViewHeight = 185;
- (void)addRecordView
{
    self.recordView = [[TMRecordView alloc] init];
    [self.view addSubview:self.recordView];
    [self.recordView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.view);
        make.height.mas_equalTo(RecordViewHeight);
        make.bottom.mas_equalTo(self.view.bottom + RecordViewHeight);
    }];
    __weak typeof(self) weakSelf = self;
    self.recordView.recordingStartBlock = ^(BOOL isStop)
    {
        weakSelf.recordHeaderView.hidden = isStop;
    };
    self.recordView.recordingStopBlock = ^(BOOL isStop, NSString *filePath)
    {
        if (!isStop) {
            return;
        }
        [weakSelf sendVoiceMessageWithPath:filePath];
    };
}

- (void) sendVoiceMessageWithPath:(NSString *)filePath
{
    [self.tableView beginUpdates];
    TMChatHelper *ch = [[TMChatHelper alloc] initWithMessageObject:@{@"voiceLength":@"10"} andTextView:tempTextView messageType:3];
    ch.messageId = [NSUUID UUID].UUIDString;
    ch.isMe = (int)(0 + (arc4random() % (1 - 0 + 1)));
    ch.isShowTime = YES;
    ch.voicePath = filePath;
    [messages addObject:ch];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:messages.count - 1 inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationTop];
    [self.tableView endUpdates];
    [self scrollToFootOfTable:self.tableView animated:YES];
}


//#pragma mark 发送默认表情回调
//self.faceView.sendFaceBlock = ^()
//{
//    if (weakSelf.toolView.textView.text.length > 0 && [weakSelf.toolView.textView.text stringByReplacingOccurrencesOfString:@" " withString:@""].length > 0) {
//        [weakSelf sendMessageWithText:weakSelf.toolView.textView.text];
//        weakSelf.toolView.textView.text = nil;
//        
//        weakSelf.toolView.height = tool_height;
//        [weakSelf animationWithBlock:^{
//            
//            weakSelf.toolView.textView.height = weakSelf.toolView.height - 10;
//            weakSelf.toolView.bottom = PhoneScreen_HEIGHT - weakSelf.keyboardHeight - nav_height;
//            weakSelf.tableView.height = PhoneScreen_HEIGHT - weakSelf.toolView.height - weakSelf.keyboardHeight - weakSelf.tableView.top - nav_height;
//        }];
//    }
//    
//};
//

#pragma mark 底部工具栏四个按钮点击事件
- (IBAction)itemButtonClicked:(UIButton *)sender
{
    
    [self.textView resignFirstResponder];
    NSUInteger tag = sender.tag;
    if (tag < 2) {
        sender.selected = !sender.selected;
    }
    if (tag == 0) {
        isShowingRecordView = !isShowingRecordView;
        [self showRecordView:isShowingRecordView];
        isShowingFaceView = NO;
        [self showFaceView:isShowingFaceView];
        [self changeAssessoryViewFrameWithConstant:isShowingRecordView ? RecordViewHeight : 0 tableScrollToFoot:YES];
        [self scrollToFootOfTable:self.tableView animated:YES];
//        [self scrollToFootOfTable:self.tableView animated:YES];
//        !isShowingRecordView ?: [self scrollToFootOfTable:self.tableView animated:YES];
    }else if (tag == 1)
    {
        isShowingFaceView = !isShowingFaceView;
        [self showFaceView:isShowingFaceView];
        
        isShowingRecordView = NO;
        [self showRecordView:isShowingRecordView];
//        if (isShowingFaceView) {
//            [self scrollToFootOfTable:self.tableView animated:YES];
//        }
        [self changeAssessoryViewFrameWithConstant:isShowingFaceView ? FaceViewHeight : 0 tableScrollToFoot:YES];
        [self scrollToFootOfTable:self.tableView animated:YES];
//        !isShowingFaceView ?: [self scrollToFootOfTable:self.tableView animated:YES];
        
    }else if (tag == 2)
    {
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        imagePicker.allowsEditing = YES;
        imagePicker.delegate = self;
        [self.navigationController presentViewController:imagePicker animated:YES completion:^{
            
        }];
    }else if (tag == 3)
    {
        UIImagePickerController *imagePicker = [[UIImagePickerController alloc] init];
        imagePicker.sourceType = [UIImagePickerController isSourceTypeAvailable:UIImagePickerControllerSourceTypeCamera] ? UIImagePickerControllerSourceTypeCamera : UIImagePickerControllerSourceTypePhotoLibrary;
        imagePicker.allowsEditing = YES;
        imagePicker.delegate = self;
        [self.navigationController presentViewController:imagePicker animated:YES completion:^{
            
        }];
    }
}

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    NSLog(@"%@", info);
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    [picker dismissViewControllerAnimated:YES completion:^{
        
    }];
    
    self.customContentViewLCHeight.constant = 84;
    //    [self changeAssessoryViewFrameWithConstant:84 tableScrollToFoot:NO];
    
    [self.tableView beginUpdates];
    tempTextView.attributedText = [LPGeneralHelper attributedStringWithText:self.textView.text];
    TMChatHelper *ch = [[TMChatHelper alloc] initWithMessageObject:@{@"image":image} andTextView:tempTextView messageType:2];
    ch.messageId = [NSUUID UUID].UUIDString;
    ch.isMe = (int)(0 + (arc4random() % (1 - 0 + 1)));
    ch.isShowTime = YES;
    ch.image = image;
//    ch.contentText = [LPGeneralHelper attributedStringWithText:self.textView.text];
    
    //    NSInteger obj = messages.count + 1;
    [messages addObject:ch];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:messages.count - 1 inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationBottom];
    [self.tableView endUpdates];
    dispatch_async(dispatch_get_main_queue(), ^{
        [self scrollToFootOfTable:self.tableView animated:NO];
    });
//    self.textView.text = nil;
    //    [self.tableView scrollToRowAtIndexPath:indexPath atScrollPosition:UITableViewScrollPositionBottom animated:NO];
//    [self scrollToFootOfTable:self.tableView animated:NO];
    //    [self scrollToFootOfTable:self.tableView animated:NO];
}

#pragma mark 是否展示表情视图
- (void) showFaceView:(BOOL)show
{
    UIButton *itemButton = itemButtons[1];
    itemButton.selected = show;
    [UIView beginAnimations:@"ChangeFace" context:nil];
    [UIView setAnimationDuration:keyboardAnimationDuration];
    [UIView setAnimationCurve:keyboardAnimationCurve];
    self.faceView.top = show ? self.view.frame.size.height - FaceViewHeight: PhoneScreen_HEIGHT;
    [UIView commitAnimations];
}
#pragma mark 是否展示录音视图
- (void) showRecordView:(BOOL)show
{
    UIButton *itemButton = itemButtons[0];
    itemButton.selected = show;
    [self.recordView mas_updateConstraints:^(MASConstraintMaker *make) {
        make.leading.trailing.equalTo(self.view);
        make.height.mas_equalTo(RecordViewHeight);
        make.bottom.equalTo(self.view).offset(show ? 0 : RecordViewHeight);
    }];
    [UIView animateWithDuration:keyboardAnimationDuration delay:0 usingSpringWithDamping:5 initialSpringVelocity:5 options:UIViewAnimationOptionAllowAnimatedContent animations:^{
        [self.view layoutIfNeeded];
    } completion:^(BOOL finished) {
        
    }];
}

#pragma mark tableview 滚动到底部

- (void)scrollToFootOfTable:(UITableView *)tableView animated:(BOOL)animated {
    NSInteger s = [tableView numberOfSections];
    if (s<1) return;
    NSInteger r = [tableView numberOfRowsInSection:s-1];
    if (r<1) return;
    
    NSIndexPath *ip = [NSIndexPath indexPathForRow:r-1 inSection:s-1];
    
    [tableView scrollToRowAtIndexPath:ip atScrollPosition:UITableViewScrollPositionBottom animated:animated];
}
#pragma mark 改变输入框视图距离self.view的底部的距离 scroll:是否执行tableview滚动到底部
- (void) changeAssessoryViewFrameWithConstant:(CGFloat)constant tableScrollToFoot:(BOOL)scorll
{
//    [self.view layoutIfNeeded];
    [UIView beginAnimations:@"ChangeFrame" context:nil];
    [UIView setAnimationDuration:keyboardAnimationDuration];
    [UIView setAnimationCurve:keyboardAnimationCurve];
    
    self.customAccessoryViewLC.constant = constant;
    
    if (scorll) {
//        [self scrollToFootOfTable:self.tableView animated:scorll];
    }
    [self.view layoutIfNeeded];
    [UIView commitAnimations];
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return messages.count;
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    TMChatHelper *ch = messages[indexPath.row];
    
    if (ch.messageType == 1) {
        //textcell height
        return ch.size.height + 50;
    }else if (ch.messageType == 2)
    {
        return ch.size.height + 50;
    }
    
    return 80;
//    CGFloat textHeight = ceil(textViewSize.height) + (indexPath.row % 2 == 0 ? 60 : 40);//: 15);
//    return textHeight;
//    return 80;
//    if (indexPath.row == 0)
//        return 200;//image.size.height;
////    voice height
//    return indexPath.row > 3 ? textHeight : 80;
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    __weak typeof(self) weakSelf = self;
    TMChatHelper *ch = messages[indexPath.row];
    switch (ch.messageType) {
        case 1:
            //text
        {
            TMTextMessageTableViewCell *textCell = [tableView dequeueReusableCellWithIdentifier:[NSString stringWithFormat:@"TextCell%@", [NSUUID UUID].UUIDString]];
            if (!textCell) {
                textCell = [[TMTextMessageTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:[NSString stringWithFormat:@"TextCell%@", [NSUUID UUID].UUIDString]];
            }
            textCell.contentTextView.attributedText = ch.contentText;
            textCell.chatHelper = ch;
            textCell.messageAvatarTapBlock = ^(BOOL flag)
            {
                NSLog(@"avatar tap");
            };
            textCell.messageDeleteBlock = ^ (BOOL enable)
            {
                [weakSelf deleteMessageCellAction:ch.messageId];
            };
            [textCell layoutSubviews];
            return textCell;
//            break;
        }
        case 2:
        {
            TMPhotoMessageTableViewCell *photoCell = [tableView dequeueReusableCellWithIdentifier:[NSString stringWithFormat:@"PhotoCell%@", [NSUUID UUID].UUIDString]];
            if (!photoCell) {
                photoCell = [[TMPhotoMessageTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:[NSString stringWithFormat:@"PhotoCell%@", [NSUUID UUID].UUIDString]];
            }
            photoCell.chatHelper = ch;
            photoCell.messageAvatarTapBlock = ^(BOOL flag)
            {
                NSLog(@"avatar tap");
            };
            photoCell.messageDeleteBlock = ^(BOOL enable)
            {
                [weakSelf deleteMessageCellAction:ch.messageId];
            };
//            __weak typeof(TMPhotoMessageTableViewCell) weakPhotoCell = photoCell;
//            __block typeof(photoCell) blockPhotoCell = photoCell;
            photoCell.messageBubbleTapBlock = ^(TMChatHelper *ch1)
            {
                [TMPhotoMessageTableViewCell setMenuControllerAvaible:NO animated:NO];
                [self photoMessageCellAction:ch];
            };
            [photoCell layoutSubviews];
            return photoCell;
//            break;
        }
        case 3:
        {
            
            TMVoiceMessageTableViewCell *voiceCell = [tableView dequeueReusableCellWithIdentifier:[NSString stringWithFormat:@"VoiceCell%@", [NSUUID UUID].UUIDString]];
            if (!voiceCell) {
                voiceCell = [[TMVoiceMessageTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:[NSString stringWithFormat:@"VoiceCell%@", [NSUUID UUID].UUIDString]];
            }
            voiceCell.chatHelper = ch;
            voiceCell.messageAvatarTapBlock = ^(BOOL flag)
            {
                NSLog(@"avatar tap");
            };
            voiceCell.messageDeleteBlock = ^(BOOL enable)
            {
                [weakSelf deleteMessageCellAction:ch.messageId];
            };
            voiceCell.messageBubbleTapBlock = ^(TMChatHelper *ch1)
            {
                [[PlayerManager sharedManager] playAudioWithFileName:ch.voicePath];
            };
            [voiceCell layoutSubviews];
            return voiceCell;
//            break;
        }
    }
//    if (indexPath.row == 0) {
//        TMPhotoMessageTableViewCell *photoCell = [[TMPhotoMessageTableViewCell alloc] init];
//        [photoCell setNeedsLayout];
//        return photoCell;
//    }else if (indexPath.row > 3) {
        //text
//        TMTextMessageTableViewCell *textCell = [[TMTextMessageTableViewCell alloc] init];
//        textCell.contentTextView.attributedText = attributedString;
//        CGSize textSize = [tempTextView sizeThatFits:CGSizeMake(tempTextView.bounds.size.width, CGFLOAT_MAX)];
//        [textCell changeContentSize:textSize];
//        return textCell;
//    }else
//    {
//        //voice
//    TMVoiceMessageTableViewCell *voiceCell = [tableView dequeueReusableCellWithIdentifier:@"Voice"];
//    if (!voiceCell) {
//        voiceCell = [[TMVoiceMessageTableViewCell alloc] init];
//    }
    
//        [voiceCell setNeedsLayout];
    
    
    
//        return voiceCell;
//    }
    return nil;
}
#pragma mark 下拉加载历史数据操作
-(void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    if (scrollView.contentOffset.y <= 0) {
        
        if (!self.loadPastActivityView.isAnimating) {
            NSLog(@"111");
            [self.loadPastActivityView startAnimating];
            [self performSelector:@selector(loadMessageWithPage:) withObject:0 afterDelay:2];
        }
    }
//    NSIndexPath *path =  [self.tableView indexPathForRowAtPoint:CGPointMake(scrollView.contentOffset.x, scrollView.contentOffset.y)];
//    
//    NSLog(@"这是第%li行",(long)path.row);
//    if (isShowingFaceView) {
//        isShowingFaceView = NO;
//        [self showFaceView:isShowingFaceView];
//        [self changeAssessoryViewFrameWithConstant:0 tableScrollToFoot:YES];
//    }
//    if (isShowingRecordView) {
//        isShowingRecordView = NO;
//        [self showRecordView:isShowingRecordView];
//        [self changeAssessoryViewFrameWithConstant:0 tableScrollToFoot:YES];
//    }
}
#pragma mark
- (void) loadMessageWithPage:(NSInteger)page
{
    for (NSInteger i = 0; i < 5; i ++) {
        
        TMChatHelper *cp = [[TMChatHelper alloc] initWithMessageObject:@{@"voiceLength":@"10"} andTextView:tempTextView messageType:1];
        cp.messageId = [NSUUID UUID].UUIDString;
        cp.isMe = (i % 2 == 0);
        cp.isShowTime = (i % 2 != 0);
        cp.contentText = [LPGeneralHelper attributedStringWithText:testText];
        [messages insertObject:cp atIndex:0];
    }
    [self.tableView reloadData];
    [self.tableView scrollToRowAtIndexPath:[NSIndexPath indexPathForRow:5-1 inSection:0] atScrollPosition:UITableViewScrollPositionBottom animated:NO];
    [self.loadPastActivityView stopAnimating];
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}

#pragma mark cell气泡长按删除处理
- (void)deleteMessageCellAction:(NSString *)messageId
{
    for (NSIndexPath *indexPath in self.tableView.indexPathsForVisibleRows) {
        TMBaseMessageTableViewCell *cell = [self.tableView cellForRowAtIndexPath:indexPath];
        if ([cell.ch.messageId isEqualToString:messageId]) {
            [self.tableView beginUpdates];
            [messages removeObjectAtIndex:indexPath.row];
            [self.tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:cell.ch.isMe ? UITableViewRowAnimationRight : UITableViewRowAnimationLeft];
            [self.tableView endUpdates];
        }
        
    }
}
#pragma mark 点击聊天中图片操作
- (void)photoMessageCellAction:(TMChatHelper *)chatHelper
{
    if (chatHelper.messageType != 2) {
        return;
    }
    NSMutableArray *chatPhotos = [NSMutableArray array];
    browserPhotos = [NSMutableArray array];
    [messages enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        TMChatHelper *ch = obj;
        if (ch.messageType == 2 && ch.image) {
            [chatPhotos addObject:ch];
        }
        
    }];
    __block NSUInteger index = 0;
    [chatPhotos enumerateObjectsUsingBlock:^(id  _Nonnull obj, NSUInteger idx, BOOL * _Nonnull stop) {
        TMChatHelper *ch = obj;
        if ([ch.image isEqual:chatHelper.image]) {
            index = idx;
//            *stop = YES;
        }
        MWPhoto *photo = [MWPhoto photoWithImage:ch.image];
        [browserPhotos addObject:photo];
    }];
    
    NSLog(@"%@", [chatPhotos[index] image]);
    MWPhotoBrowser *browser = [[MWPhotoBrowser alloc] initWithDelegate:self];
    browser.displayActionButton = YES;
    browser.displayNavArrows = YES;
    browser.displaySelectionButtons = NO;
    browser.alwaysShowControls = NO;
    browser.zoomPhotosToFill = YES;
    browser.enableGrid = NO;
    browser.startOnGrid = NO;
    browser.enableSwipeToDismiss = NO;
    browser.autoPlayOnAppear = YES;
    [browser setCurrentPhotoIndex:index];
    [self.navigationController pushViewController:browser animated:YES];
//    TMBaseNavigationController *navBrowser = [[TMBaseNavigationController alloc] initWithRootViewController:browser];
//    navBrowser.modalTransitionStyle = UIModalTransitionStyleCrossDissolve;
//    [self.navigationController presentViewController:navBrowser animated:YES completion:^{
//        
//    }];
}

- (NSUInteger)numberOfPhotosInPhotoBrowser:(MWPhotoBrowser *)photoBrowser
{
    return browserPhotos.count;
}
- (id <MWPhoto>)photoBrowser:(MWPhotoBrowser *)photoBrowser photoAtIndex:(NSUInteger)index
{
    if (index < browserPhotos.count)
        return [browserPhotos objectAtIndex:index];
    return nil;
}
- (void)textViewDidBeginEditing:(UITextView *)textView
{
    if (isShowingFaceView) {
        isShowingFaceView = NO;
        [self showFaceView:isShowingFaceView];
    }
    if (isShowingRecordView) {
        isShowingRecordView = NO;
        [self showRecordView:isShowingRecordView];
    }
    [self scrollToFootOfTable:self.tableView animated:YES];
}

- (BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if ([text isEqualToString:@"\n"]) {
        NSLog(@"send");
        [self sendAction];
        return NO;
    }
    return YES;
}
- (IBAction)btnSendClicked:(id)sender {
    [self sendAction];
}

- (void) sendAction
{
    if (self.textView.text.length < 1) {
        return;
    }
    NSString *text = self.textView.text;
    tempTextView.attributedText = [LPGeneralHelper attributedStringWithText:text];
    self.textView.text = nil;
//    [self.view layoutIfNeeded];
    self.customContentViewLCHeight.constant = 84;
    [self.view layoutIfNeeded];
    [self.tableView beginUpdates];
    TMChatHelper *ch = [[TMChatHelper alloc] initWithMessageObject:nil andTextView:tempTextView messageType:1];
    ch.messageId = [NSUUID UUID].UUIDString;
    ch.isMe = (int)(0 + (arc4random() % (1 - 0 + 1)));
    ch.isShowTime = YES;
    ch.contentText = [LPGeneralHelper attributedStringWithText:text];
    [messages addObject:ch];
    NSIndexPath *indexPath = [NSIndexPath indexPathForRow:messages.count - 1 inSection:0];
    [self.tableView insertRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationBottom];
    [self.tableView endUpdates];
//    [self.tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
//    [NSThread sleepForTimeInterval:0.5];
//    dispatch_async(dispatch_get_main_queue(), ^{
//        NSIndexPath *indexPath1 = [NSIndexPath indexPathForRow:indexPath.row inSection:0];
//        [self.tableView scrollToRowAtIndexPath:indexPath1 atScrollPosition:UITableViewScrollPositionBottom animated:YES];
//        
//        
//        
//    });
    [self scrollToFootOfTable:self.tableView animated:YES];
    
}

- (void)textViewDidChange:(UITextView *)textView
{
//    NSLog(@"%@", textView.text);
    [self resetTextViewHeightWithTextView:textView];
}

- (void)resetTextViewHeightWithTextView:(UITextView *)textView
{
    [self.view layoutIfNeeded];
    CGRect rect = [textView.text boundingRectWithSize:CGSizeMake(textView.bounds.size.width - 10, MAXFLOAT) options:NSStringDrawingUsesLineFragmentOrigin|NSStringDrawingUsesFontLeading attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:14.0]} context:nil];
    NSLog(@"height %f", rect.size.height);
    [self scrollToFootOfTable:self.tableView animated:YES];
    self.textView.scrollIndicatorInsets = UIEdgeInsetsZero;
    if (rect.size.height > 30.0f) {
        CGFloat contentHeight = 80 + rect.size.height;
        if (self.view.frame.size.height - contentHeight - keyboardHeight <= 50) {
            return;
        }
        
        if (rect.size.height > 30 && rect.size.height < 40) {
            self.customContentViewLCHeight.constant = 65 + rect.size.height - 5;
            
        }else
            self.customContentViewLCHeight.constant = 65 + rect.size.height - 10;
        
    }else
    {
        self.customContentViewLCHeight.constant = 84;
    }
    
}
@end
