//
//  TMMessageTableViewCell.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/17.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMMessageTableViewCell : UITableViewCell

@property (weak, nonatomic) IBOutlet UIImageView *imgCover;
@end
