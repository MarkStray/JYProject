//
//  ACFaceView.h
//  AChat
//
//  Created by risenb—IOS3 on 14-4-3.
//  Copyright (c) 2014年 huangtie. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "Masonry.h"
#import "AppMacro.h"
#import "UIImageView+WebCache.h"
#import "UIButton+WebCache.h"
//#import "PagedCollectionView.h"
//#import "ACFaceCollectionViewCell.h"

static CGFloat const Face_Wight = 35;

static CGFloat const Face_Hight = 35;

static NSInteger const Face_count = 23;

typedef void(^ClickFaceBlock)(id faceObject);//返回值

typedef void(^DeleteFaceBlock)(id faceObject);//删除表情

typedef void(^SendFaceBlock)();//发送

typedef void(^FaceCategorySettingBlock)();//表情类别设置

typedef void(^FaceCategoryAddBlock)();//下载添加表情类别

typedef void(^BigFaceSelectionBlock)(NSString *title, NSString *faceUrl);//大表情选择回调

@interface ACFaceView : UIView<UIScrollViewDelegate>

@property (nonatomic, copy) ClickFaceBlock clickFaceBlock;

@property (nonatomic, copy) DeleteFaceBlock deleteFaceBlock;

@property (nonatomic, copy) SendFaceBlock sendFaceBlock;

@property (nonatomic, copy) FaceCategorySettingBlock faceCategorySettingBlock;

@property (nonatomic, copy) FaceCategoryAddBlock faceCategoryAddBlock;

@property (nonatomic, copy) BigFaceSelectionBlock bigFaceSelectionBlock;

- (void)show;

- (void)showInAlbum;

- (void)hide;

- (void)reloadFaceCategoryScrollView;

@end
