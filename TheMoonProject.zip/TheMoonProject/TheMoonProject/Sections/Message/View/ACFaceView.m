//
//  ACFaceView.m
//  AChat
//
//  Created by risenb—IOS3 on 14-4-3.
//  Copyright (c) 2014年 huangtie. All rights reserved.
//

#import "ACFaceView.h"

//@interface ACFaceView()<PagedCollectionViewDelegate, PagedCollectionViewDataSource>
@interface ACFaceView()
@property (nonatomic , strong) UIScrollView *bgScrollView;//默认表情包滚动视图
//@property (nonatomic, strong) PagedCollectionView *collectionView;//显示表情包表情的视图
@property (nonatomic , strong) NSMutableArray *face2DArray;
@property (nonatomic, strong) UIPageControl *pageControl;
@property (nonatomic, strong) UIScrollView *faceCategoryScrollView;
@property (nonatomic, strong) UIButton *sendButton;
@property (nonatomic, strong) NSArray *faceArray;/**<获取plist文件表情字典数组*/
@property (nonatomic, strong) NSMutableArray *faceCategory;/**<表情类别数组*/
@property (nonatomic) NSInteger selectedCategoryIndex;/**<选中表情类别下标*/
@property (nonatomic, copy) NSString *selectedExpressionId;/**<选择表情包id*/
@property (nonatomic, strong) NSMutableArray *localExpressions;/**<表情包数组*/
@property (nonatomic, strong) NSMutableArray *localFaces;/**<所有大表情图片数组*/
@property (nonatomic, copy) NSString *cellIdentifier;

@end

static NSUInteger const oneLineCount = 7;/**<每行显示表情数*/
static NSUInteger const onePageLines = 3;/**<每一页显示表情行数*/
static CGFloat const sendLineHeight = 44.0f;/**<底部发送栏高度*/
static CGFloat const sendButtonWidth = 70;/**<发送按钮、表情类别按钮宽度*/
static CGFloat const sendButtonHeight = 35;/**<发送按钮高度*/
static CGFloat const categoryButtonTagCol = 333;/**<表情类别tag值区分*/
static CGFloat const categoryButtonSize = 25;/**<表情类别按钮图片大小*/
static NSString * const defaultExpressionId = @"Default";/**<默认表情包id*/


@implementation ACFaceView

- (id)init
{
    self = [super init];
    if (self)
    {
        [self initWithSubviews];
        [self crateWithFaceData];
        [self crateWithSubviews];
    }
    return self;
}

- (void)initWithSubviews
{
    self.width = PhoneScreen_WIDTH;
    self.height = 216;
    self.top = PhoneScreen_HEIGHT;
    self.backgroundColor = RGBCOLOR(209, 213, 219, 1);
    //加边框
//    self.layer.cornerRadius = 5;    //圆角半径
//    self.layer.borderWidth = 0.5;   //边框宽度
//    self.layer.borderColor = RGBCOLOR(217, 220, 223, 1).CGColor;
//    self.layer.masksToBounds = YES;
}
#define EmoFilePath [[NSBundle mainBundle] pathForResource:@"faceList" ofType:@"plist"]

#define Emoji [NSArray arrayWithContentsOfFile:EmoFilePath];
- (void)crateWithFaceData
{
    self.face2DArray = [[NSMutableArray alloc]init];

    NSArray *emojiArr = Emoji;
    NSMutableArray *smollArr = [[NSMutableArray alloc]init];
    for (int i = 1 ; i <= emojiArr.count ; i ++)
    {
        NSDictionary *dic = [[NSDictionary alloc]init];
        dic = emojiArr[i - 1];
        [smollArr addObject:dic];
        if (i % Face_count == 0 || i == emojiArr.count)
        {
            [self.face2DArray addObject:smollArr];
            smollArr = [[NSMutableArray alloc]init];
        }
    }
}


#pragma mark 创建视图
- (void)crateWithSubviews
{
    //滑动试图
    self.bgScrollView = [[UIScrollView alloc]init];
    self.bgScrollView.frame = self.bounds;
    self.bgScrollView.pagingEnabled = YES;
    self.bgScrollView.directionalLockEnabled = YES;
    self.bgScrollView.bounces = YES;
    self.bgScrollView.bouncesZoom = NO;
    self.bgScrollView.delegate = self;
    self.bgScrollView.showsHorizontalScrollIndicator = NO;
    self.bgScrollView.showsVerticalScrollIndicator = NO;
//    self.bgScrollView.contentSize = CGSizeMake(PhoneScreen_WIDTH * self.face2DArray.count, self.height) ;
    self.bgScrollView.backgroundColor = [UIColor clearColor];
    [self addSubview:self.bgScrollView];
    CGFloat boundsViewSpace = 16;
    
    _faceArray = Emoji;
    NSUInteger faceCount = _faceArray.count; //表情总数
    NSUInteger onePageCount = oneLineCount * onePageLines - 1;
    NSUInteger boundsViewCount = faceCount / onePageCount;
    boundsViewCount = boundsViewCount + faceCount % onePageCount > boundsViewCount ? boundsViewCount + 1 : boundsViewCount;
    self.bgScrollView.contentSize = CGSizeMake(PhoneScreen_WIDTH * boundsViewCount, self.height) ;
    NSMutableArray *boundsViews = [NSMutableArray arrayWithCapacity:boundsViewCount];
    for (NSUInteger i = 0; i < boundsViewCount; i ++) {
        UIView *boundsView = [[UIView alloc] init];
        boundsView.backgroundColor = [UIColor clearColor];
        boundsView.frame = CGRectMake(boundsViewSpace + PhoneScreen_WIDTH * i, PhoneScreen_HEIGHT >= 667 ? boundsViewSpace - 15 : boundsViewSpace, PhoneScreen_WIDTH - boundsViewSpace * 2, self.height - boundsViewSpace * 2 - sendLineHeight);
        [self.bgScrollView addSubview:boundsView];
        boundsView.tag = i;
        [boundsViews addObject:boundsView];
    }
    CGFloat btnWidth = (PhoneScreen_WIDTH - boundsViewSpace * 2) / oneLineCount;
    CGFloat edgeInsetsValue = PhoneScreen_WIDTH / 40;
    for (NSUInteger faceIndex = 0; faceIndex < faceCount; faceIndex ++) {

        NSUInteger boundsViewIndex = (faceIndex) / onePageCount;
        
        for (NSInteger boundsIndex = 0; boundsIndex < boundsViews.count; boundsIndex ++) {
            UIView *boundsView = boundsViews[boundsIndex];
            if (boundsViewIndex == boundsIndex) {
                
                NSInteger btnTop = (faceIndex / oneLineCount) * (btnWidth);
                NSInteger btnLeft = (faceIndex % oneLineCount) * btnWidth;
                if (boundsIndex > 0) {
                    btnTop = (faceIndex - onePageCount * boundsIndex) / oneLineCount * btnWidth;
                    btnLeft = (faceIndex - onePageCount * boundsIndex) % oneLineCount * btnWidth;
                }
                NSString *imageName = [[_faceArray objectAtIndex:faceIndex] objectForKey:@"png"];
                UIButton *faceButton = [UIButton buttonWithType:UIButtonTypeCustom];
                [faceButton setImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
                faceButton.frame = CGRectMake(btnLeft,  btnTop, btnWidth, btnWidth);
//                [faceButton setContentEdgeInsets:UIEdgeInsetsMake(8, 8, 8, 8)];
//                [faceButton setContentEdgeInsets:UIEdgeInsetsMake(10, 10, 10, 10)];
                [faceButton setContentEdgeInsets:UIEdgeInsetsMake(edgeInsetsValue, edgeInsetsValue, edgeInsetsValue, edgeInsetsValue)];
                faceButton.backgroundColor = [UIColor clearColor];
                faceButton.tag = faceIndex;
                [faceButton addTarget:self action:@selector(faceButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
                [boundsView addSubview:faceButton];
            }
            
        }
        
    }
    //删除按钮
    for (NSInteger boundsIndex = 0; boundsIndex < boundsViews.count; boundsIndex ++) {
        UIView *boundsView = boundsViews[boundsIndex];
        
        UIButton *deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [deleteButton setImage:[UIImage imageNamed:@"DeleteEmoticonBtn"] forState:UIControlStateNormal];
        [deleteButton setImage:[UIImage imageNamed:@"DeleteEmoticonBtnHL"] forState:UIControlStateHighlighted];
        [deleteButton addTarget:self action:@selector(deleteFaceAction:) forControlEvents:UIControlEventTouchUpInside];
        deleteButton.backgroundColor = [UIColor clearColor];
        deleteButton.frame = CGRectMake(boundsView.bounds.size.width - btnWidth - 1, boundsView.bounds.size.height - btnWidth - boundsViewSpace - 1, btnWidth, btnWidth);
        if (PhoneScreen_HEIGHT >= 667) {
            deleteButton.top = boundsView.bounds.size.height - btnWidth/2 - boundsViewSpace - 2;
        }
        if (PhoneScreen_HEIGHT >= 736) {
            deleteButton.top = boundsView.bounds.size.height - btnWidth/2 - 4;
        }
        [deleteButton setContentEdgeInsets:UIEdgeInsetsMake(edgeInsetsValue, edgeInsetsValue, edgeInsetsValue, edgeInsetsValue)];
        [boundsView addSubview:deleteButton];
        
        boundsView.height += 20;//避免6+上面表情按钮点不到
    }
    
//    NSLog(@"MAIN_FRAME %@", NSStringFromCGRect(MAIN_FRAME));
    
    
//    if (PhoneScreen_WIDTH > 320 && PhoneScreen_WIDTH <= 375) {
//        btnX = 27;
//    }else if (PhoneScreen_WIDTH > 375 && PhoneScreen_WIDTH <= 414)
//    {
//        btnX = 35;
//    }
//    for (int i = 0; i < self.face2DArray.count; i++)
//    {
//        int row = 0,lie = 0;
//        NSArray *smoArr = self.face2DArray[i];
//        UIView *faceview = [self FaceView:CGPointMake(PhoneScreen_WIDTH * i, -10)];
//        [self.bgScrollView addSubview:faceview];
////        CGFloat btnX = 16;//PhoneScreen_WIDTH - (Face_Wight + 16) * 6;
//        
//        for (int j = 0; j < smoArr.count; j++)
//        {
//            CGPoint point = CGPointMake( 16 + row * (Face_Wight + btnX),16 + lie * (Face_Hight + 16));
////            CGPoint point = CGPointMake( btnX + row * (Face_Wight + btnX),btnX + 16 + lie * (Face_Hight + 16));
//            UIButton *facebutton = [self FaceButton:point image:[UIImage imageNamed:[smoArr[j] objectForKey:@"png"]]];
//            facebutton.backgroundColor = [UIColor clearColor];
//            facebutton.tag = 999 + i * Face_count + j;
//            [faceview addSubview:facebutton];
//            row ++;
//            if ((j + 1) % 6 == 0 )
//            {
//                row = 0;
//                lie ++;
//            }
//        }
//    }
    
    
//    for (NSUInteger i = 0; i < self.face2DArray.count; i ++) {
//        
//        
//    }
    
    //
//    self.otherExpressionScrollView = [[UIScrollView alloc] init];
//    self.otherExpressionScrollView.frame = self.bounds;
//    [self addSubview:self.otherExpressionScrollView];
//    self.otherExpressionScrollView.height = self.bounds.size.height
    
    
//    self.otherExpressionScrollView.hidden = YES;
    //分页
    self.pageControl = [[UIPageControl alloc] initWithFrame:CGRectMake(0, self.height - 25 - sendLineHeight, self.width, 10)];
    if (PhoneScreen_HEIGHT >= 667) {
        self.pageControl.top = self.height - sendLineHeight - 20;
    }
    if (PhoneScreen_HEIGHT >= 736) {
        self.pageControl.top = self.height - sendLineHeight - 15;
    }
    self.pageControl.currentPageIndicatorTintColor = RGBCOLOR(63, 66, 81, 1);
    self.pageControl.pageIndicatorTintColor = [UIColor lightGrayColor];
    [self addSubview:self.pageControl];
    self.pageControl.numberOfPages = self.bgScrollView.contentSize.width/PhoneScreen_WIDTH;
    self.pageControl.backgroundColor = [UIColor clearColor];
    [self.pageControl addTarget:self action:@selector(pageChanged:) forControlEvents:UIControlEventValueChanged];
    
    //发送按钮
    self.sendButton = [UIButton buttonWithType:UIButtonTypeSystem];
    self.sendButton.backgroundColor = self.sendButton.tintColor;
    [self.sendButton setTitle:@"发送" forState:UIControlStateNormal];
    [self.sendButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    self.sendButton.titleLabel.font = [UIFont systemFontOfSize:16.0f];
    self.sendButton.layer.cornerRadius = 5;
    self.sendButton.layer.masksToBounds = YES;
    [self.sendButton setTitleEdgeInsets:UIEdgeInsetsMake(0, - 1, 0, 0)];
    [self.sendButton addTarget:self action:@selector(sendButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    [self addSubview:self.sendButton];
    self.sendButton.frame = CGRectMake(self.bounds.size.width - sendButtonWidth - 3, self.bounds.size.height - (sendLineHeight - sendButtonHeight) - sendButtonHeight, sendButtonWidth, sendButtonHeight);
    
    
#pragma mark CollectionView ~~~~~~~~~~~~~~~~~
    //显示下载的表情视图
    self.cellIdentifier = @"Cell";
//    self.collectionView = [[PagedCollectionView alloc] initWithFrame:self.bounds];
//    self.collectionView.height = self.bounds.size.height - sendLineHeight - 5;
//    [self addSubview:self.collectionView];
//    self.collectionView.cellIdentifier = self.cellIdentifier;
//    self.collectionView.cellClassName = @"ACFaceCollectionViewCell";
//    self.collectionView.dataSource = self;
//    self.collectionView.delegate = self;
//    self.collectionView.itemSize = CGSizeMake(70, 75);
//    self.collectionView.columnCount = 4;
//    self.collectionView.lineCount = 2;
//    self.collectionView.backgroundColor = [UIColor clearColor];
//    self.collectionView.hidden = YES;
    
    
    [self reloadFaceCategoryScrollView];
    [self setDefaultFaceCategory:categoryButtonTagCol];
}

#pragma mark 表情类别选择
- (IBAction)categoryButtonClicked:(UIButton *)sender
{
    if (sender.isSelected) {
        return;
    }
    
    if (sender.tag - categoryButtonTagCol == self.faceCategory.count - 2) {//设置
        if (self.faceCategorySettingBlock) {
            self.faceCategorySettingBlock();
        }
        return;
    }
    if (sender.tag - categoryButtonTagCol == self.faceCategory.count - 1) {//添加
        if (self.faceCategoryAddBlock) {
            self.faceCategoryAddBlock();
        }
        return;
    }
    
//-----------------------通过表情包id比较是否是选中的--------------------------start
    
    NSString *selectedExpressionId = defaultExpressionId;//选中表情包id，默认表情则标志为为Default
    
    if (sender.tag - categoryButtonTagCol > 0) {
        NSDictionary *selectedCategoryDcit = [self.faceCategory objectAtIndex:sender.tag - categoryButtonTagCol];
        selectedExpressionId = [selectedCategoryDcit objectForKey:@"expressionId"];
    }
    _selectedExpressionId = selectedExpressionId;
    [self reloadFaceScrollViewWithExpressionId:selectedExpressionId];
    
    
    //设置其他表情包未不选中
    for (NSInteger i = 0 ; i < self.faceCategory.count; i ++) {
        
        
        if (i == 0) {
            if (![selectedExpressionId isEqualToString:defaultExpressionId]) {
                UIButton *categoryButton = (UIButton *)[self.faceCategoryScrollView viewWithTag:i + categoryButtonTagCol];
                categoryButton.selected = NO;
            }
        }else
        if (i < self.faceCategory.count - 2) {
            NSDictionary *categoryDict = [self.faceCategory objectAtIndex:i];
            NSString *expressionId = [categoryDict objectForKey:@"expressionId"];
            
            if (![selectedExpressionId isEqualToString:expressionId]) {
                UIButton *categoryButton = (UIButton *)[self.faceCategoryScrollView viewWithTag:i + categoryButtonTagCol];
                categoryButton.selected = NO;
            }
        }
        
    }
//-----------------------通过表情包id比较是否是选中的--------------------------end
    sender.selected = YES;
    self.selectedCategoryIndex = sender.tag;
    
    
    [self expressionCollectionViewScrollToSection];
    [self expressionScrollViewScrollToSection:sender];
    //发送按钮显示与隐藏
    [UIView animateKeyframesWithDuration:0.3 delay:CGFLOAT_MIN options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
        self.sendButton.left = sender.tag > categoryButtonTagCol ? PhoneScreen_WIDTH : self.bounds.size.width - sendButtonWidth - 3;
    } completion:^(BOOL finished) {
        
    }];
}

#pragma mark 通过选择的表情包，滚动到相应的表情包组
- (void) expressionCollectionViewScrollToSection
{
    
    NSUInteger selectedCategoryNo = self.selectedCategoryIndex - categoryButtonTagCol;
    if (selectedCategoryNo > 0) {
//        [self.collectionView selectSection:selectedCategoryNo - 1 page:0 animated:YES];
    }
}
#pragma mark 通过选择的表情包，使表情包按钮处在屏幕中间
- (void) expressionScrollViewScrollToSection:(UIButton *)button
{
    NSInteger position = button.tag - categoryButtonTagCol;
    NSLog(@"position %f  %f", position * sendButtonWidth , PhoneScreen_WIDTH / 2);
    if (position * sendButtonWidth < PhoneScreen_WIDTH / 2) {
        [self.faceCategoryScrollView setContentOffset:CGPointZero animated:YES];
    }else
    {
        CGFloat offsetX = position * sendButtonWidth - self.bounds.size.width / 2 + sendButtonWidth / 2;
            [self.faceCategoryScrollView setContentOffset:CGPointMake(offsetX, self.faceCategoryScrollView.contentOffset.y) animated:YES];
    }
}

#pragma mark 默认表情按钮事件
- (IBAction)faceButtonClicked:(UIButton *)sender
{

    NSInteger faceIndex = sender.tag;
    NSDictionary *faceDict = [_faceArray objectAtIndex:faceIndex];
    if (_clickFaceBlock) {
        _clickFaceBlock([faceDict objectForKey:@"chs"]);
    }
}

- (IBAction)sendButtonClicked:(id)sender
{
    if (_sendFaceBlock) {
        _sendFaceBlock();
    }
}

- (void) pageChanged:(UIPageControl *)pageControl
{
//    NSLog(@"%ld", pageControl.currentPage);
    NSInteger page = pageControl.currentPage;
    if ([_selectedExpressionId isEqualToString:defaultExpressionId]) {
        [self.bgScrollView setContentOffset:CGPointMake(page * self.bounds.size.width, 0) animated:YES];
    }else
    {
        
    }
}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    NSInteger index = fabs(scrollView.contentOffset.x)/PhoneScreen_WIDTH;
    self.pageControl.currentPage = index;
}
//- (UIButton *)FaceButton:(CGPoint)point image:(UIImage *)image
//{
//    UIButton *facebutton = [UIButton buttonWithType:UIButtonTypeCustom];
//    facebutton.frame = CGRectMake(point.x, point.y, Face_Wight, Face_Hight);
//    [facebutton setBackgroundImage:image forState:UIControlStateNormal];
//    [facebutton addTarget:self action:@selector(clickFaceAction:) forControlEvents:UIControlEventTouchUpInside];
//    return facebutton;
//}

//- (UIView *)FaceView:(CGPoint)point
//{
//    UIView *faceview = [[UIView alloc]init];
//    faceview.backgroundColor = [UIColor clearColor];
//    faceview.frame = CGRectMake(point.x, point.y, self.width, self.height);
//    
//    UIButton *deleteButton = [UIButton buttonWithType:UIButtonTypeCustom];
//    [deleteButton setBackgroundImage:[UIImage imageNamed:@"DeleteEmoticonBtn"] forState:UIControlStateNormal];
//    [deleteButton setBackgroundImage:[UIImage imageNamed:@"DeleteEmoticonBtnHL@"] forState:UIControlStateHighlighted];
//    [deleteButton addTarget:self action:@selector(deleteFaceAction:) forControlEvents:UIControlEventTouchUpInside];
//    [deleteButton setFrame:CGRectMake(self.width - 16 - 32, self.height - 16 - 32, 32, 32)];
//    
//    [faceview addSubview:deleteButton];
//    return faceview;
//}
#pragma mark 设置默认选中表情类别
- (void) setDefaultFaceCategory:(NSInteger) categoryIndex;
{
    for (NSInteger i = 0 ; i < self.faceCategory.count; i ++) {
        UIButton *categoryButton = (UIButton *)[self.faceCategoryScrollView viewWithTag:i + categoryButtonTagCol];
        if (categoryButton.tag == categoryIndex) {
            
            categoryButton.selected = YES;
            self.selectedCategoryIndex = categoryIndex;
        }else
        {
            categoryButton.selected  =NO;
        }
    }
}

#pragma mark 显示和隐藏
- (void)show
{
    [UIView animateWithDuration:.5 animations:^{
        self.top = PhoneScreen_HEIGHT - self.height - 64;
    }];
}

- (void)showInAlbum {
    [UIView animateWithDuration:.5 animations:^{
        self.top = PhoneScreen_HEIGHT - self.height;
//        if(!iSiPhone)
//        {
//            self.top =self.superview.frame.size.height-self.height;
//        }
    }];
}

- (void)hide
{
    [UIView animateWithDuration:.5 animations:^{
        self.top = PhoneScreen_HEIGHT;
    }];
}

#pragma mark 点击表情触发事件
- (void)clickFaceAction:(UIButton *)button
{
    NSInteger index = button.tag - 999;
    NSArray *arr = self.face2DArray[index / Face_count];
    NSDictionary *dic = arr[index % Face_count];
    if (_clickFaceBlock) {
        _clickFaceBlock([dic objectForKey:@"chs"]);
    }
}

- (void)deleteFaceAction:(UIButton *)button
{
    if (_deleteFaceBlock) {
        _deleteFaceBlock(nil);
    }
}

#pragma mark 刷新表情包按钮
- (void)reloadFaceCategoryScrollView
{
    return;
    if (self.faceCategory.count > 0) {
        [self.faceCategory removeAllObjects];
        self.faceCategory = nil;
    }
    
    if (self.faceCategoryScrollView) {
        while (self.faceCategoryScrollView.subviews.lastObject) {
            [self.faceCategoryScrollView.subviews.lastObject removeFromSuperview];
        }
        [self.faceCategoryScrollView removeFromSuperview];
    }
    
    self.faceCategoryScrollView = [[UIScrollView alloc] init];
    [self addSubview:self.faceCategoryScrollView];
    
    self.faceCategoryScrollView.backgroundColor = [UIColor whiteColor];
    self.faceCategoryScrollView.showsHorizontalScrollIndicator = NO;
    self.faceCategoryScrollView.showsVerticalScrollIndicator = NO;
    [self.faceCategoryScrollView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.leading.mas_equalTo(self);
        make.trailing.mas_equalTo(self);
        make.bottom.mas_equalTo(self);
        make.height.mas_equalTo(sendLineHeight);
    }];
    
    
    NSArray *localCategory = nil;//[ACSaveObjectToLocal loadObjectForKey:EXPRESSION_LOCAL];
    self.faceCategory = [NSMutableArray arrayWithArray:localCategory];
    [self.faceCategory insertObject:@"默认" atIndex:0];
    [self.faceCategory addObject:@"设置"];
    [self.faceCategory addObject:@"添加"];
    
    self.faceCategoryScrollView.contentSize = CGSizeMake((self.faceCategory.count + 1) * sendButtonWidth, sendLineHeight);
    
    //添加表情类别按钮
    for (NSInteger categoryIndex = 0; categoryIndex < self.faceCategory.count; categoryIndex ++) {
        //        NSString *categoryText = self.faceCategory[categoryIndex];
        UIButton *categoryButton = [UIButton buttonWithType:UIButtonTypeCustom];
        [categoryButton setTitleColor:[UIColor grayColor] forState:UIControlStateNormal];
        
        categoryButton.frame = CGRectMake(sendButtonWidth * categoryIndex, 0, sendButtonWidth, sendLineHeight);
        
        if (categoryIndex < self.faceCategory.count - 1) {
            UIImageView *lineView = [[UIImageView alloc] init];//竖线，分割线
            lineView.frame = CGRectMake(categoryButton.right - 0.25, (categoryButton.bounds.size.height - 20) / 2, 0.5, 20);
            lineView.backgroundColor = [UIColor lightGrayColor];
            //        lineView.alpha
            [self.faceCategoryScrollView addSubview:lineView];
        }
        
        
        UIImageView *faceLogo = [[UIImageView alloc] initWithFrame:CGRectMake((categoryButton.bounds.size.width - categoryButtonSize) / 2, (categoryButton.bounds.size.height - categoryButtonSize) / 2, categoryButtonSize, categoryButtonSize)];
        //        faceLogo.userInteractionEnabled = YES;
        [categoryButton addSubview:faceLogo];
        faceLogo.backgroundColor = [UIColor clearColor];
        if (categoryIndex == 0) {
            faceLogo.image = [UIImage imageNamed:@"ebg"];
        }else if (categoryIndex == self.faceCategory.count - 2)
        {
            faceLogo.image = [UIImage imageNamed:@"face_my_gray"];
        }else if (categoryIndex == self.faceCategory.count - 1)
        {
            faceLogo.image = [UIImage imageNamed:@"face_add_store"];
        }else
        {
            NSDictionary *categoryDict = [self.faceCategory objectAtIndex:categoryIndex];
            NSString *categoryLogo = [categoryDict objectForKey:@"expressionLogo"];
            [faceLogo sd_setImageWithURL:[NSURL URLWithString:categoryLogo] placeholderImage:nil];
        }
        
        
        categoryButton.imageEdgeInsets = UIEdgeInsetsMake(15, 20, 15, 20);
        [categoryButton setBackgroundColor:[UIColor clearColor]];
        [categoryButton setBackgroundImage:[UIImage imageNamed:@"AC_register_normal@2x"] forState:UIControlStateSelected];
        [categoryButton setBackgroundImage:[UIImage imageNamed:@"AC_register_normal@2x"] forState:UIControlStateHighlighted];
        
        categoryButton.tag = categoryIndex + categoryButtonTagCol;
        [categoryButton addTarget:self action:@selector(categoryButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
        [self.faceCategoryScrollView addSubview:categoryButton];
    }
    
    [self bringSubviewToFront:self.sendButton];
    
    _localExpressions = [NSMutableArray arrayWithArray:self.faceCategory];
    [_localExpressions removeObjectAtIndex:0];//移除默认表情包
    [_localExpressions removeLastObject];//移除添加
    [_localExpressions removeLastObject];//移除设置
    if (self.selectedCategoryIndex > categoryButtonTagCol - 1) {
//        self.collectionView.hidden = _localExpressions.count< 1;
        self.bgScrollView.hidden = self.pageControl.hidden = YES;
        
        [UIView animateKeyframesWithDuration:0.3 delay:CGFLOAT_MIN options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
            self.sendButton.left =  PhoneScreen_WIDTH;
        } completion:^(BOOL finished) {
            
        }];
    }
    if (_localExpressions.count < 1) {
        
        
        [self setDefaultFaceCategory:categoryButtonTagCol];
        self.bgScrollView.hidden = self.pageControl.hidden = NO;
        //显示发送按钮
        [UIView animateKeyframesWithDuration:0.3 delay:CGFLOAT_MIN options:UIViewKeyframeAnimationOptionCalculationModeLinear animations:^{
            self.sendButton.left =  self.bounds.size.width - sendButtonWidth - 3;
        } completion:^(BOOL finished) {
            
        }];
        
        
        return;
    }
    
//    [self.collectionView reload];
}

#pragma mark 下载的大表情按钮事件
- (IBAction)otherFaceButtonClicked:(UIButton *)sender
{
    NSInteger index = sender.tag;
    NSDictionary *faceDict = [self.localFaces objectAtIndex:index];
    NSString *title = [faceDict objectForKey:@"title"];
    NSString *url = [faceDict objectForKey:@"url"];
    !_bigFaceSelectionBlock ?: _bigFaceSelectionBlock(title, url);
    NSLog(@"%@", faceDict);
}

#pragma mark 通过选中的表情包id更新表情栏视图
- (void) reloadFaceScrollViewWithExpressionId:(NSString *)selectedExpressionId
{
    BOOL isDefaultExpression = [selectedExpressionId isEqualToString:defaultExpressionId];
    self.bgScrollView.hidden = self.pageControl.hidden = !isDefaultExpression;
//    self.collectionView.hidden = isDefaultExpression;
}

#pragma mark -  PagedCollectionViewDataSource
//- (void)pagedCollectionView:(PagedCollectionView *)collectionView secionChanged:(NSInteger)section{
//    
////    NSLog(@"change section to %ld", (long)section);
//    [self setDefaultFaceCategory:section + 1 + categoryButtonTagCol];
//}


- (NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView
{
    NSInteger sections = 0;
    if (self.localExpressions.count > 0) {
        sections = self.localExpressions.count;
    }
    return sections;
}

- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section
{
    NSDictionary *expressionSectionDict = _localExpressions[section];
    NSArray *expressions = expressionSectionDict[@"faces"];
    return expressions.count;
}

//- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath
//{
//    ACFaceCollectionViewCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:self.cellIdentifier forIndexPath:indexPath];
//    
//    if (_localExpressions.count > 0) {
//        NSDictionary *expressionSectionDict = _localExpressions[indexPath.section];
//        NSArray *expressions = expressionSectionDict[@"faces"];
//        NSDictionary *expressionDict = expressions[indexPath.row];
//        cell.faceName.text = expressionDict[@"title"];
//        [cell.faceIcon sd_setImageWithURL:[NSURL URLWithString:expressionDict[@"url"]] placeholderImage:nil];
//    }
//
//    return cell;
//}
//
//- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath
//{
//    NSDictionary *expressionSectionDict = _localExpressions[indexPath.section];
//    NSArray *expressions = expressionSectionDict[@"faces"];
//    NSDictionary *expressionDict = expressions[indexPath.row];
//    NSString *title = expressionDict[@"title"];
//    NSString *imgUrl = expressionDict[@"url"];
//    !_bigFaceSelectionBlock ?: _bigFaceSelectionBlock(title, imgUrl);
//}

@end
