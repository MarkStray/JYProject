//
//  TMPhotoMessageTableViewCell.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/23.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMBaseMessageTableViewCell.h"

@interface TMPhotoMessageTableViewCell : TMBaseMessageTableViewCell

@property (nonatomic, strong) UIImageView *photoView;
@property (nonatomic, strong) UIImageView *maskImageView;

@property (nonatomic, strong) TMChatHelper *chatHelper;

+(void)setMenuControllerAvaible:(BOOL)avaible animated:(BOOL)animated;
@end
