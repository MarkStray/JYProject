//
//  TMBaseMessageTableViewCell.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/22.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMBaseMessageTableViewCell.h"
#import "UIImageView+WebCache.h"

//const CGFloat TMChatAvatarSize = 50.0f;

@implementation TMBaseMessageTableViewCell
{
    UITapGestureRecognizer *tapAvatar;
    UITapGestureRecognizer *tapBubble;
}

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self =  [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createBaseSubviews];
        self.backgroundColor = [UIColor clearColor];
        self.selectionStyle = UITableViewCellSelectionStyleNone;
    }
    return self;
}

- (instancetype)initWithChatHelper:(TMChatHelper *)ch
{
    self = [super init];
    if (self) {
        _ch = ch;
    }
    return self;
}

- (void) createBaseSubviews
{
    //date label
    self.dateLabel = [[UILabel alloc] init];
    self.dateLabel.backgroundColor = [UIColor clearColor];
    self.dateLabel.textAlignment = NSTextAlignmentCenter;
    self.dateLabel.font = [UIFont systemFontOfSize:14.0f];
    self.dateLabel.textColor = [UIColor grayColor];
    [self.contentView addSubview:self.dateLabel];
    self.dateLabel.text = @"17:30";
    //init avatar
    self.avatarImageView = [[UIImageView alloc] init];
    self.avatarImageView.image = [UIImage imageNamed:@"message_select"];
    [self.avatarImageView sd_setImageWithURL:[NSURL URLWithString:@"http://www.qq1234.org/uploads/allimg/150126/1425055125-5.png"]];
    [self.contentView addSubview:self.avatarImageView];
    self.avatarImageView.backgroundColor = [UIColor clearColor];
    self.avatarImageView.userInteractionEnabled = YES;
    self.avatarImageView.layer.cornerRadius = 5;
    self.avatarImageView.layer.masksToBounds = YES;
    tapAvatar = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(avatarTapped:)];
    [self.avatarImageView addGestureRecognizer:tapAvatar];
    
    
    //init bubble
    self.bubbleImageView = [[UIImageView alloc] init];
//    self.bubbleImageView.backgroundColor = [UIColor orangeColor];
    [self.contentView addSubview:self.bubbleImageView];
    tapBubble = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(bubbleTapped:)];
    [self.bubbleImageView addGestureRecognizer:tapBubble];
    //auto layout
    
    self.activityView = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleGray];
    [self.contentView addSubview:self.activityView];
    [self.activityView startAnimating];
    
    self.sendFailedButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [self.sendFailedButton setImage:[UIImage imageNamed:@"chat_message_error"] forState:UIControlStateNormal];
    [self.contentView addSubview:self.sendFailedButton];
    [self performSelector:@selector(test) withObject:nil afterDelay:2];
    self.sendFailedButton.hidden = YES;
}
- (void) test
{
    
    [self.activityView stopAnimating];
}

- (void)avatarTapped:(UITapGestureRecognizer *)tap
{
    !self.messageAvatarTapBlock ?: self.messageAvatarTapBlock(YES);
}

- (void)bubbleTapped:(UITapGestureRecognizer *)tap
{
    !_messageBubbleTapBlock ?: _messageBubbleTapBlock();
}

- (BOOL)canBecomeFirstResponder
{
    return YES;
}


- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
