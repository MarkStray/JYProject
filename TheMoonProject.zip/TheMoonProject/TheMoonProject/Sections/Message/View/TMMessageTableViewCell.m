//
//  TMMessageTableViewCell.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/17.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMMessageTableViewCell.h"

@implementation TMMessageTableViewCell

- (void)awakeFromNib {
    // Initialization code

}
- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
