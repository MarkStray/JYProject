//
//  TMTextMessageTableViewCell.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TMBaseMessageTableViewCell.h"


@interface TMTextMessageTableViewCell : TMBaseMessageTableViewCell

@property (nonatomic, strong) UITextView *contentTextView;

//@property (nonatomic, strong) UILabel *dateLabel;

//@property (nonatomic, strong) UIImageView *avatarImageView;

//- (void)changeContentSize:(CGSize)size isMe:(BOOL)isMe;
@property (nonatomic, strong) TMChatHelper *chatHelper;
@end
