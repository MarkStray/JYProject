//
//  TMRightTextMessageTableViewCell.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMRightTextMessageTableViewCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UITextView *textView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *widthLayoutConstraint;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *heightLayoutConstraint;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;


- (void) changeTextWidthLayout:(CGFloat)width;
- (void)changeTextHeightLayout:(CGFloat)height;
@end
