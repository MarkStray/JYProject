//
//  TMBaseMessageTableViewCell.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/22.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TMChatHelper.h"

//应该为static变量
#define Chat_Bubble_Me_ImageName @"chat_bubble_me"
#define Chat_Bubble_Other_ImageName @"chat_bubble_other"

#define Bubble_Offset 8

static const CGFloat TMChatAvatarSize = 50.0f;

typedef void(^TMMessageAvatarTapBlock)(BOOL enable);

typedef void(^TMMessageDeleteBlock)(BOOL enable);

typedef void(^TMMessageBubbleTapBlock)();

@interface TMBaseMessageTableViewCell : UITableViewCell

@property (nonatomic, strong) UILabel *dateLabel;

@property (nonatomic, strong) UIImageView *avatarImageView;

@property (nonatomic, strong) UIImageView *bubbleImageView;

@property (nonatomic, strong) UIActivityIndicatorView *activityView;

@property (nonatomic, strong) UIButton *sendFailedButton;

@property (nonatomic, copy) TMMessageAvatarTapBlock messageAvatarTapBlock;

@property (nonatomic, copy) TMMessageDeleteBlock messageDeleteBlock;

@property (nonatomic, copy) TMMessageBubbleTapBlock messageBubbleTapBlock;


@property (nonatomic, assign) BOOL isMine;

@property (nonatomic, strong) TMChatHelper *ch;


//- (instancetype)initWithRole:(BOOL)role;

@end
