//
//  TMTextMessageTableViewCell.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMTextMessageTableViewCell.h"

@implementation TMTextMessageTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createSubviews];
    }
    return self;
}

- (void)setChatHelper:(TMChatHelper *)chatHelper
{
    _chatHelper = chatHelper;
    self.ch = chatHelper;
//    [super setCh:chatHelper];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
    
    [self.dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(5);
        make.width.equalTo(self.contentView);
        make.height.mas_equalTo(15);
        make.leading.equalTo(self.contentView);
    }];
    if (self.chatHelper.isMe) {
//        [self.dateLabel mas_updateConstraints:^(MASConstraintMaker *make) {
//            make.height.mas_equalTo(CGFLOAT_MIN);
//        }];
        [self.avatarImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.dateLabel).offset(25);//25
            make.size.mas_equalTo(CGSizeMake(TMChatAvatarSize, TMChatAvatarSize));
            make.right.equalTo(self.contentView).offset(- 10);
        }];

        [self.contentTextView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView).offset(Bubble_Offset);
            make.right.equalTo(self.avatarImageView).offset(- TMChatAvatarSize - 15);
            make.size.mas_equalTo(self.chatHelper.size);
        }];
        [self.bubbleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentTextView).offset(- 5);
            make.right.equalTo(self.contentTextView).offset(10);
            make.width.equalTo(self.contentTextView).offset(15);
            make.height.equalTo(self.contentTextView).offset(10);
        }];
        self.bubbleImageView.image = [[UIImage imageNamed:Chat_Bubble_Me_ImageName] stretchableImageWithLeftCapWidth:10 topCapHeight:30];
        
        [self.activityView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.bubbleImageView.right).offset(- TMChatAvatarSize - self.chatHelper.size.width - 20);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
        [self.sendFailedButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.bubbleImageView.right).offset(- TMChatAvatarSize - self.chatHelper.size.width - 20);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
    }else
    {
        [self.avatarImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.dateLabel).offset(25);
            make.size.mas_equalTo(CGSizeMake(TMChatAvatarSize, TMChatAvatarSize));
            make.left.equalTo(self.contentView).offset(10);
        }];
        
        [self.contentTextView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView);
            make.left.equalTo(self.avatarImageView).offset(TMChatAvatarSize + 15);
            make.size.mas_equalTo(self.chatHelper.size);
        }];
        [self.bubbleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.contentTextView).offset(0);
            make.left.equalTo(self.contentTextView).offset(- 10);
            make.width.equalTo(self.contentTextView).offset(15);
            make.height.equalTo(self.contentTextView).offset(10);
        }];
        self.bubbleImageView.image = [[UIImage imageNamed:Chat_Bubble_Other_ImageName] stretchableImageWithLeftCapWidth:10 topCapHeight:30];
        
        [self.activityView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.bubbleImageView.left).offset(TMChatAvatarSize + self.chatHelper.size.width + 20);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
        [self.sendFailedButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.bubbleImageView.left).offset(TMChatAvatarSize + self.chatHelper.size.width + 20);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
    }
    
    self.contentTextView.backgroundColor = [UIColor clearColor];
    self.contentTextView.textColor = self.chatHelper.isMe ? [UIColor whiteColor] : [UIColor blackColor];
    
//    if ([self.chatHelper.contentText.string rangeOfString:@"http://" options:NSCaseInsensitiveSearch].length > 0 || [self.chatHelper.contentText.string rangeOfString:@"www" options:NSCaseInsensitiveSearch].length > 0 || [self.chatHelper.contentText.string rangeOfString:@".com" options:NSCaseInsensitiveSearch].length > 0 || [self.chatHelper.contentText.string rangeOfString:@".cn" options:NSCaseInsensitiveSearch].length > 0 || [self.chatHelper.contentText.string rangeOfString:@"html" options:NSCaseInsensitiveSearch].length > 0) {
//        
//        NSLog(@"NSCaseInsensitiveSearch");
        _contentTextView.selectable = YES;
        _contentTextView.userInteractionEnabled = NO;
//    }
    
}

- (void) bubbleLongPressed:(UILongPressGestureRecognizer *)longPress
{
    if (longPress.state != UIGestureRecognizerStateBegan) {
        return;
    }
    [self becomeFirstResponder];
    UIMenuItem * copyMenuItem = [[UIMenuItem alloc] initWithTitle:@"复制" action:@selector(copyMenuAction)];
    UIMenuItem * transMenuItem = [[UIMenuItem alloc] initWithTitle:@"转发" action:@selector(transMenuAction)];
//    UIMenuItem * itemCollect = [[UIMenuItem alloc] initWithTitle:@"收藏" action:@selector(collect)];
    UIMenuItem * trashMenuItem = [[UIMenuItem alloc] initWithTitle:@"删除" action:@selector(trashMenuAction)];
    UIMenuController * menuController = [UIMenuController sharedMenuController];
    [menuController setMenuItems: @[copyMenuItem, transMenuItem, trashMenuItem]];
//    CGPoint location = [longPress locationInView:[longPress view]];
//    CGRect menuLocation = CGRectMake(location.x, location.y, 0, 0);
    [menuController setTargetRect:self.bubbleImageView.bounds inView:[longPress view]];
    menuController.arrowDirection = UIMenuControllerArrowDown;
    
    [menuController setMenuVisible:YES animated:YES];
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if (action == @selector(copyMenuAction) || action == @selector(transMenuAction) || action == @selector(trashMenuAction)) {
        return YES;
    }
    return [super canPerformAction:action withSender:sender];
}

- (void)copyMenuAction
{
    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
    pasteboard.string = self.contentTextView.text;
}

- (void)transMenuAction
{
    
}

- (void)trashMenuAction
{
    !self.messageDeleteBlock ?: self.messageDeleteBlock(YES);
}

- (void) createSubviews
{
    self.contentTextView = [[UITextView alloc] initWithFrame:CGRectMake(0, 0, PhoneScreen_WIDTH - 80, 40)];
    self.contentTextView.editable = NO;
    self.contentTextView.scrollEnabled = NO;
//    self.contentTextView.selectionAffinity
//    self.contentTextView.userInteractionEnabled = NO;
    self.contentTextView.selectable = NO;
    self.contentTextView.font = [UIFont systemFontOfSize:17.f];
    self.contentTextView.backgroundColor = [UIColor grayColor];
    self.contentTextView.dataDetectorTypes = UIDataDetectorTypeAll;
    [self.contentView addSubview:self.contentTextView];
    
    self.contentTextView.userInteractionEnabled = NO;
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(bubbleLongPressed:)];
    //    longPress.minimumPressDuration = 1;
    self.bubbleImageView.userInteractionEnabled = YES;
    [self.bubbleImageView addGestureRecognizer:longPress];
    //    [self becomeFirstResponder];

}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
