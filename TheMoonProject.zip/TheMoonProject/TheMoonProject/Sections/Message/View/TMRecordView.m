//
//  TMRecordView.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/28.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMRecordView.h"
#import "LPGeneralHelper.h"

@implementation TMRecordView
{
    BOOL isRecording;
    NSString *_fileName;
    NSString *_filePath;
    __weak IBOutlet UILabel *lblDuration;
}

- (instancetype)init
{
    self = [[NSBundle mainBundle] loadNibNamed:@"TMRecordView" owner:self options:nil].lastObject;
    if (self) {
        
    }
    return self;
}
- (IBAction)recordButtonClicked:(id)sender {
    if (isRecording) {
        [self stopRecording];
        !_recordingStartBlock ?: _recordingStartBlock(YES);
        !_recordingStopBlock ?: _recordingStopBlock(YES, _filePath);
        return;
    }
    [self startRecording];
    lblDuration.text = @"00:00";
    [self startCountDown];
    !_recordingStartBlock ?: _recordingStartBlock(NO);
}


- (void) startCountDown
{
    [LPGeneralHelper countDownWithTime:60 countDownBlock:^(int timeLeft) {
        int seconds = timeLeft % 60;
        NSString *strTime = [NSString stringWithFormat:@"00:%.2d", 60 - seconds];
        lblDuration.text = strTime;
//        NSLog(@"%@", strTime);
    } endBlock:^{
        if (isRecording) {
            [self stopRecording];
        }
    }];
}



- (IBAction)recordButtonDownAction:(id)sender {
    NSLog(@"%s", __FUNCTION__);
}
- (IBAction)recordButtonExitAction:(id)sender {
    NSLog(@"%s", __FUNCTION__);
}

- (IBAction)playButtonClicked:(id)sender {
    
    [[PlayerManager sharedManager] playAudioWithFileName:_filePath];
}

- (IBAction)trashButtonClicked:(id)sender {
    if (_filePath) {
        NSError *error;
        [[NSFileManager defaultManager] removeItemAtPath:_filePath error:&error];
        if (error) {
            NSLog(@"%@", error.description);
        }
    }
}

- (void) startRecording
{
    _fileName = [NSUUID UUID].UUIDString;
    [RecorderManager sharedManager].delegate = self;
    [[RecorderManager sharedManager] startRecording:_fileName];
    isRecording = YES;
}

- (void) stopRecording
{
    [[RecorderManager sharedManager] stopRecording];
    isRecording = NO;
}

- (void)recordingFailed:(NSString *)failureInfoString
{
    NSLog(@"%s", __FUNCTION__);
}

- (void)recordingStopped
{
    NSLog(@"%s", __FUNCTION__);
}

- (void)recordingTimeout
{
    NSLog(@"%s", __FUNCTION__);
}

- (void)recordingFinishedWithFileName:(NSString *)filePath time:(NSTimeInterval)interval
{
    NSString *documentsDirectory = [NSSearchPathForDirectoriesInDomains(NSCachesDirectory,NSUserDomainMask, YES) objectAtIndex:0];
    
    _filePath = [documentsDirectory stringByAppendingPathComponent:[NSString stringWithFormat:@"/Voice/%@.spx", filePath]];
    
    NSLog(@"%@ %f", _filePath, interval);
}

@end
