//
//  TMRecordView.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/28.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "RecorderManager.h"
#import "PlayerManager.h"


typedef void(^RecordingStartBlock)(BOOL isStop);
typedef void(^RecordingStopBlock)(BOOL isStop, NSString *filePath);
@interface TMRecordView : UIView<RecordingDelegate>

@property (nonatomic, copy) RecordingStartBlock recordingStartBlock;
@property (nonatomic, copy) RecordingStopBlock recordingStopBlock;
@end
