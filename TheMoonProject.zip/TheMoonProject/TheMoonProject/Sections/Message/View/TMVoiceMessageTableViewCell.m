//
//  TMVoiceMessageTableViewCell.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/18.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMVoiceMessageTableViewCell.h"

@implementation TMVoiceMessageTableViewCell
{
    UIImageView *voiceImageView;
}

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier {
    if (self = [super initWithStyle:style reuseIdentifier:reuseIdentifier]) {
        // Initialization code
        if (!voiceImageView) {
            voiceImageView = [[UIImageView alloc] init];
            voiceImageView.image = [UIImage imageNamed:@"chat_voice_normal"];
            [self.bubbleImageView addSubview:voiceImageView];
            
            UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(bubbleLongPressed:)];
            //    longPress.minimumPressDuration = 1;
            self.bubbleImageView.userInteractionEnabled = YES;
            [self.bubbleImageView addGestureRecognizer:longPress];
        }
    }
    return self;
}

//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        
//    }
//    return self;
//}

- (void)setChatHelper:(TMChatHelper *)chatHelper
{
    _chatHelper = chatHelper;
    self.ch = chatHelper;
//    if (self.messageBubbleTapBlock) {
//        self.messageBubbleTapBlock(chatHelper);
//    }
}

- (void) bubbleLongPressed:(UILongPressGestureRecognizer *)longPress
{
    if (longPress.state != UIGestureRecognizerStateBegan) {
        return;
    }
    [self becomeFirstResponder];
    UIMenuItem * copyMenuItem = [[UIMenuItem alloc] initWithTitle:@"复制" action:@selector(copyMenuAction)];
    UIMenuItem * transMenuItem = [[UIMenuItem alloc] initWithTitle:@"转发" action:@selector(transMenuAction)];
    //    UIMenuItem * itemCollect = [[UIMenuItem alloc] initWithTitle:@"收藏" action:@selector(collect)];
    UIMenuItem * trashMenuItem = [[UIMenuItem alloc] initWithTitle:@"删除" action:@selector(trashMenuAction)];
    UIMenuController * menuController = [UIMenuController sharedMenuController];
    [menuController setMenuItems: @[copyMenuItem, transMenuItem, trashMenuItem]];
    [menuController setTargetRect:self.bubbleImageView.bounds inView:[longPress view]];
    menuController.arrowDirection = UIMenuControllerArrowDown;
    
    [menuController setMenuVisible:YES animated:YES];
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if (action == @selector(copyMenuAction) || action == @selector(transMenuAction) || action == @selector(trashMenuAction)) {
        return YES;
    }
    return [super canPerformAction:action withSender:sender];
}

- (void)copyMenuAction
{
//    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
}

- (void)transMenuAction
{
    
}

- (void)trashMenuAction
{
    !self.messageDeleteBlock ?: self.messageDeleteBlock(YES);
}


- (void)layoutSubviews
{
    [super layoutSubviews];
    
    [self.dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(5);
        make.width.equalTo(self.contentView);
        make.height.mas_equalTo(15);
        make.leading.equalTo(self.contentView);
    }];
    
    BOOL isMe = self.chatHelper.isMe;
    if (isMe) {
        [self.avatarImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.dateLabel).offset(20);
            make.size.mas_equalTo(CGSizeMake(TMChatAvatarSize, TMChatAvatarSize));
            make.right.equalTo(self.contentView).offset(- 10);
        }];
        [self.bubbleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView).offset(5 / 2);
            make.right.equalTo(self.avatarImageView).offset(- TMChatAvatarSize - 5);
            make.width.mas_equalTo(100);
            make.height.mas_equalTo(45);
        }];
        self.bubbleImageView.image = [[UIImage imageNamed:Chat_Bubble_Me_ImageName] stretchableImageWithLeftCapWidth:10 topCapHeight:30];
        [voiceImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.equalTo(self.bubbleImageView).offset(-15);
            make.centerY.equalTo(self.bubbleImageView);
            make.width.height.mas_equalTo(15);
        }];
        
        [self.activityView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.bubbleImageView.right).offset(- TMChatAvatarSize - 105);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
//        self.activityView.hidden = YES;
        [self.sendFailedButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.bubbleImageView.right).offset(- TMChatAvatarSize - 105);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
        
    }else
    {
        [self.avatarImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.dateLabel).offset(17);
            make.size.mas_equalTo(CGSizeMake(TMChatAvatarSize, TMChatAvatarSize));
            make.left.equalTo(self.contentView).offset(10);
        }];
        [self.bubbleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView).offset(5/ 2);
            make.left.equalTo(self.avatarImageView).offset(TMChatAvatarSize + 5);
            make.width.mas_equalTo(100);
            make.height.mas_equalTo(45);
        }];
        self.bubbleImageView.image = [[UIImage imageNamed:Chat_Bubble_Other_ImageName] stretchableImageWithLeftCapWidth:10 topCapHeight:30];
        [voiceImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.bubbleImageView).offset(15);
            make.centerY.equalTo(self.bubbleImageView);
            make.width.height.mas_equalTo(15);
        }];
        [self.activityView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.bubbleImageView.left).offset(TMChatAvatarSize + 105);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
        [self.sendFailedButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.bubbleImageView.left).offset(TMChatAvatarSize + 105);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
    }
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
