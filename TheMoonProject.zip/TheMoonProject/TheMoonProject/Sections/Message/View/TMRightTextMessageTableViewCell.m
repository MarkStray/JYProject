//
//  TMRightTextMessageTableViewCell.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMRightTextMessageTableViewCell.h"

@implementation TMRightTextMessageTableViewCell

- (instancetype)init
{
    self = [[NSBundle mainBundle] loadNibNamed:@"TMRightTextMessageTableViewCell" owner:self options:nil].lastObject;
    if (self) {    }
    return self;
}

- (void)changeTextWidthLayout:(CGFloat)width
{
    self.widthLayoutConstraint.constant = width;
}

- (void)changeTextHeightLayout:(CGFloat)height
{
    self.heightLayoutConstraint.constant = height;
//    [self.textView sizeToFit];
//    NSLog(@"%@", self.textView.font);
//    [self.textView scrollRectToVisible:CGRectZero animated:NO];
}

- (void)layoutSubviews
{
    [super layoutSubviews];
}

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
