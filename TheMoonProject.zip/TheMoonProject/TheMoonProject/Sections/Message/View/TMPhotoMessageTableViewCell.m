//
//  TMPhotoMessageTableViewCell.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/23.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMPhotoMessageTableViewCell.h"

@implementation TMPhotoMessageTableViewCell

-(instancetype)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self createSubviews];
    }
    return self;
}

- (void)setChatHelper:(TMChatHelper *)chatHelper
{
    _chatHelper = chatHelper;
    self.ch = chatHelper;
}

- (void) createSubviews
{
    self.photoView = [[UIImageView alloc] init];
    self.photoView.layer.cornerRadius = 3;
    self.photoView.layer.masksToBounds = YES;
    [self.contentView addSubview:self.photoView];
    
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(bubbleLongPressed:)];
    //    longPress.minimumPressDuration = 1;
    self.bubbleImageView.userInteractionEnabled = YES;
    [self.bubbleImageView addGestureRecognizer:longPress];
    //    [self becomeFirstResponder];

//    self.maskImageView = [UIImageView new];
}
- (void)layoutSubviews
{
    [super layoutSubviews];
    [self.dateLabel mas_makeConstraints:^(MASConstraintMaker *make) {
        make.top.mas_equalTo(5);
        make.width.equalTo(self.contentView);
        make.height.mas_equalTo(15);
        make.leading.equalTo(self.contentView);
    }];
    
    BOOL isMe = self.chatHelper.isMe;
    if (isMe) {
        [self.avatarImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.dateLabel).offset(20);
            make.size.mas_equalTo(CGSizeMake(TMChatAvatarSize, TMChatAvatarSize));            make.right.equalTo(self.contentView).offset(- 10);
        }];
        
        [self.photoView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView).offset(3);
            make.right.equalTo(self.avatarImageView).offset(- TMChatAvatarSize - 15);
            //            make.width.mas_equalTo(220);
            //            make.height.mas_equalTo(170);
            make.size.mas_equalTo(self.chatHelper.size);
        }];
        
        [self.bubbleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView).offset(0);
            make.right.equalTo(self.avatarImageView).offset(- TMChatAvatarSize - 6);
            make.width.mas_equalTo(self.chatHelper.size.width + 15);
            make.height.mas_equalTo(self.chatHelper.size.height + 8);
//            make.size.mas_equalTo(self.chatHelper.size);
//            make.width.mas_equalTo(self.chatHelper.size.width);
//            make.height.mas_equalTo(170);
        }];
        
//        self.photoView.backgroundColor = [UIColor orangeColor];
//        self.photoView.image = [UIImage imageNamed:@"Chat_Bubble_Other_ImageName"];
        self.photoView.image = self.chatHelper.image;
        //[[UIImage imageNamed:Chat_Bubble_Other_ImageName] stretchableImageWithLeftCapWidth:50 topCapHeight:30];
        self.bubbleImageView.image = [[UIImage imageNamed:Chat_Bubble_Me_ImageName] stretchableImageWithLeftCapWidth:10 topCapHeight:30];
//        self.bubbleImageView.clipsToBounds = YES;
//        self.bubbleImageView.layer.mask = self.maskImageView.layer;
//        [self.maskImageView mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.top.equalTo(self.bubbleImageView);
//            make.right.equalTo(self.bubbleImageView);
//            make.size.equalTo(self.bubbleImageView);
//        }];
//        self.maskImageView.image = self.bubbleImageView.image;
        
        [self.activityView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.bubbleImageView.right).offset(- TMChatAvatarSize - self.chatHelper.size.width - 20);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
        //        self.activityView.hidden = YES;
        [self.sendFailedButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.bubbleImageView.right).offset(- TMChatAvatarSize - self.chatHelper.size.width - 20);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
        
    }else
    {
        [self.avatarImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.mas_equalTo(self.dateLabel).offset(20);
            make.size.mas_equalTo(CGSizeMake(TMChatAvatarSize, TMChatAvatarSize));
            make.left.equalTo(self.contentView).offset(10);
        }];
        
        [self.photoView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView).offset(0);
            make.left.equalTo(self.avatarImageView).offset(TMChatAvatarSize + 15);
            
            make.size.mas_equalTo(self.chatHelper.size);
        }];
        [self.bubbleImageView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.avatarImageView).offset(0);
            make.left.equalTo(self.avatarImageView).offset(TMChatAvatarSize + 6);
            make.width.mas_equalTo(self.chatHelper.size.width + 15);
            make.height.mas_equalTo(self.chatHelper.size.height + 5);
        }];
        self.photoView.image = self.chatHelper.image;
        self.bubbleImageView.image = [[UIImage imageNamed:Chat_Bubble_Other_ImageName] stretchableImageWithLeftCapWidth:10 topCapHeight:30];
        
        [self.activityView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.bubbleImageView.left).offset(TMChatAvatarSize + self.chatHelper.size.width + 20);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
        [self.sendFailedButton mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.bubbleImageView.left).offset(TMChatAvatarSize + self.chatHelper.size.width + 20);
            make.centerY.equalTo(self.bubbleImageView);
            make.size.mas_equalTo(CGSizeMake(50, 50));
        }];
    }
}

- (void) bubbleLongPressed:(UILongPressGestureRecognizer *)longPress
{
    if (longPress.state != UIGestureRecognizerStateBegan) {
        return;
    }
    [self becomeFirstResponder];
    UIMenuItem * copyMenuItem = [[UIMenuItem alloc] initWithTitle:@"复制" action:@selector(copyMenuAction)];
    UIMenuItem * transMenuItem = [[UIMenuItem alloc] initWithTitle:@"转发" action:@selector(transMenuAction)];
    //    UIMenuItem * itemCollect = [[UIMenuItem alloc] initWithTitle:@"收藏" action:@selector(collect)];
    UIMenuItem * trashMenuItem = [[UIMenuItem alloc] initWithTitle:@"删除" action:@selector(trashMenuAction)];
    UIMenuController *menuController = [UIMenuController sharedMenuController];
    [menuController setMenuItems: @[copyMenuItem, transMenuItem, trashMenuItem]];
    //    CGPoint location = [longPress locationInView:[longPress view]];
    //    CGRect menuLocation = CGRectMake(location.x, location.y, 0, 0);
    [menuController setTargetRect:self.bubbleImageView.bounds inView:[longPress view]];
    menuController.arrowDirection = UIMenuControllerArrowDown;
    
    [menuController setMenuVisible:YES animated:YES];
}

+ (void)setMenuControllerAvaible:(BOOL)avaible animated:(BOOL)animated
{
    [[UIMenuController sharedMenuController] setMenuVisible:avaible animated:animated];
}

- (BOOL)canPerformAction:(SEL)action withSender:(id)sender
{
    if (action == @selector(copyMenuAction) || action == @selector(transMenuAction) || action == @selector(trashMenuAction)) {
        return YES;
    }
    return [super canPerformAction:action withSender:sender];
}

- (void)copyMenuAction
{
//    UIPasteboard *pasteboard = [UIPasteboard generalPasteboard];
}

- (void)transMenuAction
{
    
}

- (void)trashMenuAction
{
    !self.messageDeleteBlock ?: self.messageDeleteBlock(YES);
}


@end
