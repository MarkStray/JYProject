//
//  TMVoiceMessageTableViewCell.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/18.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TMBaseMessageTableViewCell.h"
@interface TMVoiceMessageTableViewCell : TMBaseMessageTableViewCell

//- (void)changeContentSize;
@property (nonatomic, strong) TMChatHelper *chatHelper;
@end
