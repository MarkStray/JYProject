//
//  TMContactsTableViewCell.h
//  TheMoonProject
//
//  Created by 藏云柱 on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMContactsTableViewCell : UITableViewCell
/**
 *  好友头像
 */
@property (weak, nonatomic) IBOutlet UIImageView *userImgView;
/**
 *  好友名称
 */
@property (weak, nonatomic) IBOutlet UILabel *nameLab;
///**
// *  好友电话
// */
//@property (weak, nonatomic) IBOutlet UILabel *phoneNumLab;
/**
 *  分割线
 */
@property (weak, nonatomic) IBOutlet UILabel *lineLab;

/**
 *  接收数据方法
 */
-(void)getMessage:(NSMutableArray *)dataArr andWith:(NSIndexPath *)indexPath andWith:(BOOL)isSearchNow;
@end
