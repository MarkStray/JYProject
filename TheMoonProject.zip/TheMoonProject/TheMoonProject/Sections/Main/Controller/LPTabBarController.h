//
//  LPTabBarController.h
//  LPTabbarController
//
//  Created by MacBook on 16/3/11.
//  Copyright © 2016年 lipeng. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPTabBarController : UITabBarController
- (instancetype)initWithViewControllers:(NSArray *)viewContorllers;
@end
