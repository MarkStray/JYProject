//
//  LPTabbarItemView.h
//  TheMoonProject
//
//  Created by MacBook on 16/3/16.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LPTabbarItemView : UIView

@property (weak, nonatomic) IBOutlet UIImageView *icon;
@property (weak, nonatomic) IBOutlet UILabel *lblTitle;

@property (copy, nonatomic) NSString *normalIconName;
@property (copy, nonatomic) NSString *selectIconName;
@property (assign, nonatomic) BOOL selected;

@end
