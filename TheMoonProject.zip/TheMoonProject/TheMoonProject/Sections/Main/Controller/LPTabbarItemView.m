//
//  LPTabbarItemView.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/16.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "LPTabbarItemView.h"

@implementation LPTabbarItemView

- (instancetype)init
{
    self = [[NSBundle mainBundle] loadNibNamed:@"LPTabbarItemView" owner:self options:nil].lastObject;
    if (self) {
        self.backgroundColor = [UIColor whiteColor];
    }
    return self;
}

- (void)setNormalIconName:(NSString *)normalIconName
{
    self.icon.image = [UIImage imageNamed:normalIconName];
    _normalIconName = normalIconName;
}

- (void)setSelected:(BOOL)selected
{
    if (selected) {
        self.icon.image = [UIImage imageNamed:self.selectIconName];
        self.lblTitle.textColor = ROOT_TINT_COLOR;
    }else
    {
        self.icon.image = [UIImage imageNamed:self.normalIconName];
        self.lblTitle.textColor = RGBCOLOR(164, 164, 164, 1);
    }
}

- (BOOL)selected
{
    return self.selected;
}

@end
