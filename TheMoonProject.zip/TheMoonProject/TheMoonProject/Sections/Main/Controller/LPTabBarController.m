//
//  LPTabBarController.m
//  LPTabbarController
//
//  Created by MacBook on 16/3/11.
//  Copyright © 2016年 lipeng. All rights reserved.
//

#import "LPTabBarController.h"
#import "LPTabbarItemView.h"
@interface LPTabBarController ()

@end

@implementation LPTabBarController
{
    UIView *tabbarView;
}

- (instancetype)initWithViewControllers:(NSArray *)viewContorllers
{
    self = [super init];
    if (self) {
        self.tabBar.shadowImage = [UIImage new];
        self.tabBar.backgroundImage = [UIImage new];
        self.viewControllers = viewContorllers;
        [self.tabBar addSubview:[self tabbarView]];
        
        CGFloat oneWidth = self.tabBar.frame.size.width / 5;
        
        NSArray *normalIcons = @[@"home_normal", @"management_normal", @"message_normal", @"contacts_normal", @"me_normal"];
        NSArray *selectIcons = @[@"home_select", @"management_select", @"message_select", @"contacts_select", @"me_select"];
//        NSArray *titles = @[@"首页", @"进销存", @"消息", @"通讯录", @"我的"];
        
        UILabel *lblLine = [[UILabel alloc] initWithFrame:CGRectMake(0, 0, self.tabBar.frame.size.width, 1)];
//        lblLine.backgroundColor = [UIColor redColor];
        lblLine.backgroundColor = RGBCOLOR(233, 233, 233, 1);
        [self.tabBar addSubview:lblLine];
        
        
        for (NSInteger i = 0; i < self.viewControllers.count; i ++) {
            
            UIButton *squareButton = [UIButton buttonWithType:UIButtonTypeSystem];
            squareButton.frame = CGRectMake(oneWidth * i, 0, oneWidth, self.tabBar.frame.size.height);
//            NSLog(@"%f", self.tabBar.frame.size.height);
            squareButton.backgroundColor = [UIColor whiteColor];
            [squareButton addTarget:self action:@selector(btnClicked:) forControlEvents:UIControlEventTouchUpInside];
            squareButton.tag = i + 100;
            
            
            LPTabbarItemView *itemView = [[LPTabbarItemView alloc] init];
            itemView.frame = CGRectMake((squareButton.frame.size.width - 45) / 2, (squareButton.frame.size.height - 45) / 2, 45, 45);
            itemView.lblTitle.textColor = [UIColor grayColor];
            itemView.lblTitle.text = self.viewControllers[i].title;
            itemView.normalIconName = normalIcons[i];
            itemView.selectIconName = selectIcons[i];
            itemView.tag = i + 200;
//            itemView.icon.image = [UIImage imageNamed:normalIcons[i]];
//            itemView.center = squareView.center;
            [squareButton addSubview:itemView];
            [tabbarView addSubview:squareButton];
//            break;
//            UIButton *tabbarItem = [UIButton buttonWithType:UIButtonTypeCustom];
//            tabbarItem.frame = CGRectMake(oneWidth * i, 0, oneWidth - 0.5, self.tabBar.frame.size.height);
//            UINavigationController *nav = self.viewControllers[i];
//            [tabbarItem setTitle:nav.topViewController.title forState:UIControlStateNormal];
            
//            tabbarItem.backgroundColor = [UIColor grayColor];
//            [tabbarView addSubview:tabbarItem];
            //badge button
//            UIButton *badge = [UIButton buttonWithType:UIButtonTypeCustom];
//            badge.frame = CGRectMake(43, 5, 18, 18);
//            [badge setTitle:@"1" forState:UIControlStateNormal];
//            badge.backgroundColor = [UIColor redColor];
//            badge.userInteractionEnabled = NO;
//            badge.titleLabel.font = [UIFont systemFontOfSize:14];
//            badge.layer.cornerRadius = 18 / 2;
//            badge.layer.masksToBounds = YES;
            
//            [tabbarItem addSubview:badge];
//            [badge bringSubviewToFront:tabbarItem];
//            [tabbarView bringSubviewToFront:badge];
        }
        UIButton *btn = (UIButton *)[tabbarView viewWithTag:100];
        [btn setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
    }
    return self;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
    
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
//    self.tabBar.backgroundColor = [UIColor whiteColor];
//    self.viewControllers[0].tabBarItem.image = [UIImage imageNamed:@"5.png"];
//    self.tabBar.backgroundColor = [UIColor clearColor];
//    self.tabBar.barStyle = UIBarStyleBlack;
//    self.tabBar.barTintColor = [UIColor blackColor];
    
}

- (UIView *)tabbarView
{
//    self.tabBar.frame
    tabbarView = [[UIView alloc] initWithFrame:CGRectMake(CGRectGetMinX(self.tabBar.bounds), CGRectGetMinY(self.tabBar.bounds) + 0.5, CGRectGetWidth(self.tabBar.bounds), CGRectGetHeight(self.tabBar.bounds) - 0.5)];
    tabbarView.backgroundColor = [UIColor whiteColor];
   
    
    
    return tabbarView;
}

- (void)setSelectedIndex:(NSUInteger)selectedIndex
{
//    if (self.selectedIndex == selectedIndex) {
//        return;
//    }
//    self.selectedIndex = selectedIndex;
//    NSLog(@"index %lu", (unsigned long)selectedIndex);
    for (UIButton *squareButton in tabbarView.subviews) {
        
        LPTabbarItemView *itemView = squareButton.subviews[0];
        
        if (itemView.tag == selectedIndex + 200) {
            itemView.selected = YES;
        }else
        {
            itemView.selected = NO;
        }
    }
    [super setSelectedIndex:selectedIndex];
    
}

- (IBAction)btnClicked:(UIButton *)sender
{
    if (self.selectedIndex + 100 == sender.tag) {
        NSLog(@"return");
        return;
    }
//    self.selectedIndex = sender.tag - 100;
    [self setSelectedIndex:sender.tag - 100];
    
//    sender.titleLabel.textColor = self.navigationController.navigationBar.tintColor;
    
    
//    UIButton *selectedItem = (UIButton *)[tabbarView viewWithTag:selectedIndex + 100];
//    for (UIButton *squareButton in tabbarView.subviews) {
////        NSLog(@"%ld %ld", (long)item.tag, (long)selectedItem.tag);
////        [squareButton setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//        LPTabbarItemView *itemView = squareButton.subviews[0];
//        
//        if (itemView.tag == sender.tag + 100) {
//            itemView.selected = YES;
////            [sender setTitleColor:[UIColor orangeColor] forState:UIControlStateNormal];
//        }else
//        {
//            itemView.selected = NO;
//        }
//    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
