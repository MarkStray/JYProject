//
//  TMHomeViewController.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/11.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMHomeViewController.h"
#import "TMHomeGridCell.h"
#import "TMHomeCustomerMeaasgeView.h"
#import "TMHomeAddCellView.h"
#import "TMGridItemModel.h"
#import "TMSectionThreeModel.h"
#import "TMAddMoreViewController.h"
#import "TMHomeSectionThreeView.h"
#import "UIViewExt.h"
#import "TMCollectMoneyViewController.h"
#import "TMPayAttentionViewController.h"
#import "TMVIPViewController.h"
#import "TMShopCenterViewController.h"
#import "TMCustomerWordViewController.h"
#import "TMSearchViewController.h"
#import "TMMovingAppearenceViewController.h"
#import "TMMaintainViewController.h"
#import "TMGoodsManagerViewController.h"
#import "TMShopDiscountViewController.h"
#import "TMShopPreferentialViewController.h"
#import "TMShopInfomationViewController.h"
#import "TMShopActivityViewController.h"
#import "TMOrderViewController.h"
#import "TMMyAchievementViewController.h"
#import "TMMyEvalutionViewController.h"
#import "TMImmetiateMarketViewController.h"
#import "TMEncourageViewController.h"
#import "TMAppointmentViewController.h"

#define LineWidth 0.75

#define PhoneScreenWidth  [UIScreen mainScreen].bounds.size.width
#define PhoneScreenHeight [UIScreen mainScreen].bounds.size.height

@interface TMHomeViewController ()<UIScrollViewDelegate>
/**
 *  最上面一部分view
 */
@property (nonatomic, strong) UIView *headerView;
/**
 *  网格collectionView
 */
@property (nonatomic, strong) UIScrollView *gridScrollView;
/**
 *  第一分区数据源
 */
@property (nonatomic, strong) NSMutableArray *sectionOneDataArray;
/**
 *  第三分区数据源
 */
@property (nonatomic, strong) NSMutableArray *sectionThreeDataArray;
/**
 *  item数组
 */
@property (nonatomic, strong) NSMutableArray *cellViewArray;
/**
 *  itemFrame数组
 */
@property (nonatomic, strong) NSMutableArray *cellViewFrameArray;
/**
 *  用来记录手势刚开始时的位置
 */
@property (nonatomic, assign) CGRect currentCellViewFrame;
/**
 *  用来记录当前是哪个item
 */
@property (nonatomic, strong) TMHomeGridCell *currentCellView;
/**
 *  用来占位的一个view
 */
@property (nonatomic, strong) UIView *placeholeView;
/**
 *  记录最后的坐标
 */
@property (nonatomic, assign) CGPoint lastPoint;
/**
 *  删除的时候 保存删除的 cell
 */
@property (nonatomic, strong) TMHomeGridCell *deleteCellView;
/**
 *  右上角按钮
 */
@property (nonatomic, strong) UIBarButtonItem *rightBarButtonItem;

@end

@implementation TMHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initLocationData];
    [self.view addSubview:self.headerView];
    [self.view addSubview:self.gridScrollView];
    [self doWithRightBarButtonItem];
}

- (void)viewWillAppear:(BOOL)animated {
    [super viewWillAppear:animated];
    
    //  去除导航栏边线
    [self.navigationController.navigationBar setBackgroundImage:[[UIImage alloc]init] forBarMetrics:UIBarMetricsDefault];
    [self.navigationController.navigationBar setShadowImage:[[UIImage alloc]init]];
    
    // 从更多回来 需要刷新
    [self doWithData];
    [self doWithCreatSectionOneSubViews];
    [self doWithCreatOtherSection];

}

#pragma mark - 配置本地数据
- (void)initLocationData {
    
    NSArray *locationArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"LocationData"];
    
    //登录 标识 登录成功之后 保存
    [[NSUserDefaults standardUserDefaults] setObject:@"userID" forKey:@"USER_TYPE"];
    
    if (!locationArr) {
        NSMutableArray *dataArr = [NSMutableArray arrayWithArray:@[
                                                                   @{@"title":@"商品管理",@"imageStr":@"i01"},
                                                                   @{@"title":@"本店优惠",@"imageStr":@"i02"},
                                                                   @{@"title":@"本店打折",@"imageStr":@"i03"},
                                                                   @{@"title":@"本店信息",@"imageStr":@"i04"},
                                                                   @{@"title":@"本店活动",@"imageStr":@"i05"},
                                                                   @{@"title":@"订单",@"imageStr":@"i06"},
                                                                   @{@"title":@"我的业绩",@"imageStr":@"i07"},
                                                                   @{@"title":@"我的评价",@"imageStr":@"i08"},
                                                                   @{@"title":@"即时营销",@"imageStr":@"i09"},
                                                                   @{@"title":@"激励",@"imageStr":@"i10"},
                                                                   @{@"title":@"预约",@"imageStr":@"i11"},
                                                                   @{@"title":@"更多",@"imageStr":@"tf_home_more"}]];
        [[NSUserDefaults standardUserDefaults] setObject:[dataArr copy] forKey:@"LocationData"];
        [[NSUserDefaults standardUserDefaults] synchronize];
        
    }
    
    //
    NSArray *locationDeleteArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"LocationDeleteData"];
    
    if (!locationDeleteArr) {
        [[NSUserDefaults standardUserDefaults] setObject:[NSArray array] forKey:@"LocationDeleteData"];
        [[NSUserDefaults standardUserDefaults] synchronize];
    }
}
#pragma mark - 初始化数据
- (void)doWithData {
    
    //初始化第一分数数据源
    if (self.sectionOneDataArray) {
        [self.sectionOneDataArray removeAllObjects];
    } else {
        self.sectionOneDataArray = [NSMutableArray array];
    }
    
    //读取本地数据
    NSArray *locationArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"LocationData"];
    
    for (NSDictionary *dict in locationArr) {
        TMGridItemModel *model = [[TMGridItemModel alloc] init];
        model.title = dict[@"title"];
        model.imageStr = dict[@"imageStr"];
        [self.sectionOneDataArray addObject:model];
    }
    
    //初始化第三分区数据源
    if (self.sectionThreeDataArray) {
        [self.sectionThreeDataArray removeAllObjects];
    } else {
        self.sectionThreeDataArray = [NSMutableArray array];
    }
    
    NSMutableArray *arr = [NSMutableArray arrayWithArray:@[
                                                           @{@"title":@"搜索",@"imageStr":@"i13"},
                                                           @{@"title":@"动态",@"imageStr":@"i14"},
                                                           @{@"title":@"维系",@"imageStr":@"i15"}]];
    for (int i = 0; i<arr.count; i++) {
        TMSectionThreeModel *model = [[TMSectionThreeModel alloc] init];
        model.title = arr[i][@"title"];
        model.imageStr = arr[i][@"imageStr"];
        [self.sectionThreeDataArray addObject:model];
    }
    
    //初始化存放cell的数组
    if (self.cellViewArray) {
        [self.cellViewArray removeAllObjects];
    } else {
        self.cellViewArray = [NSMutableArray array];
    }
    
    //初始化存放cellFrame的数组
    if (self.cellViewFrameArray) {
        [self.cellViewFrameArray removeAllObjects];
    } else {
        self.cellViewFrameArray = [NSMutableArray array];
    }
    
    //清除 原来的 子视图
    [self.gridScrollView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    self.placeholeView = [[UIView alloc] init];
    
}

#pragma mark - 创建头部view
- (UIView *)headerView {
    if (!_headerView) {
        
        _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, PhoneScreenWidth, 70)];
        _headerView.backgroundColor = [UIColor colorWithRed:(14/255.0) green:(168/255.0) blue:(225/255.0) alpha:1];
        
        for (NSInteger i = 0; i < 4; i++) {
            UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake(PhoneScreenWidth/4*i, 0, PhoneScreenWidth/4, 80)];
            button.tag = 888+i;
            [button addTarget:self action:@selector(headerButtonClick:) forControlEvents:UIControlEventTouchUpInside];
            [_headerView addSubview:button];
            
            UIImageView *imageView = [[UIImageView alloc] initWithFrame:CGRectMake((PhoneScreenWidth/4-30)/2, 10, 30, 30)];
            imageView.image = [UIImage imageNamed:[NSString stringWithFormat:@"%@%ld", @"home_icon_",(long)i]];
            
            [button addSubview:imageView];
            
            UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake((PhoneScreenWidth/4-50)/2, 45, 50, 15)];
            NSArray *textArr = @[@"收款",@"关注",@"会员卡",@"商城"];
            label.text = textArr[i];
            label.textAlignment = NSTextAlignmentCenter;
            label.textColor = [UIColor whiteColor];
            label.font = [UIFont systemFontOfSize:14];
            [button addSubview:label];
        }
    }
    return _headerView;
}

#pragma mark - 头部按钮点击事件
- (void)headerButtonClick:(UIButton *)button {
    
    switch (button.tag) {
        case 888://收款
        {
            TMCollectMoneyViewController *vc = [[TMCollectMoneyViewController alloc] init];
            [vc setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:vc animated:YES];
            
        }
            break;
        case 889://关注
        {
            TMPayAttentionViewController *vc = [[TMPayAttentionViewController alloc] init];
            [vc setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 890://会员卡
        {
            TMVIPViewController *vc = [[TMVIPViewController alloc] init];
            [vc setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        case 891://商城
        {
            TMShopCenterViewController *vc = [[TMShopCenterViewController alloc] init];
            [vc setHidesBottomBarWhenPushed:YES];
            [self.navigationController pushViewController:vc animated:YES];
        }
            break;
        default:
            break;
    }
    
}

#pragma mark - 创建右上角按钮
- (void)doWithRightBarButtonItem {
    _rightBarButtonItem = [[UIBarButtonItem alloc] initWithImage:[[UIImage imageNamed:@"BarButtonItem"] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal]style:UIBarButtonItemStyleDone target:self action:@selector(rightBarButtonItemClick:)];
    self.navigationItem.rightBarButtonItem = _rightBarButtonItem;
}

#pragma mark - 右上角点击事件
- (void)rightBarButtonItemClick:(UIBarButtonItem *)item {
    
    UIViewController *vc = [[UIViewController alloc] init];
    vc.view.backgroundColor = [UIColor orangeColor];
    [vc setHidesBottomBarWhenPushed:YES];
    [self.navigationController pushViewController:vc animated:YES];
    
}

#pragma mark - 创建collectionView
- (UIScrollView *)gridScrollView {
    if (!_gridScrollView) {
        
        _gridScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 70, PhoneScreenWidth, PhoneScreenHeight-70)];
        if (PhoneScreen_HEIGHT == 480) {
            _gridScrollView.contentSize = CGSizeMake(PhoneScreen_WIDTH, PhoneScreen_HEIGHT+20);
        }
        _gridScrollView.backgroundColor = [UIColor whiteColor];
        _gridScrollView.showsVerticalScrollIndicator = NO;
        _gridScrollView.delegate = self;
        
        // 当数据不多，collectionView.contentSize小于collectionView.frame.size的时候，UICollectionView是不会滚动的。//设置
        _gridScrollView.bounces = YES;
        _gridScrollView.alwaysBounceVertical = YES;
        
    }
    return _gridScrollView;
}


#pragma mark - 创建第一分区视图
-(void)doWithCreatSectionOneSubViews{

    float itemWidth = PhoneScreen_WIDTH/4;
    
    for (int i = 0; i < self.sectionOneDataArray.count; i++) {
        
        int a = i/4;
        int b = i%4;
        
        if (i == self.sectionOneDataArray.count - 1) {
            
            //加载 添加视图
            TMHomeAddCellView *addMoreCollectionView = [[[NSBundle mainBundle]loadNibNamed:@"TMHomeAddCellView" owner:self options:nil] lastObject];
            addMoreCollectionView.frame = CGRectMake(b*itemWidth, a*itemWidth, itemWidth, itemWidth);
            [self.gridScrollView addSubview:addMoreCollectionView];
            
            addMoreCollectionView.tag = 1000 + i;
            
            TMGridItemModel *model = self.sectionOneDataArray[i];
            [addMoreCollectionView setModel:model];
            
            //点击事件
            addMoreCollectionView.tapOperationBlock = ^ (UITapGestureRecognizer *gesture) {
                [self tapAction:gesture];
            };
            
            [self doWithAddCellFrameWith:addMoreCollectionView index:i];
            //线条
            [self addSeparatorLineWithIndex:i];
        } else {
            
            TMHomeGridCell *gridCollectionView = [[[NSBundle mainBundle]loadNibNamed:@"TMHomeGridCell" owner:self options:nil]lastObject];
            gridCollectionView.frame = CGRectMake(b*itemWidth, a*itemWidth, itemWidth, itemWidth);
            [self.gridScrollView addSubview:gridCollectionView];
            
            gridCollectionView.tag = 1000 + i;

            TMGridItemModel *model = self.sectionOneDataArray[i];
            [gridCollectionView setModel:model];
            
            //长按事件
            gridCollectionView.longPressBlock = ^ (UILongPressGestureRecognizer *gesture) {
                [self handleLongPress:gesture];
            };

            //删除事件
            gridCollectionView.deleteButtonClickBlock = ^ (TMHomeGridCell *cellView) {
                [self deleteView:cellView];
            };
            
            //点击事件
            gridCollectionView.tapOperationBlock = ^ (UITapGestureRecognizer *gesture) {
                [self tapAction:gesture];
            };
            
            [self doWithAddCellFrameWith:gridCollectionView index:i];
            [self addSeparatorLineWithIndex:i];
        }
    }
}

-(void)doWithAddCellFrameWith:(UIView*)view index:(int)index{
    
    if (index < self.sectionOneDataArray.count) {
        
        //添加更多 view
        if (index == self.sectionOneDataArray.count-1) {
            
            TMHomeAddCellView *addMoreView = (TMHomeAddCellView*)view;
            [self.cellViewArray addObject:addMoreView];
            
            NSValue *frameValue = [NSValue valueWithCGRect:addMoreView.frame];
            [self.cellViewFrameArray addObject:frameValue];
        }else {
            
            TMHomeGridCell *gridView = (TMHomeGridCell*)view;
            [self.cellViewArray addObject:gridView];
            
            NSValue *frameValue = [NSValue valueWithCGRect:gridView.frame];
            [self.cellViewFrameArray addObject:frameValue];
        }
    }
}


#pragma mark - 创建第二三分区视图
-(void)doWithCreatOtherSection{
    
    int number;
    int a = self.sectionOneDataArray.count/4;
    int b = self.sectionOneDataArray.count%4;
    
    if (b == 0) {
        number = a;
    }else{
        number = a+1;
    }
    float itemWidth = PhoneScreen_WIDTH/4;
    
    //初始化第二组
    TMHomeCustomerMeaasgeView *customerMessageView = [[[NSBundle mainBundle]loadNibNamed:@"TMHomeCustomerMeaasgeView" owner:self options:nil]lastObject];
    customerMessageView.tag = 500;
    customerMessageView.frame = CGRectMake( 0, number*itemWidth, PhoneScreen_WIDTH, 60);
    [self.gridScrollView addSubview:customerMessageView];
    
    //点击事件
    customerMessageView.tapOperationBlock = ^ (UITapGestureRecognizer *gesture) {
        [self tapAction:gesture];
    };

    //初始化第三组
    for (int i = 0; i < self.sectionThreeDataArray.count; i++) {
        
        int a = i/4;
        int b = i%4;
        
        TMHomeSectionThreeView *sectionThCollectionView = [[[NSBundle mainBundle]loadNibNamed:@"TMHomeSectionThreeView" owner:self options:nil]lastObject];
        
        sectionThCollectionView.frame = CGRectMake(b*itemWidth+b*LineWidth, a*itemWidth+customerMessageView.bottom, itemWidth-LineWidth, itemWidth-LineWidth);
        sectionThCollectionView.tag = 200 + i;
        TMSectionThreeModel *model = self.sectionThreeDataArray[i];
        [sectionThCollectionView setModelThree:model];
        
        //点击事件
        sectionThCollectionView.tapOperationBlock = ^ (UITapGestureRecognizer *gesture) {
            [self tapAction:gesture];
        };

        [self.gridScrollView addSubview:sectionThCollectionView];
        //布局section3线条
        [self drawLianeWithFrame:sectionThCollectionView.frame];
    }
}

#pragma mark - 布局第一分区的线条
- (void)addSeparatorLineWithIndex:(NSInteger)index {
    NSInteger count = self.sectionOneDataArray.count;
    
    // 当数量小于行数的时候 以实际数量来布局
    NSInteger rowCount = 4;
    if (self.sectionOneDataArray.count < 4) {
        rowCount = self.sectionOneDataArray.count + 1;
    }
    
    // 当最后一个 cell 布局完成的时候为当前collection 添加分割线
    if (index == count-1) {
        CGRect frame = [[self.cellViewFrameArray objectAtIndex:index] CGRectValue];
        //        NSLog(@"line --> %@",self.cellViewFrameArray);
        
        CGFloat colHeight = frame.origin.y +frame.size.height;
        CGFloat rowWidth = PhoneScreenWidth;
        
        for (int i=0; i<rowCount-1; i++) {
            CGRect frame = [[self.cellViewFrameArray objectAtIndex:i] CGRectValue];
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(frame.origin.x + frame.size.width, 0, LineWidth, colHeight)];
            lineView.backgroundColor = [UIColor colorWithRed:(239/255.0) green:(239/255.0) blue:(239/255.0) alpha:1];
            [self.gridScrollView addSubview:lineView];
            [self.gridScrollView bringSubviewToFront:lineView];
        }
        for (int i=0; i<count+3/rowCount; i+=rowCount) {
            CGRect frame = [[self.cellViewFrameArray objectAtIndex:i] CGRectValue];
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, frame.origin.y + frame.size.height, rowWidth, LineWidth)];
            lineView.backgroundColor = [UIColor colorWithRed:(239/255.0) green:(239/255.0) blue:(239/255.0) alpha:1];
            [self.gridScrollView addSubview:lineView];
            [self.gridScrollView bringSubviewToFront:lineView];
        }
    }
}


#pragma mark - 布局第三分区线条
-(void)drawLianeWithFrame:(CGRect)frame {
 
    CGFloat colHeight = (PhoneScreen_WIDTH-LineWidth*3)/4;
    
    //第三分区 顶上 线条
    UIView *topLineView = [[UIView alloc] initWithFrame:CGRectMake(0, frame.origin.y, PhoneScreen_WIDTH, LineWidth)];
    topLineView.backgroundColor = [UIColor colorWithRed:(239/255.0) green:(239/255.0) blue:(239/255.0) alpha:1];
    [self.gridScrollView addSubview:topLineView];
    
    //竖着的 线条
    for (int i = 0; i < self.sectionThreeDataArray.count; i++) {
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake((i+1)*colHeight+i, frame.origin.y, LineWidth, colHeight)];
        lineView.backgroundColor = [UIColor colorWithRed:(239/255.0) green:(239/255.0) blue:(239/255.0) alpha:1];
        [self.gridScrollView addSubview:lineView];
        [self.gridScrollView bringSubviewToFront:lineView];
    }

    //横着的
    for (int i = 0; i<self.sectionThreeDataArray.count; i++) {
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake((colHeight+LineWidth)*i, colHeight, colHeight,0)];
        lineView.backgroundColor = [UIColor colorWithRed:(239/255.0) green:(239/255.0) blue:(239/255.0) alpha:1];
        [self.gridScrollView addSubview:lineView];
        [self.gridScrollView bringSubviewToFront:lineView];
    }
    
    //底部 线条
    UIView *bottomLineView = [[UIView alloc] initWithFrame:CGRectMake(0, frame.origin.y+colHeight, PhoneScreen_WIDTH, LineWidth)];
    bottomLineView.backgroundColor = [UIColor colorWithRed:(239/255.0) green:(239/255.0) blue:(239/255.0) alpha:1];
    
    [self.gridScrollView addSubview:bottomLineView];
}


#pragma mark - 处理删除操作
- (void)deleteView:(TMHomeGridCell *)cellView {
    //删除之后   有个记录当前长按的View    currentCellView 的状态没有改  所以在下次 点击的时候 直接在没有往下走  先是回复状态 然后 第二次 才有点击效果
    if (!self.currentCellView.deleteIsHidden && self.currentCellView) {
        self.currentCellView.deleteIsHidden = YES;
        self.currentCellView.backgroundColor = [UIColor whiteColor];
    }
    
    [self.sectionOneDataArray removeObjectAtIndex:cellView.tag - 1000];
    
    if ([self.cellViewArray containsObject:cellView]) {
        
        //记录删除的 cell 用来保存
        self.deleteCellView = cellView;
        
        [cellView removeFromSuperview];
        [self.cellViewArray removeObject:cellView];
        
        //本地保存 需要对删除的元素也进行保存 so需要用一个 deleteCellView
        [self saveItemsSettingCache];
        
        [UIView animateWithDuration:0.5 animations:^{
            [self setupSubViewsFrame];
        } completion:^(BOOL finished) {
            [self doWithData];//重新布局
            [self doWithCreatSectionOneSubViews];
            [self doWithCreatOtherSection];
        }];
    }
}

#pragma mark - 处理长按事件
- (void)handleLongPress:(UILongPressGestureRecognizer *)gesture {
    
    TMHomeGridCell *cellView = (TMHomeGridCell *)gesture.view;
    
    //定位手势 坐标点
    CGPoint point = [gesture locationInView:self.gridScrollView];
    
    if (gesture.state == UIGestureRecognizerStateBegan) {
        
        //显示 删除 图标
        self.currentCellView.deleteIsHidden = YES;
        //清除选中之前的背景色
        self.currentCellView.backgroundColor = [UIColor whiteColor];
        
        self.currentCellView = cellView;
        self.currentCellViewFrame = cellView.frame;
        
        //放大动画
        [UIView animateWithDuration:0.4 animations:^{
            cellView.transform = CGAffineTransformMakeScale(1.1, 1.1);
        }];
        
        self.currentCellView.deleteIsHidden = NO;
        //选中效果颜色
        self.currentCellView.backgroundColor = [UIColor colorWithRed:(235 / 255.0) green:(235 / 255.0) blue:(235 / 255.0) alpha:1];
        
        long index = [self.cellViewArray indexOfObject:cellView];
        
        [self.cellViewArray  removeObject:cellView];
        [self.cellViewArray  insertObject:self.placeholeView atIndex:index];
        self.lastPoint = point;
        
        [self.gridScrollView bringSubviewToFront:cellView];

    }
    
    CGRect temp = cellView.frame;
    
    temp.origin.x += point.x - self.lastPoint.x;
    temp.origin.y += point.y - self.lastPoint.y;
    
    cellView.frame = temp;
    
    self.lastPoint = point;
    
    [self.cellViewArray enumerateObjectsUsingBlock:^(UIView *view, NSUInteger idx, BOOL *stop) {
        
        //防止 最后一个 cell 被移动 位置
        if ([view isKindOfClass:[TMHomeAddCellView class]])
            return ;
        
        if (CGRectContainsPoint(view.frame, point) && view != cellView) {
            [self.cellViewArray removeObject:self.placeholeView];
            [self.cellViewArray insertObject:self.placeholeView atIndex:idx];
            
            [UIView animateWithDuration:0.5 animations:^{
                [self setupSubViewsFrame];
            }];
            
            *stop = YES;
        }
    }];
    
    //手势结束
    if (gesture.state == UIGestureRecognizerStateEnded) {
        long index = [self.cellViewArray indexOfObject:self.placeholeView];
        [self.cellViewArray removeObject:self.placeholeView];
        [self.cellViewArray insertObject:cellView atIndex:index];
        
        [self.gridScrollView sendSubviewToBack:cellView];
        
        // 保存数据 这里没有做删除操作 却保存 目的是将最新的界面布局信息 保存
        [self saveItemsSettingCache];
        
        [UIView animateWithDuration:0.4 animations:^{
            cellView.transform = CGAffineTransformIdentity;
            [self setupSubViewsFrame];
        } completion:^(BOOL finished) {
            if (!CGRectEqualToRect(self.currentCellViewFrame, self.currentCellView.frame)) {
                self.currentCellView.deleteIsHidden = YES;
                self.currentCellView.backgroundColor = [UIColor whiteColor];
            }
        }];
    }
}

- (void)setupSubViewsFrame {
    
    [self.cellViewArray enumerateObjectsUsingBlock:^(UIView *view, NSUInteger idx, BOOL *stop) {
        view.frame = [[self.cellViewFrameArray objectAtIndex:idx] CGRectValue];
        
        if ([view isEqual:self.placeholeView]) {
            [self.gridScrollView sendSubviewToBack:view];
        }
    }];
}

#pragma mark - 本地保存
- (void)saveItemsSettingCache {
    
    //保存首页展示
    NSMutableArray *itemsContainer = [NSMutableArray array];
    
    [self.cellViewArray enumerateObjectsUsingBlock:^(TMHomeGridCell *cell, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([cell isKindOfClass:[TMHomeGridCell class]]) {
            [itemsContainer addObject:@{@"title":cell.model.title,@"imageStr":cell.model.imageStr}];
        }
        //添加 最后一个 更多 数据模型(用来占位)
        if ([cell isKindOfClass:[TMHomeAddCellView class]]) {
            [itemsContainer addObject:@{@"title":@"更多",@"imageStr":@"tf_home_more"}];
        }
    }];
    [[NSUserDefaults standardUserDefaults] setObject:[itemsContainer copy] forKey:@"LocationData"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    // 保存更多页展示数组(首页删除元素数组)
    
    NSMutableArray *deleteItemContainer = nil;
    
    if (self.deleteCellView) {
        /**
         *  先获取本地已经有的然后追加，如果直接保存 会将本地已经有的给覆盖掉
         */
        NSArray *locDeleteArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"LocationDeleteData"];
        deleteItemContainer = [NSMutableArray arrayWithArray:locDeleteArr];
        [deleteItemContainer addObject:@{@"title":self.deleteCellView.model.title,@"imageStr":self.deleteCellView.model.imageStr}];
        
        [[NSUserDefaults standardUserDefaults] setObject:[deleteItemContainer copy] forKey:@"LocationDeleteData"];
        [[NSUserDefaults standardUserDefaults] synchronize];//立马保存
        
        // 置为初始状态 否则下次点击的时候 会重复调用
        self.deleteCellView = nil;
    }
}


#pragma mark - 点击选中事件
- (void)tapAction:(UITapGestureRecognizer*)tap {
    
    UIView *view = (UIView*)[(UITapGestureRecognizer*)tap view];
    
    if (!self.currentCellView.deleteIsHidden && self.currentCellView) {
        self.currentCellView.deleteIsHidden = YES;
        self.currentCellView.backgroundColor = [UIColor whiteColor];
        return;
    }
    
    if (view.tag >= 1000) {
        
        if (view.tag - 1000 == self.sectionOneDataArray.count-1) {//添加更多
            TMAddMoreViewController *vc = [[TMAddMoreViewController alloc] init];
            [vc setHidesBottomBarWhenPushed:YES];//加上这句就可以把推出的ViewController隐藏Tabbar
            vc.view.backgroundColor = [UIColor colorWithRed:(245/255.0) green:(246/255.0) blue:(247/255.0) alpha:1];
            [self.navigationController pushViewController:vc animated:YES];
        }
        
        else {
            // 通过cell 获取model
            TMHomeGridCell *cell = (TMHomeGridCell *)view;
            
            // 空白地方长按 直接return
            if ([cell.model.title isEqualToString:@""]) {
                return;
            }
            
            TMGridItemModel *model = [cell model];
            
            
            NSDictionary *dic = @{
                                  @"商品管理":@"TMGoodsManagerViewController",
                                  @"本店打折":@"TMShopDiscountViewController",
                                  @"本店优惠":@"TMShopPreferentialViewController",
                                  @"本店信息":@"TMShopInfomationViewController",
                                  @"本店活动":@"TMShopActivityViewController",
                                  @"订单":@"TMOrderViewController",
                                  @"我的业绩":@"TMMyAchievementViewController",
                                  @"我的评价":@"TMMyEvalutionViewController",
                                  @"即时营销":@"TMImmetiateMarketViewController",
                                  @"激励":@"TMEncourageViewController",
                                  @"预约":@"TMAppointmentViewController"
                                  };
            
            NSString *titleString = model.title;
            
            NSString *className = [dic objectForKey:titleString];
            Class class = NSClassFromString(className);
            
            if (class) {
                
                UIViewController *ctrl = class.new;
                ctrl.title = titleString;
                ctrl.hidesBottomBarWhenPushed = YES;
                [self.navigationController pushViewController:ctrl animated:YES];
            }
            
        }
        
    }else if (view.tag == 500) {
        
        TMCustomerWordViewController *newVC = [[TMCustomerWordViewController alloc] init];
        [newVC setHidesBottomBarWhenPushed:YES];
        [self.navigationController pushViewController:newVC animated:YES];
        
    }else {
        
        // 通过cell 获取model
        TMHomeSectionThreeView *cell = (TMHomeSectionThreeView *)view;
        TMSectionThreeModel *model = [cell modelThree];
        
        NSDictionary *dic = @{
                     @"搜索":@"TMSearchViewController",
                     @"动态":@"TMMovingAppearenceViewController",
                     @"维系":@"TMMaintainViewController"
                     };
        
        NSString *titleString = model.title;
        
        NSString *className = [dic objectForKey:titleString];
        Class class = NSClassFromString(className);
        
        if (class) {
            
            UIViewController *ctrl = class.new;
            ctrl.title = titleString;
            ctrl.hidesBottomBarWhenPushed = YES;
            [self.navigationController pushViewController:ctrl animated:YES];
        }
    }
}



@end
