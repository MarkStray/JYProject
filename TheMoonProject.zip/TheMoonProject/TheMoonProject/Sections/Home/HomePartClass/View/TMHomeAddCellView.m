//
//  TMHomeAddCellView.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMHomeAddCellView.h"

@implementation TMHomeAddCellView

- (void)awakeFromNib {
    [super awakeFromNib];
    self.backgroundColor = [UIColor whiteColor];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    tapGesture.numberOfTapsRequired = 1;
    tapGesture.numberOfTouchesRequired = 1;
    [self addGestureRecognizer:tapGesture];
}

#pragma mark - 点击事件
- (void)tapAction:(UITapGestureRecognizer *)gesture {
    if (self.tapOperationBlock) {
        self.tapOperationBlock(gesture);
    }
}

- (void)setModel:(TMGridItemModel *)model {
    // 重写 别忘记首先赋值
    _model = model;
    self.moreImageView.image=[UIImage imageNamed:self.model.imageStr];
    
}

-(void)layoutSubviews{
    
    [super layoutSubviews];
    
}



@end
