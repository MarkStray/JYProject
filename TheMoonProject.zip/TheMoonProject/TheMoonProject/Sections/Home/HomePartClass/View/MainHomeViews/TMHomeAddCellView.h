//
//  TMHomeAddCellView.h
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TMGridItemModel.h"

@interface TMHomeAddCellView : UICollectionViewCell
/**
 *  更多图片view
 */
@property (strong, nonatomic) IBOutlet UIImageView *moreImageView;

/**
 *  强引用 一个 model
 */
@property (nonatomic, strong) TMGridItemModel *model;
@end
