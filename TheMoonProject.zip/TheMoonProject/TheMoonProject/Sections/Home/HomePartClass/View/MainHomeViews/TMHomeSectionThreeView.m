//
//  TMHomeSectionThreeView.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMHomeSectionThreeView.h"

@implementation TMHomeSectionThreeView

- (void)awakeFromNib {
    
    self.backgroundColor = [UIColor whiteColor];
}

- (void)setModelThree:(TMSectionThreeModel *)modelThree {
    // 重写 别忘记首先赋值
    _modelThree = modelThree;
    
    _iconImageView.image = [UIImage imageNamed:modelThree.imageStr];
    _iconImageView.contentMode=UIViewContentModeScaleAspectFit;
    _titlelabel.text = modelThree.title;
    _titlelabel.textColor = [UIColor colorWithRed:(60/255.0) green:(60/255.0) blue:(60/255.0) alpha:1];
    CGFloat width = (PhoneScreen_WIDTH-3)/4;
    CGFloat space;
    
    if (PhoneScreen_WIDTH == 320) {// 4 5
        space = 28*2;
    }else if (PhoneScreen_WIDTH == 375) {// 6
        space = 32*2;
    }else {//6p  414
        space = 70;
    }
    
    _iconImageView.frame = CGRectMake(space/2, (space-20-5)/2, width-space, width-space);
    _titlelabel.frame = CGRectMake(10, (space-20-5)/2+width-space+5, width-20, 20);
}


@end
