//
//  TMHomeCustomerMeaasgeView.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMHomeCustomerMeaasgeView.h"

@implementation TMHomeCustomerMeaasgeView

- (void)awakeFromNib {
    
    self.backgroundColor = [UIColor whiteColor];
}

@end
