//
//  TMHomeGridCell.h
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TMGridItemModel.h"

@interface TMHomeGridCell : UICollectionViewCell
/**
 *  图标
 */
@property (strong, nonatomic) IBOutlet UIImageView *iconImageView;
/**
 *  图标名称
 */
@property (strong, nonatomic) IBOutlet UILabel *titleLabel;
/**
 *  删除按钮
 */
@property (strong, nonatomic) IBOutlet UIButton *deleteButton;
/**
 *  删除按钮图片
 */
@property (strong, nonatomic) IBOutlet UIImageView *deleteImageView;
/**
 *  记录是否隐藏删除按钮
 */
@property (nonatomic, assign) BOOL deleteIsHidden;
/**
 *  强引用 一个 model
 */
@property (nonatomic, strong) TMGridItemModel *model;


//长按事件
@property (nonatomic, copy) void (^longPressBlock) (UILongPressGestureRecognizer *gesture);

//删除事件
@property (nonatomic, copy) void (^deleteButtonClickBlock) (TMHomeGridCell *cell);


//点击事件
@property (nonatomic, copy) void (^tapOperationBlock) (UITapGestureRecognizer *gesture);

@end
