//
//  TMHomeGridCell.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMHomeGridCell.h"
#import "TMGridItemModel.h"

#define PhoneScreenWidth  [UIScreen mainScreen].bounds.size.width
#define PhoneScreenHeight [UIScreen mainScreen].bounds.size.height

@implementation TMHomeGridCell

- (void)awakeFromNib {
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    [self addGestureRecognizer:longPress];
    
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    tapGesture.numberOfTapsRequired = 1;
    tapGesture.numberOfTouchesRequired = 1;
    [self addGestureRecognizer:tapGesture];
    
    self.deleteIsHidden = YES;
    
    self.backgroundColor = [UIColor whiteColor];
}
- (void)setDeleteIsHidden:(BOOL)deleteIsHidden {
    
    _deleteIsHidden = deleteIsHidden;
    _deleteButton.hidden = deleteIsHidden;
    _deleteImageView.hidden = deleteIsHidden;
    
}

#pragma mark - 长按事件
- (void)longPress:(UILongPressGestureRecognizer *)gesture {
    if (self.longPressBlock) {
        self.longPressBlock(gesture);
    }
}

#pragma mark - 删除事件
- (IBAction)deleteButtonClick:(id)sender {
    
    if (self.deleteButtonClickBlock) {
        self.deleteButtonClickBlock(self);
    }
    
}

#pragma mark - 点击事件
- (void)tapAction:(UITapGestureRecognizer *)gesture {
    if (self.tapOperationBlock) {
        self.tapOperationBlock(gesture);
    }
}

// 重写 model 方法 在赋值的时候调用
// 等价《==》updateUIWithModel:
//    《==》showDataWithModel:
//    《==》doWithModel:

- (void)setModel:(TMGridItemModel *)model {
    // 重写 别忘记首先赋值
    _model = model;
    
    _iconImageView.image = [UIImage imageNamed:model.imageStr];
    _titleLabel.text = model.title;
    _titleLabel.textColor = [UIColor colorWithRed:(60/255.0) green:(60/255.0) blue:(60/255.0) alpha:1];
    CGFloat width = (PhoneScreen_WIDTH-3)/4;
    CGFloat space;
    
    if (PhoneScreen_WIDTH == 320) {// 4 5
        space = 28*2;
    }else if (PhoneScreen_WIDTH == 375) {// 6
        space = 32*2;
    }else {//6p  414
        space = 37*2;
    }
    
    _iconImageView.frame = CGRectMake(space/2, (space-20-5)/2, width-space, width-space);
    _titleLabel.frame = CGRectMake(10, (space-20-5)/2+width-space+5, width-20, 20);
}



@end
