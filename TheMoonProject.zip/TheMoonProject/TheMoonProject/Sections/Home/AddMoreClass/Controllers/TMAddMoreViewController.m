//
//  TMAddMoreViewController.m
//  TheMoonProject
//
//  Created by 藏云柱 on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMAddMoreViewController.h"
#import "TMHomeAddView.h"
#import "TMGridItemModel.h"

#define PhoneScreenWidth  [UIScreen mainScreen].bounds.size.width
#define PhoneScreenHeight [UIScreen mainScreen].bounds.size.height


@interface TMAddMoreViewController ()<UIScrollViewDelegate>
@property (nonatomic, strong) UIScrollView *gridScrollView;
@property (nonatomic, strong) NSMutableArray *dataArr;
/**
 *  item数组
 */
@property (nonatomic, strong) NSMutableArray *cellViewArray;
/**
 *  itemFrame数组
 */
@property (nonatomic, strong) NSMutableArray *cellViewFrameArray;
/**
 *  用来记录手势刚开始时的位置
 */
@property (nonatomic, assign) CGRect currentCellViewFrame;
/**
 *  用来记录当前是哪个item
 */
@property (nonatomic, strong) TMHomeAddView *currentCellView;
/**
 *  用来占位的一个view
 */
@property (nonatomic, strong) UIView *placeholeView;
/**
 *  记录最后的坐标
 */
@property (nonatomic, assign) CGPoint lastPoint;
/**
 *  用来记录添加的cell
 */
@property (nonatomic, strong) TMHomeAddView *addCellView;
@end

@implementation TMAddMoreViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"添加更多";
    self.view.backgroundColor = [UIColor colorWithRed:(240/255.0) green:(241/255.0) blue:(242/255.0) alpha:1];
    
    [self doWithData];
    
    self.placeholeView = [[UIView alloc] init];
    
    [self.view addSubview:self.gridCollectionView];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
    [self doWithCreatSubViews];
}

#pragma mark - 数据初始化
- (void)doWithData {
    if (self.dataArr) {
        [self.dataArr removeAllObjects];
    } else {
        self.dataArr = [NSMutableArray array];
    }
    
    NSArray *moreArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"LocationDeleteData"];
    
    for (NSDictionary *dict in moreArr) {
        TMGridItemModel *model = [[TMGridItemModel alloc] init];
        model.title = dict[@"title"];
        model.imageStr = dict[@"imageStr"];
        [self.dataArr addObject:model];
    }
    
    //初始化存放cell的数组
    if (self.cellViewArray) {
        [self.cellViewArray removeAllObjects];
    } else {
        self.cellViewArray = [NSMutableArray array];
    }
    
    //初始化存放cellFrame的数组
    if (self.cellViewFrameArray) {
        [self.cellViewFrameArray removeAllObjects];
    } else {
        self.cellViewFrameArray = [NSMutableArray array];
    }
    
    [self.gridCollectionView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
}

//#pragma mark - 创建collectionView
- (UIScrollView *)gridCollectionView {
    if (!_gridScrollView) {
        
        _gridScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, PhoneScreenWidth, PhoneScreenHeight)];
        _gridScrollView.backgroundColor = [UIColor colorWithRed:(245/255.0) green:(246/255.0) blue:(247/255.0) alpha:1];
        _gridScrollView.delegate = self;
        _gridScrollView.bounces = YES;
        _gridScrollView.alwaysBounceVertical = YES;
        
    }
    return _gridScrollView;
}

-(void)doWithCreatSubViews{
    
    float itemWidth = PhoneScreen_WIDTH/4;
    
    for (int i=0; i<self.dataArr.count; i++) {
        int a=i/4;
        int b=i%4;
        TMHomeAddView *addCellView=[[[NSBundle mainBundle]loadNibNamed:@"TMHomeAddView" owner:self options:nil]lastObject];
        addCellView.frame=CGRectMake(b*itemWidth, a*itemWidth, itemWidth, itemWidth);
        [self.gridScrollView addSubview:addCellView];
        addCellView.tag=1000+i;
        
        TMGridItemModel *model = self.dataArr[i];
        [addCellView setAddModel:model];
        //长按事件
        addCellView.longPressBlock = ^ (UILongPressGestureRecognizer *gesture) {
            [self handleLongPress:gesture];
        };
        
        //删除事件
        addCellView.addButtonClickBlock = ^ (TMHomeAddView *cellView) {
            [self addView:cellView];
        };
        
        UITapGestureRecognizer *tapGesture=[[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
        tapGesture.numberOfTapsRequired=1;
        tapGesture.numberOfTouchesRequired=1;
        [addCellView addGestureRecognizer:tapGesture];
        
        [self doWithAddCellFrameWith:addCellView index:i];
        
        [self addSeparatorLineWithIndex:i];
    }
}

-(void)doWithAddCellFrameWith:(TMHomeAddView*)view index:(int)index{
    
    [self.cellViewArray addObject:view];
    NSValue *frameValue = [NSValue valueWithCGRect:view.frame];
    [self.cellViewFrameArray addObject:frameValue];
    
}

#pragma mark - 布局屏幕上的线条
- (void)addSeparatorLineWithIndex:(NSInteger)index {
    NSInteger count = self.dataArr.count;
    
    // 当数量小于行数的时候 以实际数量来布局
    NSInteger rowCount = 4;
    if (self.dataArr.count < 4) {
        rowCount = self.dataArr.count+1;
    }
    
    // 当最后一个 cell 布局完成的时候为当前collection 添加分割线
    if (index == count-1) {
        CGRect frame = [[self.cellViewFrameArray objectAtIndex:index] CGRectValue];
        //        NSLog(@"line --> %@",self.cellViewFrameArray);
        
        CGFloat colHeight = frame.origin.y +frame.size.height;
        CGFloat rowWidth = PhoneScreenWidth;
        
        for (int i=0; i<rowCount-1; i++) {
            CGRect frame = [[self.cellViewFrameArray objectAtIndex:i] CGRectValue];
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(frame.origin.x + frame.size.width, 0, 1, colHeight)];
            lineView.backgroundColor = [UIColor colorWithRed:(239/255.0) green:(239/255.0) blue:(239/255.0) alpha:1];
            [self.gridCollectionView addSubview:lineView];
            [self.gridCollectionView bringSubviewToFront:lineView];
        }
        for (int i=0; i<count+3/rowCount; i+=rowCount) {
            CGRect frame = [[self.cellViewFrameArray objectAtIndex:i] CGRectValue];
            UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(0, frame.origin.y + frame.size.height, rowWidth, 1)];
            lineView.backgroundColor = [UIColor colorWithRed:(239/255.0) green:(239/255.0) blue:(239/255.0) alpha:1];
            [self.gridCollectionView addSubview:lineView];
            [self.gridCollectionView bringSubviewToFront:lineView];
        }
    }
}


#pragma mark - 处理长按事件
- (void)handleLongPress:(UILongPressGestureRecognizer *)gesture {
    
    TMHomeAddView *cellView = (TMHomeAddView *)gesture.view;
    
    //定位手势 坐标点
    CGPoint point = [gesture locationInView:self.gridCollectionView];
    
    if (gesture.state == UIGestureRecognizerStateBegan) {
        
        //显示 添加 图标
        self.currentCellView.addIsHidden = YES;
        //清除选中之前的背景色
        self.currentCellView.backgroundColor = [UIColor whiteColor];
        
        self.currentCellView = cellView;
        self.currentCellViewFrame = cellView.frame;
        
        //放大动画
        cellView.transform = CGAffineTransformMakeScale(1.1, 1.1);
        
        self.currentCellView.addIsHidden = NO;
        //选中效果颜色
        self.currentCellView.backgroundColor = [UIColor colorWithRed:(235 / 255.0) green:(235 / 255.0) blue:(235 / 255.0) alpha:1];
        
        long index = [self.cellViewArray indexOfObject:cellView];
        
        [self.cellViewArray  removeObject:cellView];
        [self.cellViewArray  insertObject:self.placeholeView atIndex:index];
        self.lastPoint = point;
        
        [self.gridCollectionView bringSubviewToFront:cellView];
        
    }
    
    CGRect temp = cellView.frame;
    
    temp.origin.x += point.x - self.lastPoint.x;
    temp.origin.y += point.y - self.lastPoint.y;
    
    cellView.frame = temp;
    
    self.lastPoint = point;
    
    [self.cellViewArray enumerateObjectsUsingBlock:^(UIView *view, NSUInteger idx, BOOL *stop) {
        
        if (CGRectContainsPoint(view.frame, point) && view != cellView) {
            [self.cellViewArray removeObject:self.placeholeView];
            [self.cellViewArray insertObject:self.placeholeView atIndex:idx];
            *stop = YES;
            
            [UIView animateWithDuration:0.5 animations:^{
                [self setupSubViewsFrame];
            }];
        }
    }];
    
    //手势结束
    if (gesture.state == UIGestureRecognizerStateEnded) {
        long index = [self.cellViewArray indexOfObject:self.placeholeView];
        [self.cellViewArray removeObject:self.placeholeView];
        [self.cellViewArray insertObject:cellView atIndex:index];
        
        [self.gridCollectionView sendSubviewToBack:cellView];
        
        // 保存数据 这里没有做删除操作 却保存 目的是将最新的界面布局信息 保存
        [self saveItemsSettingCache];
        
        [UIView animateWithDuration:0.4 animations:^{
            cellView.transform = CGAffineTransformIdentity;
            [self setupSubViewsFrame];
        } completion:^(BOOL finished) {
            if (!CGRectEqualToRect(self.currentCellViewFrame, self.currentCellView.frame)) {
                self.currentCellView.addIsHidden = YES;
                self.currentCellView.backgroundColor = [UIColor whiteColor];
            }
        }];
    }
}

-(void)tapAction:(UITapGestureRecognizer*)tap{
    
    
}

- (void)setupSubViewsFrame {
    [self.cellViewArray enumerateObjectsUsingBlock:^(UIView *view, NSUInteger idx, BOOL *stop) {
        view.frame = [[self.cellViewFrameArray objectAtIndex:idx] CGRectValue];
        
        if ([view isEqual:self.placeholeView]) {
            [self.gridCollectionView sendSubviewToBack:view];
        }
    }];
}

#pragma mark - 本地保存
- (void)saveItemsSettingCache {
    
    //保存更多页面 展示数组
    NSMutableArray *itemsContainer = [NSMutableArray array];
    
    [self.cellViewArray enumerateObjectsUsingBlock:^(TMHomeAddView *cell, NSUInteger idx, BOOL * _Nonnull stop) {
        if ([cell isKindOfClass:[TMHomeAddView class]]) {
            [itemsContainer addObject:@{@"title":cell.addModel.title,@"imageStr":cell.addModel.imageStr}];
        }
    }];
    [[NSUserDefaults standardUserDefaults] setObject:[itemsContainer copy] forKey:@"LocationDeleteData"];
    [[NSUserDefaults standardUserDefaults] synchronize];
    
    // 保存首页 展示数组
    
    NSMutableArray *mainItemContainer = nil;
    
    if (self.addCellView) {
        /**
         *  先获取本地已经有的然后追加，如果直接保存 会将本地已经有的给覆盖掉
         */
        NSArray *locArr = [[NSUserDefaults standardUserDefaults] objectForKey:@"LocationData"];
        mainItemContainer = [NSMutableArray arrayWithArray:locArr];
        
        
        [mainItemContainer insertObject:@{@"title":self.addCellView.addModel.title,@"imageStr":self.addCellView.addModel.imageStr} atIndex:mainItemContainer.count-1];
        
        [[NSUserDefaults standardUserDefaults] setObject:[mainItemContainer copy] forKey:@"LocationData"];
        [[NSUserDefaults standardUserDefaults] synchronize];//立马保存
        
        // 置为初始状态 否则下次点击的时候 会重复调用
        self.addCellView = nil;
    }
}



#pragma mark - 处理添加事件
- (void)addView:(TMHomeAddView *)cellView {
    
    //删除之后   有个记录当前长按的View    currentCellView 的状态没有改  所以在下次 点击的时候 直接在没有往下走  先是回复状态 然后 第二次 才有点击效果
    if (!self.currentCellView.addIsHidden && self.currentCellView) {
        self.currentCellView.addIsHidden = YES;
        self.currentCellView.backgroundColor = [UIColor whiteColor];
        self.currentCellView = nil;
    }
    
    if ([self.cellViewArray containsObject:cellView]) {
        [self.cellViewArray removeObject:cellView];
        [self.cellViewFrameArray removeLastObject];
        
        //记录删除的 cell 用来保存
        self.addCellView = cellView;
        
        [cellView removeFromSuperview];
        //本地保存 需要对添加的元素也进行保存 so需要用一个addCellView
        [self saveItemsSettingCache];
        
        [UIView animateWithDuration:0.5 animations:^{
            [self setupSubViewsFrame];
        } completion:^(BOOL finished) {
            [self doWithData];//重新布局
            [self doWithCreatSubViews];
        }];
    }
    
}

//选中 点击 事件
- (void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath {
    
    if (!self.currentCellView.addIsHidden && self.currentCellView) {
        self.currentCellView.addIsHidden = YES;
        self.currentCellView.backgroundColor = [UIColor whiteColor];
        return;
    }
}
@end
