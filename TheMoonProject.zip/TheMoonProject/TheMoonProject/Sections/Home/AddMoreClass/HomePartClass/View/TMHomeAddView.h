//
//  TMHomeAddView.h
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TMGridItemModel.h"

@interface TMHomeAddView : UICollectionViewCell

/**
 *  图标
 */
@property (strong, nonatomic) IBOutlet UIImageView *iconImageView;
/**
 *  内容label
 */
@property (strong, nonatomic) IBOutlet UILabel *contentLabel;
/**
 *  添加按钮
 */
@property (strong, nonatomic) IBOutlet UIButton *addButton;
/**
 *  添加图片
 */
@property (strong, nonatomic) IBOutlet UIImageView *addImageView;
/**
 *  记录是否隐藏添加按钮
 */
@property (nonatomic, assign) BOOL addIsHidden;
/**
 *  强引用 一个 model
 */
@property (nonatomic, strong) TMGridItemModel *addModel;

//长按事件
@property (nonatomic, copy) void (^longPressBlock) (UILongPressGestureRecognizer *gesture);

//添加事件
@property (nonatomic, copy) void (^addButtonClickBlock) (TMHomeAddView *cell);




@end
