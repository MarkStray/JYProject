//
//  TMHomeAddView.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMHomeAddView.h"

#define PhoneScreenWidth  [UIScreen mainScreen].bounds.size.width
#define PhoneScreenHeight [UIScreen mainScreen].bounds.size.height

@implementation TMHomeAddView

- (void)awakeFromNib {
    UILongPressGestureRecognizer *longPress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(longPress:)];
    [self addGestureRecognizer:longPress];
    
    self.addIsHidden = YES;
    
    self.backgroundColor = [UIColor whiteColor];
}

- (void)setAddIsHidden:(BOOL)addIsHidden {
    _addIsHidden = addIsHidden;
    _addButton.hidden = addIsHidden;
    _addImageView.hidden = addIsHidden;
}

#pragma mark - 长按事件
- (void)longPress:(UILongPressGestureRecognizer *)gesture {
    if (self.longPressBlock) {
        self.longPressBlock(gesture);
    }
}


#pragma mark - 添加事件
- (IBAction)addButtonClick:(id)sender {
    
    if (self.addButtonClickBlock) {
        self.addButtonClickBlock(self);
    }
    
}

- (void)setAddModel:(TMGridItemModel *)addModel {
    // 重写 别忘记首先赋值
    _addModel = addModel;
    
    _iconImageView.image = [UIImage imageNamed:addModel.imageStr];
    _contentLabel.text = addModel.title;
    _contentLabel.textColor = [UIColor colorWithRed:(60/255.0) green:(60/255.0) blue:(60/255.0) alpha:1];
    CGFloat width = (PhoneScreen_WIDTH-3)/4;
    CGFloat space;
    
    if (PhoneScreen_WIDTH == 320) {// 4 5
        space = 28*2;
    }else if (PhoneScreen_WIDTH == 375) {// 6
        space = 32*2;
    }else {//6p  414
        space = 37*2;
    }
    
    _iconImageView.frame = CGRectMake(space/2, (space-20-5)/2, width-space, width-space);
    _contentLabel.frame = CGRectMake(10, (space-20-5)/2+width-space+5, width-20, 20);
    
}


@end
