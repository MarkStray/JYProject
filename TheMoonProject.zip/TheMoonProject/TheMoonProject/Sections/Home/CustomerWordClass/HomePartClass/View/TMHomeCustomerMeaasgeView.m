//
//  TMHomeCustomerMeaasgeView.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMHomeCustomerMeaasgeView.h"

@implementation TMHomeCustomerMeaasgeView

- (void)awakeFromNib {
    
    self.backgroundColor = [UIColor whiteColor];
    
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(tapAction:)];
    tapGesture.numberOfTapsRequired = 1;
    tapGesture.numberOfTouchesRequired = 1;
    [self addGestureRecognizer:tapGesture];
}

#pragma mark - 点击事件
- (void)tapAction:(UITapGestureRecognizer *)gesture {
    if (self.tapOperationBlock) {
        self.tapOperationBlock(gesture);
    }
}

@end
