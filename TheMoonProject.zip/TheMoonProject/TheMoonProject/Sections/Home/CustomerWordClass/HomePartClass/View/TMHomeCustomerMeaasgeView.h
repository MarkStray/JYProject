//
//  TMHomeCustomerMeaasgeView.h
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/21.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMHomeCustomerMeaasgeView : UICollectionViewCell
/**
 *  客户留言
 */
@property (strong, nonatomic) IBOutlet UILabel *customerWordLabel;
/**
 *  留言条数
 */
@property (strong, nonatomic) IBOutlet UILabel *countLabel;
/**
 *  向右图片
 */
@property (strong, nonatomic) IBOutlet UIImageView *arrowImageView;
/**
 *  上下留白
 */
@property (strong, nonatomic) IBOutlet UIView *topView;
@property (strong, nonatomic) IBOutlet UIView *bottomView;

//点击事件
@property (nonatomic, copy) void (^tapOperationBlock) (UITapGestureRecognizer *gesture);

@end
