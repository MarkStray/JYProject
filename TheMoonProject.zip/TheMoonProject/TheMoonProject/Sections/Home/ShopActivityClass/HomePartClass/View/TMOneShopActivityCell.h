//
//  TMOneShopActivityCell.h
//  TheMoonProject
//
//  Created by iOS_yixin on 16/4/8.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TMOneShopActivityCell : UITableViewCell
/**
 *  发布时间 label
 */
@property (strong, nonatomic) IBOutlet UILabel *sendTimeLabel;
/**
 *  参加人数 label
 */
@property (strong, nonatomic) IBOutlet UILabel *personCountLabel;
/**
 *  分割线 view
 */
@property (strong, nonatomic) IBOutlet UIView *lineView;
/**
 *  头部图像 imageView
 */
@property (strong, nonatomic) IBOutlet UIImageView *iconImageView;
/**
 *  活动内容 label
 */
@property (strong, nonatomic) IBOutlet UILabel *contentLabel;
/**
 *  活动时间 label
 */
@property (strong, nonatomic) IBOutlet UILabel *activityTimeLabel;
/**
 *  活动类型 label
 */
@property (strong, nonatomic) IBOutlet UILabel *activityModeLabel;
/**
 *  二维码 button
 */
@property (strong, nonatomic) IBOutlet UIButton *codeButton;
/**
 *  分享按钮
 */
@property (strong, nonatomic) IBOutlet UIButton *shareButton;
/**
 *  二维码 label
 */
@property (strong, nonatomic) IBOutlet UILabel *codeLabel;
/**
 *  分享 imageView
 */
@property (strong, nonatomic) IBOutlet UIImageView *shareImageView;
/**
 *  分享 label
 */
@property (strong, nonatomic) IBOutlet UILabel *shareLabel;
/**
 *  二维码点击事件
 */
@property (nonatomic, copy) void (^codeClickBlock) (TMOneShopActivityCell *cell);
/**
 *  分享点击事件
 */
@property (nonatomic, copy) void (^shareClickBlock) (TMOneShopActivityCell *cell);



@end
