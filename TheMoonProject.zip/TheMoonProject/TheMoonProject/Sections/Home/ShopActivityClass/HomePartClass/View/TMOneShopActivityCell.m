//
//  TMOneShopActivityCell.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/4/8.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMOneShopActivityCell.h"
#import "ACViewHelper.h"

@implementation TMOneShopActivityCell

- (void)awakeFromNib {
    
    [self.shareImageView setImage:[ACViewHelper resizableImage:[UIImage imageNamed:@"shopActivity_share.png"]]];
    
    
}
#pragma mark - 二维码按钮 点击事件
- (IBAction)codeButtonClick:(id)sender {
    
    
    
    
    
    
}
#pragma mark - 分享按钮 点击事件
- (IBAction)shareButtonClick:(id)sender {
    
    
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
