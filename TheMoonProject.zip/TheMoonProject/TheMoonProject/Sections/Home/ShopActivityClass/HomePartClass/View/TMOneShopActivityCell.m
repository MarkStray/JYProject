//
//  TMOneShopActivityCell.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/4/8.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMOneShopActivityCell.h"
#import "ACViewHelper.h"

@implementation TMOneShopActivityCell

- (void)awakeFromNib {
    
    [self.shareImageView setImage:[ACViewHelper resizableImage:[UIImage imageNamed:@"shopActivity_share.png"]]];
    
    if (PhoneScreen_WIDTH == 320) {
        self.codeButton.frame = CGRectMake(210, 85, 50, 30);
        self.codeLabel.frame = CGRectMake(210, 90, 50, 20);
        self.shareButton.frame = CGRectMake(260, 85, PhoneScreen_WIDTH-260-10, 35);
    }else if (PhoneScreen_WIDTH == 375) {
        self.codeButton.frame = CGRectMake(210, 85, 70, 30);
        self.codeLabel.frame = CGRectMake(220, 90, 50, 20);
        self.shareButton.frame = CGRectMake(285, 85, PhoneScreen_WIDTH-285-10, 35);
    }else {
        self.codeButton.frame = CGRectMake(210, 85, 100, 30);
        self.codeLabel.frame = CGRectMake(240, 90, 50, 20);
        self.shareButton.frame = CGRectMake(320, 85, PhoneScreen_WIDTH-320-10, 35);
        
    }
//    self.codeButton.backgroundColor = [UIColor yellowColor];
//    self.codeLabel.backgroundColor = [UIColor greenColor];
//    self.shareButton.backgroundColor = [UIColor blueColor];
    self.shareImageView.frame = CGRectMake(PhoneScreen_WIDTH-50-10, 87, 50, 25);
    self.shareLabel.textAlignment = NSTextAlignmentCenter;
    self.shareLabel.frame = CGRectMake(PhoneScreen_WIDTH-50-10, 90, 50, 20);
}

#pragma mark - 二维码按钮 点击事件
- (IBAction)codeButtonClick:(id)sender {
    
    if (self.codeClickBlock) {
        self.codeClickBlock(self);
    }
    
}

#pragma mark - 分享按钮 点击事件
- (IBAction)shareButtonClick:(id)sender {
    
    if (self.shareClickBlock) {
        self.shareClickBlock(self);
    }
    
    [self.shareImageView setImage:[ACViewHelper resizableImage:[UIImage imageNamed:@"shopActivity_share_sel.png"]]];
    
}


- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
