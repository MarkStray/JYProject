//
//  TMShopActivityViewController.m
//  TheMoonProject
//
//  Created by iOS_yixin on 16/3/30.
//  Copyright © 2016年 moon. All rights reserved.
//

#import "TMShopActivityViewController.h"
#import "TMOneShopActivityCell.h"

#define LINE_WIDTH  0.5
#define ButtonCount 2
#define LINE_HEIGHT 0.75

@interface TMShopActivityViewController ()<UIScrollViewDelegate,UITableViewDataSource,UITableViewDelegate>

/**
 *  滚动视图 用来左右滑动
 */
@property (nonatomic, strong) UIScrollView *mainScrollView;
/**
 *  本店活动 视图
 */
@property (nonatomic, strong) UITableView *mainTableView;

/**
 *  头部分区视图
 */
@property (nonatomic, strong) UIView *headerView;
/**
 *  本店活动 视图
 */
@property (nonatomic, strong) UITableView *oneTableView;
/**
 *  商城活动 视图
 */
@property (nonatomic, strong) UITableView *twoTableView;
/**
 *  本店活动 数据源
 */
@property (nonatomic, strong) NSMutableArray *oneDataArr;

@end

@implementation TMShopActivityViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.title = @"本店活动";
    self.view.backgroundColor = [UIColor whiteColor];
    
    [self doWithData];
    
    [self.view addSubview:self.headerView];
    [self.view addSubview:self.mainScrollView];
    
    [self.mainScrollView addSubview:self.oneTableView];
//    [self.mainScrollView addSubview:self.twoTableView];
}

#pragma mark - 初始数据
- (void)doWithData {
    
    self.oneDataArr = [NSMutableArray arrayWithArray:@[@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@"10"]];
    
}

#pragma mark - 创建头部分区视图 
- (UIView *)headerView {
    if (!_headerView) {
        
        _headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, PhoneScreen_WIDTH, 44)];
        
        NSArray *dataArr = @[@"本店活动",@"商城活动"];
        for (NSInteger i = 0; i < 2; i++) {
            UIButton *button = [[UIButton alloc] initWithFrame:CGRectMake((PhoneScreen_WIDTH-LINE_WIDTH)/2*i, 0, PhoneScreen_WIDTH/2-LINE_WIDTH/2, 44-LINE_HEIGHT)];
            button.tag = 888+i;
            [button setTitle:dataArr[i] forState:UIControlStateNormal];
            [button setTitleColor:[UIColor colorWithRed:(164/255.0f) green:(164/255.0f) blue:(164/255.0f) alpha:1] forState:UIControlStateNormal];
            [button addTarget:self action:@selector(buttonClick:) forControlEvents:UIControlEventTouchUpInside];
            button.titleLabel.font = [UIFont systemFontOfSize:16];
            [_headerView addSubview:button];
        }
        UIView *lineView = [[UIView alloc] initWithFrame:CGRectMake(PhoneScreen_WIDTH/2-LINE_WIDTH/2, 0, LINE_WIDTH, 44-LINE_HEIGHT)];
        lineView.backgroundColor = RGBCOLOR(164, 164, 164, 1);
        [_headerView addSubview:lineView];
        
        UIView *bottomView = [[UIView alloc] initWithFrame:CGRectMake(0, 44-LINE_HEIGHT, PhoneScreen_WIDTH, LINE_HEIGHT)];
        bottomView.backgroundColor = RGBCOLOR(164, 164, 164, 1);
        [_headerView addSubview:bottomView];
        
        
    }
    return _headerView;
}

#pragma mark - 头部按钮 点击事件 
- (void)buttonClick:(UIButton *)button {
    float w = self.mainScrollView.width;
    NSInteger index = button.tag - 888;
    [self.mainScrollView scrollRectToVisible:CGRectMake(w * index, self.mainScrollView.top, self.mainScrollView.width, self.mainScrollView.height) animated:YES];
}

#pragma mark - 创建滚动视图
- (UIScrollView *)mainScrollView {
    if (!_mainScrollView) {
        _mainScrollView = [[UIScrollView alloc] initWithFrame:CGRectMake(0, self.headerView.bottom, PhoneScreen_WIDTH, PhoneScreen_HEIGHT-64-44)];
        _mainScrollView.pagingEnabled = YES;
        _mainScrollView.delegate = self;
        _mainScrollView.bounces = NO;
        _mainScrollView.showsHorizontalScrollIndicator = NO;
        _mainScrollView.showsVerticalScrollIndicator = NO;
        _mainScrollView.backgroundColor = [UIColor orangeColor];
        _mainScrollView.contentSize = CGSizeMake(PhoneScreen_WIDTH *ButtonCount, _mainScrollView.height);
    }
    return _mainScrollView;
}

#pragma mark - 创建 本店活动视图 
- (UITableView *)oneTableView {
    if (!_oneTableView) {
        _oneTableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, PhoneScreen_WIDTH, self.mainScrollView.height) style:UITableViewStyleGrouped];
        _oneTableView.delegate = self;
        _oneTableView.dataSource = self;
        _oneTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        _oneTableView.backgroundColor = RGBCOLOR(246, 246, 246, 1);
        [_oneTableView registerNib:[UINib nibWithNibName:@"TMOneShopActivityCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"TMOneShopActivityCell"];
    }
    return _oneTableView;
}

#pragma mark - tableView代理方法
//分区个数
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return self.oneDataArr.count;
}
//每个分区cell 的个数
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return 1;
}
//头视图高度
- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section {
    return CGFLOAT_MIN;
}
- (CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section {
    return 10;
}
//每个 section 的高度
- (CGFloat) tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 120;
}
//填充 cell
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    TMOneShopActivityCell *cell = [tableView dequeueReusableCellWithIdentifier:@"TMOneShopActivityCell" forIndexPath:indexPath];
    return cell;
}






















@end
