//
//  main.m
//  TheMoonProject
//
//  Created by MacBook on 16/3/7.
//  Copyright © 2016年 moon. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
